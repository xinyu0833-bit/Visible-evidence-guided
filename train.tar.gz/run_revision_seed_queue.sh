#!/bin/bash
set -e

source /root/miniconda3/etc/profile.d/conda.sh
conda activate strdiff_v2

cd /root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting

export PYTHONPATH=$PWD:$PYTHONPATH
export CUDA_VISIBLE_DEVICES=0
export TORCH_CUDA_ARCH_LIST=8.9
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

for SEED in 2025 3407
do

    CFG=$PWD/options/train/revision_seeds/PM_Correct_Seed${SEED}_20K.yml
    LOG=$PWD/revision_seed_logs/PM_Correct_Seed${SEED}_20K.log

    echo "=============================================="
    echo "START SEED $SEED"
    date
    echo "=============================================="

    python train_new.py \
    -opt "$CFG" \
    2>&1 | tee "$LOG"

    echo "=============================================="
    echo "DONE SEED $SEED"
    date
    echo "=============================================="

done
