import torch
import torch.nn.functional as F


def build_outer_boundary(mask_known, width_px):
    """
    mask_known:
        Bx1xHxW
        1 = known
        0 = hole

    width_px:
        known-side outer boundary width measured
        at input-image resolution.

    returns:
        hole, boundary
    """

    width_px = int(width_px)

    hole = 1.0 - mask_known

    if width_px <= 0:
        boundary = torch.zeros_like(hole)
        return hole, boundary

    # Radius w pixels -> odd dilation kernel 2w+1.
    kernel = 2 * width_px + 1

    dilated = F.max_pool2d(
        hole,
        kernel_size=kernel,
        stride=1,
        padding=width_px,
    )

    boundary = (
        dilated - hole
    ).clamp_(0.0, 1.0)

    return hole, boundary
