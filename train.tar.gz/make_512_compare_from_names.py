#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}


def parse_result_name(path):
    stem = Path(path).stem

    for suffix in ["_HardBlend", "_SoftBlend", "_raw", "_gtcopy"]:
        if stem.endswith(suffix):
            stem = stem[:-len(suffix)]

    if "_ratio" in stem:
        stem = stem.split("_ratio")[0]

    for cat in ["_0-20", "_20-40", "_40+", "_40"]:
        if stem.endswith(cat):
            stem = stem[:-len(cat)]

    return stem


def collect_images(root):
    root = Path(root)
    files = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in IMG_EXTS:
            files.append(p)
    return sorted(files)


def build_index(root):
    idx = {}
    for p in collect_images(root):
        idx[p.stem] = p
    return idx


def find_by_id(idx, image_id):
    if image_id in idx:
        return idx[image_id]

    candidates = [
        image_id,
        image_id + "_mask",
        image_id + "_masked",
        image_id + "_GT",
        image_id + "_gt",
    ]

    for c in candidates:
        if c in idx:
            return idx[c]

    # fallback: use first digit group
    m = re.search(r"(\d+)", image_id)
    if m:
        digits = m.group(1)
        for k, v in idx.items():
            if k == digits or k.startswith(digits + "_") or k.startswith(digits + "-"):
                return v
            if digits in k:
                return v

    return None


def load_rgb(path, size=None):
    img = Image.open(path).convert("RGB")
    if size is not None:
        img = img.resize(size, Image.BICUBIC)
    return img


def load_mask(path, size, mask_known_value):
    mask = Image.open(path).convert("L")
    mask = mask.resize(size, Image.NEAREST)

    # known=white means mask white is known region and black is hole.
    # known=black means mask black is known region and white is hole.
    if mask_known_value == "white":
        known = mask.point(lambda p: 255 if p > 127 else 0)
        hole = mask.point(lambda p: 255 if p <= 127 else 0)
    elif mask_known_value == "black":
        known = mask.point(lambda p: 255 if p <= 127 else 0)
        hole = mask.point(lambda p: 255 if p > 127 else 0)
    else:
        # auto: assume the smaller area is hole
        vals = list(mask.getdata())
        white = sum(1 for v in vals if v > 127)
        black = len(vals) - white
        if white < black:
            hole = mask.point(lambda p: 255 if p > 127 else 0)
            known = mask.point(lambda p: 255 if p <= 127 else 0)
        else:
            hole = mask.point(lambda p: 255 if p <= 127 else 0)
            known = mask.point(lambda p: 255 if p > 127 else 0)

    return known.convert("L"), hole.convert("L"), mask.convert("L")


def make_masked_input(gt, known):
    white = Image.new("RGB", gt.size, (255, 255, 255))
    return Image.composite(gt, white, known)


def make_overlay(gt, hole, alpha=120):
    overlay = gt.copy().convert("RGBA")
    red = Image.new("RGBA", gt.size, (255, 0, 0, alpha))
    transparent = Image.new("RGBA", gt.size, (0, 0, 0, 0))
    mask_rgba = Image.composite(red, transparent, hole)
    out = Image.alpha_composite(overlay, mask_rgba)
    return out.convert("RGB")


def mask_bbox(hole, pad=30):
    bbox = hole.getbbox()
    if bbox is None:
        return None
    x1, y1, x2, y2 = bbox
    w, h = hole.size
    x1 = max(0, x1 - pad)
    y1 = max(0, y1 - pad)
    x2 = min(w, x2 + pad)
    y2 = min(h, y2 + pad)

    bw = x2 - x1
    bh = y2 - y1
    side = max(bw, bh)
    cx = (x1 + x2) // 2
    cy = (y1 + y2) // 2
    x1 = max(0, cx - side // 2)
    y1 = max(0, cy - side // 2)
    x2 = min(w, x1 + side)
    y2 = min(h, y1 + side)
    x1 = max(0, x2 - side)
    y1 = max(0, y2 - side)
    return (x1, y1, x2, y2)


def draw_bbox(img, bbox):
    out = img.copy()
    if bbox is not None:
        draw = ImageDraw.Draw(out)
        draw.rectangle(bbox, outline=(255, 0, 0), width=4)
    return out


def fit_square(img, size):
    img = img.convert("RGB")
    img.thumbnail((size, size), Image.BICUBIC)
    canvas = Image.new("RGB", (size, size), "white")
    x = (size - img.width) // 2
    y = (size - img.height) // 2
    canvas.paste(img, (x, y))
    return canvas


def title_tile(img, title, size, title_h=34):
    tile = Image.new("RGB", (size, size + title_h), "white")
    tile.paste(fit_square(img, size), (0, title_h))
    draw = ImageDraw.Draw(tile)
    font = ImageFont.load_default()
    try:
        bbox = draw.textbbox((0, 0), title, font=font)
        tw = bbox[2] - bbox[0]
    except Exception:
        tw = len(title) * 6
    draw.text(((size - tw) // 2, 10), title, fill="black", font=font)
    return tile


def make_board(image_id, gt, masked, overlay, ours, hole, tile_size):
    bbox = mask_bbox(hole, pad=40)

    gt_box = draw_bbox(gt, bbox)
    ours_box = draw_bbox(ours, bbox)

    if bbox is not None:
        zoom = ours.crop(bbox)
    else:
        zoom = ours.copy()

    columns = [
        ("GT", gt_box),
        ("Input", masked),
        ("Mask Overlay", overlay),
        ("Ours-512", ours_box),
        ("Zoom-in", zoom),
    ]

    title_h = 34
    pad = 12
    header_h = 28
    w = len(columns) * tile_size + (len(columns) + 1) * pad
    h = tile_size + title_h + header_h + 2 * pad

    board = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(board)
    draw.text((pad, 8), f"ID: {image_id}", fill="black", font=ImageFont.load_default())

    x = pad
    y = header_h + pad
    for title, img in columns:
        tile = title_tile(img, title, tile_size, title_h=title_h)
        board.paste(tile, (x, y))
        x += tile_size + pad

    return board


def concat_sheets(boards, rows_per_sheet, pad=20):
    sheets = []
    for i in range(0, len(boards), rows_per_sheet):
        part = boards[i:i + rows_per_sheet]
        if not part:
            continue
        w = max(b.width for b in part)
        h = sum(b.height for b in part) + pad * (len(part) + 1)
        sheet = Image.new("RGB", (w + 2 * pad, h), "white")
        y = pad
        for b in part:
            x = pad + (w - b.width) // 2
            sheet.paste(b, (x, y))
            y += b.height + pad
        sheets.append(sheet)
    return sheets


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gt_dir", required=True)
    parser.add_argument("--mask_dir", required=True)
    parser.add_argument("--ours_dir", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--max_samples", type=int, default=40)
    parser.add_argument("--tile_size", type=int, default=260)
    parser.add_argument("--rows_per_sheet", type=int, default=4)
    parser.add_argument("--mask_known_value", default="white", choices=["white", "black", "auto"])
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    case_dir = out_dir / "cases"
    sheet_dir = out_dir / "sheets"
    case_dir.mkdir(parents=True, exist_ok=True)
    sheet_dir.mkdir(parents=True, exist_ok=True)

    gt_idx = build_index(args.gt_dir)
    mask_idx = build_index(args.mask_dir)

    result_files = [
        p for p in collect_images(args.ours_dir)
        if p.name.endswith("_HardBlend.png") or p.name.endswith("_SoftBlend.png")
    ]

    result_files = result_files[:args.max_samples]

    print(f"[INFO] result files: {len(result_files)}")
    boards = []

    for rp in result_files:
        image_id = parse_result_name(rp)
        gt_path = find_by_id(gt_idx, image_id)
        mask_path = find_by_id(mask_idx, image_id)

        if gt_path is None:
            print(f"[WARN] skip {rp.name}: GT not found for id={image_id}")
            continue
        if mask_path is None:
            print(f"[WARN] skip {rp.name}: mask not found for id={image_id}")
            continue

        ours = load_rgb(rp)
        gt = load_rgb(gt_path, size=ours.size)
        known, hole, raw_mask = load_mask(mask_path, size=ours.size, mask_known_value=args.mask_known_value)

        masked = make_masked_input(gt, known)
        overlay = make_overlay(gt, hole)

        board = make_board(image_id, gt, masked, overlay, ours, hole, args.tile_size)
        save_path = case_dir / f"{image_id}_compare_512.png"
        board.save(save_path)
        boards.append(board)
        print(f"[OK] {save_path}")

    sheets = concat_sheets(boards, rows_per_sheet=args.rows_per_sheet)
    for i, sheet in enumerate(sheets, start=1):
        save_path = sheet_dir / f"compare_512_sheet_{i:03d}.png"
        sheet.save(save_path)
        print(f"[OK] {save_path}")


if __name__ == "__main__":
    main()
