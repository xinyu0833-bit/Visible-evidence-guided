import os
import cv2
import json
import torch
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from torchvision import transforms
from torchvision.transforms import InterpolationMode
import argparse
import options as option
from models import create_model
import str_utils as str_util
import utils as util
from transformers import CLIPTextModel, CLIPTokenizer
import torch.nn.functional as F
import logging

# 拦截器 (确保输出为 Tensor)
class OutputWrapper(torch.nn.Module):
    def __init__(self, net):
        super().__init__()
        self.net = net
    def forward(self, *args, **kwargs):
        out = self.net(*args, **kwargs)
        if isinstance(out, tuple): return out[0]
        return out

def add_text_to_image(image_np, text, font_size=16):
    """在图像底部添加描述框，使用更兼容的 PIL 绘图方式"""
    h, w, c = image_np.shape
    bar_h = 70
    # 创建画布
    canvas = np.ones((h + bar_h, w, c), dtype=np.uint8) * 255
    canvas[0:h, :, :] = image_np
    
    pil_img = Image.fromarray(canvas)
    draw = ImageDraw.Draw(pil_img)
    
    # 尝试加载字体，失败则回退
    font = None
    paths = [
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                font = ImageFont.truetype(p, font_size)
                break
            except: continue
            
    # 如果还是没找到字体，使用 PIL 默认字体
    if font is None:
        font = ImageFont.load_default()

    # 简单的自动换行逻辑
    import textwrap
    lines = textwrap.wrap(text, width=w // 8) 
    y = h + 5
    for line in lines:
        try:
            # 使用最基础的绘图调用
            draw.text((10, y), line, fill=(0, 0, 0), font=font)
        except:
            # 最后的保底措施：如果 PIL 还是崩，直接跳过文字渲染
            pass
        y += font_size + 4
        
    return np.array(pil_img)

def find_file(root, raw_name):
    """提取基础 ID 并尝试匹配各种后缀"""
    # 提取 ID (如从 '507.jpg' 提取 '507')
    base_id = os.path.splitext(os.path.basename(raw_name))[0]
    
    exts = ['.jpg', '.png', '.jpeg', '.JPG', '.PNG']
    # 尝试多种命名习惯
    variants = [base_id, f"{base_id}_mask", f"{base_id}_masked"]
    
    for v in variants:
        for e in exts:
            path = os.path.join(root, v + e)
            if os.path.exists(path):
                return path
    return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-opt", default="options/test/test_dunhuang.yml", type=str)
    # 建议只输入数字 ID，如 "507,517"
    parser.add_argument("-select_ids", default="507,517,548", type=str)
    args = parser.parse_args()
    
    opt = option.parse(args.opt, is_train=False)
    opt = option.dict_to_nonedict(opt)

    util.setup_logger("base", opt["path"]["log"], "vis_prompt", level=logging.INFO, screen=True)
    logger = logging.getLogger("base")

    # 初始化模型
    model = create_model(opt) 
    device = model.device
    model.tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
    model.text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14").to(device)
    model.text_encoder.eval()

    sde = util.IRSDE(max_sigma=opt["sde"]["max_sigma"], T=opt["sde"]["T"], schedule=opt["sde"]["schedule"], eps=opt["sde"]["eps"], device=device)
    sde.set_model(OutputWrapper(model.model))
    model.model.eval()

    vis_dir = os.path.join(opt['path']['results_root'], "Visual_Proof_Figure1")
    util.mkdir(vis_dir)

    resize_256 = transforms.Resize((256, 256), interpolation=InterpolationMode.BICUBIC)
    
    final_rows = []
    ids = args.select_ids.split(',')
    
    logger.info(f"🚀 准备生成可视化对比图...")

    for img_id in ids:
        gt_path = find_file(opt['datasets']['test1']['dataroot_GT'], img_id)
        mask_path = find_file(opt['degradation']['mask_root'], img_id)
        
        if not gt_path or not mask_path:
            logger.error(f"❌ 找不到 ID {img_id}。请确认图片在 GT 目录且 Mask 在 mask_root 目录。")
            continue

        # 加载数据
        gt_pil = Image.open(gt_path).convert('RGB')
        Y_GT = transforms.ToTensor()(resize_256(gt_pil)).unsqueeze(0).to(device)
        X_GT = transforms.ToTensor()(resize_256(gt_pil.convert('L'))).unsqueeze(0).to(device)
        
        mask_pil = Image.open(mask_path).convert('L')
        mask = transforms.ToTensor()(transforms.Resize((256, 256), interpolation=InterpolationMode.NEAREST)(mask_pil)).unsqueeze(0).to(device).float()
        if mask.mean() < 0.5: mask = 1.0 - mask

        # 设置 Prompt 对照组
        clean_name = os.path.splitext(os.path.basename(gt_path))[0]
        if clean_name == "507":
            prompts = [
                ("正常引导", "一位身披石绿袍服、头戴贴金发冠的菩萨坐像。"),
                ("反向控制", "一位身披【亮蓝色】袍服、头戴【银色】发冠的菩萨坐像。")
            ]
        else:
            prompts = [
                ("正常引导", "一幅色彩丰富的敦煌壁画。"),
                ("反向控制", "一幅只有【纯紫色和蓝色】的抽象壁画。")
            ]

        logger.info(f"正在处理: {clean_name}")
        row_imgs = []
        
        # 基础对比图
        row_imgs.append(add_text_to_image(util.tensor2img((Y_GT * mask).squeeze()), "[Input] 破损输入"))
        row_imgs.append(add_text_to_image(util.tensor2img(Y_GT.squeeze()), "[GT] 完美原图"))

        # 推理
        for p_type, p_text in prompts:
            tokens = model.tokenizer([p_text], padding="max_length", max_length=77, truncation=True, return_tensors="pt").to(device)
            prompt_context = model.text_encoder(tokens.input_ids)[0]
            
            sde.set_mu(Y_GT * mask)
            with torch.no_grad():
                SR_img = sde.reverse_sde(torch.randn_like(Y_GT) * (opt["sde"]["max_sigma"] / 255.0), S=X_GT, prompt_context=prompt_context)
            
            sr_np = util.tensor2img(SR_img.squeeze())
            row_imgs.append(add_text_to_image(sr_np, f"[{p_type}]: {p_text}"))

        final_rows.append(np.hstack(row_imgs))

    if final_rows:
        res = np.vstack(final_rows)
        save_path = os.path.join(vis_dir, "Figure1_Final_Comparison.png")
        cv2.imwrite(save_path, cv2.cvtColor(res, cv2.COLOR_RGB2BGR))
        print(f"\n✅ 任务圆满完成！对比图已存至: {save_path}")
    else:
        print("\n⚠️ 未生成任何图像，请检查文件 ID 是否正确。")

if __name__ == "__main__":
    main()