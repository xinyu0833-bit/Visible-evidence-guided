#!/usr/bin/env python3
from pathlib import Path
import argparse, copy, yaml

ROOT = Path("/root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting")
TRAIN_DIR = ROOT / "options/train/boundary_sensitivity_route_only"
BASE_TRAIN = ROOT / "options/train/parameter_matched/PM_Correct_OfficialInit_20K.yml"
DEFAULT_TEMPLATE = ROOT / "options/test/test_combined_routeA_prompt_enhanced.yml"
OUT = ROOT / "options/test/boundary_sensitivity_route_only"
EXP_ROOT = ROOT / "experiments/inpainting"

parser = argparse.ArgumentParser()
parser.add_argument("--template", default=str(DEFAULT_TEMPLATE))
parser.add_argument("--k5_checkpoint", default=None,
                    help="Optional exact K=5 PM-Correct checkpoint path.")
args = parser.parse_args()

template_path = Path(args.template)
assert template_path.exists(), template_path
template = yaml.safe_load(template_path.read_text(encoding="utf-8"))
OUT.mkdir(parents=True, exist_ok=True)

def discover_ckpt(exp_name):
    candidates = [
        EXP_ROOT / exp_name / "models/20000_G.pth",
        EXP_ROOT / exp_name / "models/latest_G.pth",
    ]
    for p in candidates:
        if p.exists():
            return p
    # Last resort: search experiment tree by exact experiment directory name.
    for d in EXP_ROOT.rglob(exp_name):
        if d.is_dir():
            for fn in ("20000_G.pth", "latest_G.pth"):
                p = d / "models" / fn
                if p.exists():
                    return p
    raise FileNotFoundError(f"No checkpoint found for {exp_name}")

base_train = yaml.safe_load(BASE_TRAIN.read_text(encoding="utf-8"))
base_name = base_train["name"]

for k in [1,3,5,7,9]:
    if k == 5:
        if args.k5_checkpoint:
            ckpt = Path(args.k5_checkpoint)
            assert ckpt.exists(), ckpt
        else:
            ckpt = discover_ckpt(base_name)
        train_cfg = base_train
        exp_name = base_name
    else:
        train_path = TRAIN_DIR / f"PMCorrect_RouteK{k}_20K.yml"
        assert train_path.exists(), train_path
        train_cfg = yaml.safe_load(train_path.read_text(encoding="utf-8"))
        exp_name = train_cfg["name"]
        ckpt = discover_ckpt(exp_name)

    cfg = copy.deepcopy(template)
    cfg["name"] = f"PMCorrect_RouteK{k}_Test"

    ng = cfg.setdefault("network_G", {}).setdefault("setting", {})
    tr_ng = train_cfg["network_G"]["setting"]
    for key in [
        "use_prompt_adapter", "prompt_injection", "adapter_variant",
        "route_mode", "route_boundary_weight", "route_temperature",
        "prompt_scale",
    ]:
        if key in tr_ng:
            ng[key] = tr_ng[key]
    ng["route_kernel_size"] = int(k)

    cfg.setdefault("path", {})["pretrain_model_G"] = str(ckpt)

    # Patch any prompt_path keys to the deterministic correct test prompts.
    def rec_set_prompt(obj):
        if isinstance(obj, dict):
            for kk in list(obj):
                if kk == "prompt_path":
                    obj[kk] = "/root/autodl-tmp/data/mural/DUNHUANG/parameter_matched_prompts/test_correct.json"
                else:
                    rec_set_prompt(obj[kk])
        elif isinstance(obj, list):
            for x in obj:
                rec_set_prompt(x)
    rec_set_prompt(cfg)

    out = OUT / f"PMCorrect_RouteK{k}_Test.yml"
    out.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    print(f"K{k}: {ckpt}")
    print(f" -> {out}")
