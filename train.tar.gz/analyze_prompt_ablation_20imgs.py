import pandas as pd
from pathlib import Path
import re

root = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation")

# 只分析 6000 权重、20 张验证结果；如果后面测 8000/10000，可以改这里
patterns = [
    "prompt_ablation_retrain_6000_scale*_20imgs_summary.csv",
    "prompt_ablation_retrain_6000_scale*_summary.csv",
]

files = []
for pat in patterns:
    files.extend(root.glob(pat))

files = sorted(set(files))

if not files:
    raise SystemExit("No summary CSV found. Check output_csv path.")

def extract_scale(name):
    m = re.search(r"scale([0-9]+)", name)
    if not m:
        return "unknown"
    s = m.group(1)
    if s == "05":
        return "0.5"
    if s == "10":
        return "1.0"
    if s == "15":
        return "1.5"
    if s == "20":
        return "2.0"
    return s

all_rows = []

for p in files:
    df = pd.read_csv(p)
    df["csv_file"] = p.name
    df["scale"] = extract_scale(p.name)

    # 兼容不同脚本列名
    for col in ["psnr_hole", "psnr_all", "ssim_all", "mae_hole", "mse_hole", "n_eval"]:
        if col not in df.columns:
            df[col] = float("nan")

    all_rows.append(df)

data = pd.concat(all_rows, ignore_index=True)

# 只保留 20 张或有效样本数较小的验证结果
# 有些文件名没带 20imgs，但 n_eval=20，也纳入
data = data[data["n_eval"].fillna(0) > 0].copy()

print("\n" + "=" * 120)
print("ALL RESULTS SORTED BY scale, psnr_hole DESC")
print("=" * 120)

cols = [
    "scale",
    "prompt_mode",
    "n_eval",
    "psnr_hole",
    "psnr_all",
    "ssim_all",
    "mae_hole",
    "mse_hole",
    "csv_file",
]
print(
    data.sort_values(["scale", "psnr_hole"], ascending=[True, False])[
        [c for c in cols if c in data.columns]
    ].to_string(index=False)
)

print("\n" + "=" * 120)
print("BEST PROMPT FOR EACH SCALE")
print("=" * 120)

best_each_scale = (
    data.sort_values("psnr_hole", ascending=False)
    .groupby("scale", as_index=False)
    .head(1)
    .sort_values("scale")
)

print(
    best_each_scale[
        [c for c in ["scale", "prompt_mode", "n_eval", "psnr_hole", "psnr_all", "ssim_all", "csv_file"] if c in data.columns]
    ].to_string(index=False)
)

print("\n" + "=" * 120)
print("PROMPT GAIN AGAINST no_prompt WITHIN EACH SCALE")
print("=" * 120)

rows = []
for scale, g in data.groupby("scale"):
    base = g[g["prompt_mode"] == "no_prompt"]
    if base.empty:
        continue

    base_row = base.iloc[0]
    base_hole = base_row["psnr_hole"]
    base_all = base_row["psnr_all"]
    base_ssim = base_row["ssim_all"]

    for _, r in g.iterrows():
        rows.append({
            "scale": scale,
            "prompt_mode": r["prompt_mode"],
            "n_eval": r["n_eval"],
            "psnr_hole": r["psnr_hole"],
            "delta_hole_vs_no": r["psnr_hole"] - base_hole,
            "psnr_all": r["psnr_all"],
            "delta_all_vs_no": r["psnr_all"] - base_all,
            "ssim_all": r["ssim_all"],
            "delta_ssim_vs_no": r["ssim_all"] - base_ssim,
            "csv_file": r["csv_file"],
        })

gain = pd.DataFrame(rows)

if not gain.empty:
    print(
        gain.sort_values(["scale", "delta_hole_vs_no"], ascending=[True, False])
        .to_string(index=False)
    )

print("\n" + "=" * 120)
print("MIDDLE PROMPT COMPARISON")
print("=" * 120)

target_modes = ["no_prompt", "generic_prompt", "content_only", "content_degradation", "full_structured"]
mid = data[data["prompt_mode"].isin(target_modes)].copy()

print(
    mid.sort_values(["scale", "psnr_hole"], ascending=[True, False])[
        [c for c in ["scale", "prompt_mode", "n_eval", "psnr_hole", "psnr_all", "ssim_all", "mae_hole", "csv_file"] if c in mid.columns]
    ].to_string(index=False)
)

print("\n" + "=" * 120)
print("OBSERVATION CHECKLIST")
print("=" * 120)

for scale, g in data.groupby("scale"):
    print(f"\n[scale={scale}]")

    g_sorted = g.sort_values("psnr_hole", ascending=False)
    top = g_sorted.iloc[0]
    print(f"Top prompt: {top['prompt_mode']} | psnr_hole={top['psnr_hole']:.4f}")

    no = g[g["prompt_mode"] == "no_prompt"]
    full = g[g["prompt_mode"] == "full_structured"]
    cont = g[g["prompt_mode"] == "content_only"]
    cd = g[g["prompt_mode"] == "content_degradation"]
    gen = g[g["prompt_mode"] == "generic_prompt"]

    if not no.empty:
        no_h = no.iloc[0]["psnr_hole"]

        for name, item in [
            ("generic_prompt", gen),
            ("content_only", cont),
            ("content_degradation", cd),
            ("full_structured", full),
        ]:
            if item.empty:
                continue
            delta = item.iloc[0]["psnr_hole"] - no_h
            mark = "BETTER" if delta > 0 else "WORSE"
            print(f"{name:22s}: delta_hole_vs_no={delta:+.4f} ({mark})")

    if not full.empty and not cd.empty:
        delta = full.iloc[0]["psnr_hole"] - cd.iloc[0]["psnr_hole"]
        mark = "full > content_degradation" if delta > 0 else "full < content_degradation"
        print(f"full vs content_degradation: {delta:+.4f} ({mark})")

    if not full.empty and not cont.empty:
        delta = full.iloc[0]["psnr_hole"] - cont.iloc[0]["psnr_hole"]
        mark = "full > content_only" if delta > 0 else "full < content_only"
        print(f"full vs content_only       : {delta:+.4f} ({mark})")

print("\nDone.")
