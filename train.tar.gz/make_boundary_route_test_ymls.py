from pathlib import Path
import copy
import yaml

CFG_ROOT = Path(
    "/root/autodl-tmp/StrDiffusion_Official/"
    "train/texture/config/inpainting"
)

EXP_ROOT = Path(
    "/root/autodl-tmp/StrDiffusion_Official/"
    "train/experiments/inpainting"
)

TEMPLATE = (
    CFG_ROOT /
    "options/test/"
    "test_combined_routeA_prompt_enhanced.yml"
)

OUTDIR = (
    CFG_ROOT /
    "options/test/"
    "boundary_sensitivity_route_only"
)

TEST_GT = (
    "/root/autodl-tmp/data/mural/"
    "DUNHUANG/test/test_GT"
)

TEST_MASK = (
    "/root/autodl-tmp/data/mural/"
    "DUNHUANG/test/test_mask"
)

TEST_PROMPT = (
    "/root/autodl-tmp/data/mural/"
    "DUNHUANG/parameter_matched_prompts/"
    "test_correct.json"
)

EXPERIMENTS = {
    1: "PMCorrect_RouteK1_R0px_20K",
    3: "PMCorrect_RouteK3_R1px_20K",
    5: "PM_Correct_OfficialInit_20K",
    7: "PMCorrect_RouteK7_R3px_20K",
    9: "PMCorrect_RouteK9_R4px_20K",
}

assert TEMPLATE.exists(), TEMPLATE

OUTDIR.mkdir(
    parents=True,
    exist_ok=True
)


def find_checkpoint(exp_dir):

    preferred = [
        exp_dir / "models/20000_G.pth",
        exp_dir / "models/latest_G.pth",
    ]

    for p in preferred:
        if (
            p.exists()
            and
            p.stat().st_size > 0
        ):
            return p.resolve()

    found = []

    for name in [
        "20000_G.pth",
        "latest_G.pth",
    ]:
        found += [
            p
            for p in exp_dir.rglob(name)
            if (
                p.is_file()
                and
                p.stat().st_size > 0
            )
        ]

    if not found:
        raise FileNotFoundError(
            f"No checkpoint: {exp_dir}"
        )

    return max(
        found,
        key=lambda p:p.stat().st_mtime
    ).resolve()


def patch_paths(obj):

    if isinstance(obj, dict):

        for key in list(obj.keys()):

            if key == "prompt_path":
                obj[key] = TEST_PROMPT

            elif key == "dataroot_GT":
                obj[key] = TEST_GT

            elif key in [
                "mask_root",
                "dataroot_mask",
            ]:
                obj[key] = TEST_MASK

            else:
                patch_paths(obj[key])

    elif isinstance(obj, list):

        for x in obj:
            patch_paths(x)


template = yaml.safe_load(
    TEMPLATE.read_text()
)


for k, exp_name in EXPERIMENTS.items():

    exp_dir = (
        EXP_ROOT /
        exp_name
    )

    assert exp_dir.exists(), exp_dir

    ckpt = find_checkpoint(
        exp_dir
    )

    cfg = copy.deepcopy(
        template
    )

    cfg["name"] = (
        f"BoundarySens_RouteK{k}_Test"
    )

    setting = (
        cfg
        .setdefault(
            "network_G", {}
        )
        .setdefault(
            "setting", {}
        )
    )

    setting["use_prompt_adapter"] = True
    setting["prompt_injection"] = "full"
    setting["adapter_variant"] = "film_attn"

    setting["route_mode"] = \
        "hole_boundary"

    setting[
        "route_boundary_weight"
    ] = 0.5

    setting[
        "route_temperature"
    ] = 4.0

    # THIS IS THE SENSITIVITY VARIABLE
    setting[
        "route_kernel_size"
    ] = int(k)

    setting[
        "prompt_scale"
    ] = 2.0

    cfg.setdefault(
        "path", {}
    )[
        "pretrain_model_G"
    ] = str(ckpt)

    patch_paths(cfg)

    out = (
        OUTDIR /
        f"BoundarySens_RouteK{k}_Test.yml"
    )

    out.write_text(
        yaml.safe_dump(
            cfg,
            sort_keys=False,
            allow_unicode=True
        )
    )

    print(
        "\n============================"
    )

    print(
        f"K={k}, "
        f"radius={(k-1)//2}px"
    )

    print(
        "checkpoint:",
        ckpt
    )

    print(
        "config:",
        out
    )


print(
    "\nPASS: 5 test configs created."
)
