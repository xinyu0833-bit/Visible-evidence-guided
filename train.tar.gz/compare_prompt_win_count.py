import pandas as pd
from pathlib import Path

root = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation/per_image_metrics_retrain_6000_scale1_20imgs")

files = sorted(root.glob("*.csv"))
if not files:
    raise SystemExit(f"No per-image csv found in {root}")

dfs = {}
for p in files:
    name = p.stem.replace("test_prompt_ablation_hard_", "")
    df = pd.read_csv(p)
    dfs[name] = df[["image_id", "psnr_hole", "psnr_all", "ssim_all"]].copy()

if "no_prompt" not in dfs:
    raise SystemExit("no_prompt csv not found")

base = dfs["no_prompt"].rename(columns={
    "psnr_hole": "no_psnr_hole",
    "psnr_all": "no_psnr_all",
    "ssim_all": "no_ssim_all",
})

for name, df in dfs.items():
    if name == "no_prompt":
        continue

    merged = base.merge(df, on="image_id", how="inner")
    merged["delta_hole"] = merged["psnr_hole"] - merged["no_psnr_hole"]

    win = (merged["delta_hole"] > 0).sum()
    lose = (merged["delta_hole"] < 0).sum()
    tie = (merged["delta_hole"] == 0).sum()

    print("=" * 80)
    print(name)
    print("win / lose / tie:", win, lose, tie)
    print("mean delta_hole:", merged["delta_hole"].mean())
    print("max delta_hole :", merged["delta_hole"].max())
    print("min delta_hole :", merged["delta_hole"].min())
