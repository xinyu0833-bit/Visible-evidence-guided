#!/usr/bin/env bash
set -euo pipefail

source /root/miniconda3/etc/profile.d/conda.sh
conda activate strdiff_v2

ROOT=/root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting
cd "$ROOT"

export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

TEST_SCRIPT="${TEST_SCRIPT:-$ROOT/prompt_format_ablation/test_conbined_routeA.py}"
test -f "$TEST_SCRIPT"

mkdir -p boundary_sensitivity_route_only_test_logs

for K in 1 3 5 7 9; do
    CFG="$ROOT/options/test/boundary_sensitivity_route_only/PMCorrect_RouteK${K}_Test.yml"
    LOG="$ROOT/boundary_sensitivity_route_only_test_logs/RouteK${K}_Test.log"

    test -f "$CFG"

    echo "================================================"
    echo "TEST route_kernel_size=${K}"
    date
    echo "================================================"

    python "$TEST_SCRIPT" -opt "$CFG" 2>&1 | tee "$LOG"
done
