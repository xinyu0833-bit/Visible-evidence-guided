# -*- coding: utf-8 -*-
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


DATA_ROOT = Path("/root/autodl-tmp/data/mural/DUNHUANG/test")
FINAL_WEIGHT = "/root/autodl-tmp/StrDiffusion_Official/train/experiments/inpainting/StrDiffusion_Ours_Final_RTX4090/models/latest_G.pth"


def sort_key(x):
    x = str(x)
    return int(x) if x.isdigit() else x


def choose_prompt(item, mode):
    if not isinstance(item, dict):
        return str(item)

    prompts = item.get("prompts_for_ablation", {})

    mapping = {
        "full": "full_structured",
        "full_structured": "full_structured",
        "no_prompt": "no_prompt",
        "empty_prompt": "no_prompt",
        "generic": "generic_prompt",
        "generic_prompt": "generic_prompt",
        "tag_prompt": "tag_prompt",
        "random_prompt": "random_prompt",
        "wrong_degradation": "wrong_degradation",
        "content_only": "content_only",
        "degradation_only": "degradation_only",
        "content_degradation": "content_degradation",
    }

    key = mapping.get(mode, mode)
    prompt = prompts.get(key, "")

    if prompt is None:
        prompt = ""

    return str(prompt)


def write_flat_prompt(prompt_json, prompt_mode, out_json, limit):
    with open(prompt_json, "r", encoding="utf-8") as f:
        data = json.load(f)

    image_ids = sorted(data.keys(), key=sort_key)
    if limit is not None and limit > 0:
        image_ids = image_ids[:limit]

    flat = {}

    for image_id in image_ids:
        prompt = choose_prompt(data[image_id], prompt_mode)

        # 兼容旧 test 脚本可能使用的不同 key：501 / 501_masked / 501_mask
        for key in [
            str(image_id),
            f"{image_id}_masked",
            f"{image_id}_mask",
            f"{image_id}_edge",
        ]:
            flat[key] = {"final_prompt": prompt}

    out_json.parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(flat, f, ensure_ascii=False, indent=2)

    print(f"[WRAPPER] wrote prompt file: {out_json}")
    print(f"[WRAPPER] prompt_mode: {prompt_mode}")
    print(f"[WRAPPER] prompt samples: {len(image_ids)}")


def safe_symlink(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    dst.symlink_to(src)


def find_existing_file(folder, patterns):
    for pat in patterns:
        p = folder / pat
        if p.exists():
            return p
    return None


def make_subset_from_prompt(prompt_json, max_images):
    if max_images is None or max_images <= 0:
        return None

    with open(prompt_json, "r", encoding="utf-8") as f:
        data = json.load(f)

    image_ids = sorted(data.keys(), key=sort_key)[:max_images]

    subset_root = DATA_ROOT.parent / f"test_ablation_{max_images}"
    if subset_root.exists():
        shutil.rmtree(subset_root)

    mapping = {
        "test_GT": [
            "{id}.jpg",
            "{id}.png",
            "{id}.jpeg",
        ],
        "test_masked": [
            "{id}_masked.jpg",
            "{id}_masked.png",
            "{id}.jpg",
            "{id}.png",
        ],
        "test_mask": [
            "{id}_mask.jpg",
            "{id}_mask.png",
            "{id}.jpg",
            "{id}.png",
        ],
        "test_edge": [
            "{id}_edge.jpg",
            "{id}_edge.png",
            "{id}.jpg",
            "{id}.png",
        ],
    }

    for sub, patterns in mapping.items():
        src_dir = DATA_ROOT / sub
        dst_dir = subset_root / sub
        dst_dir.mkdir(parents=True, exist_ok=True)

        for image_id in image_ids:
            src = find_existing_file(
                src_dir,
                [p.format(id=image_id) for p in patterns]
            )
            if src is None:
                print(f"[WRAPPER][WARN] missing {sub} for id={image_id}")
                continue
            safe_symlink(src, dst_dir / src.name)

    print(f"[WRAPPER] created subset root: {subset_root}")
    return subset_root


def patch_yml(src_yml, out_yml, flat_prompt_json, ablation_name, subset_root):
    text = Path(src_yml).read_text(encoding="utf-8")

    # 使用最终权重
    text = re.sub(
        r"(?m)^(\s*)pretrain_model_G:\s*.*$",
        rf"\1pretrain_model_G: {FINAL_WEIGHT}",
        text,
    )

    # 替换 prompt_path
    text = re.sub(
        r"(?m)^(\s*)prompt_path:\s*.*$",
        rf"\1prompt_path: {flat_prompt_json}",
        text,
    )

    # 如果只测 max_images，替换测试数据路径到子集目录
    if subset_root is not None:
        old_root = str(DATA_ROOT)
        new_root = str(subset_root)

        text = text.replace(f"{old_root}/test_GT", f"{new_root}/test_GT")
        text = text.replace(f"{old_root}/test_masked", f"{new_root}/test_masked")
        text = text.replace(f"{old_root}/test_mask", f"{new_root}/test_mask")
        text = text.replace(f"{old_root}/test_edge", f"{new_root}/test_edge")

    # 修改 name，尽量让不同消融结果分目录保存
    if re.search(r"(?m)^name:\s*.*$", text):
        text = re.sub(
            r"(?m)^name:\s*.*$",
            f"name: test_combined_routeA_{ablation_name}",
            text,
        )

    out_yml.parent.mkdir(parents=True, exist_ok=True)
    out_yml.write_text(text, encoding="utf-8")

    print(f"[WRAPPER] wrote yml: {out_yml}")
    print("[WRAPPER] key yml lines:")
    for line in text.splitlines():
        if "pretrain_model_G:" in line or "prompt_path:" in line or "dataroot" in line:
            print("  " + line)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-opt", required=True)
    parser.add_argument("--prompt_json", required=True)
    parser.add_argument("--prompt_mode", default="full_structured")
    parser.add_argument("--ablation_name", default="full")
    parser.add_argument("--max_images", type=int, default=-1)

    # 接收 run_ablation_experiments.py 可能传来的参数，避免报错
    parser.add_argument("--disable_prompt_adapter", action="store_true")
    parser.add_argument("--route_mode", default=None)
    parser.add_argument("--prompt_injection", default=None)
    parser.add_argument("--adapter_variant", default=None)
    parser.add_argument("--prompt_scale", type=float, default=None)

    args = parser.parse_args()

    prompt_mode = args.prompt_mode
    if args.disable_prompt_adapter:
        prompt_mode = "no_prompt"

    work_dir = Path("options/test/_tmp_prompt_ablation")
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", args.ablation_name)

    flat_prompt = work_dir / f"prompts_{safe_name}_{prompt_mode}.json"
    tmp_yml = work_dir / f"{safe_name}_{prompt_mode}.yml"

    subset_root = make_subset_from_prompt(args.prompt_json, args.max_images)
    write_flat_prompt(args.prompt_json, prompt_mode, flat_prompt, args.max_images)
    patch_yml(args.opt, tmp_yml, flat_prompt.resolve(), safe_name, subset_root)

    cmd = [
        sys.executable,
        "test_combined_final.py",
        "-opt",
        str(tmp_yml),
    ]

    print("[WRAPPER] running:")
    print(" ".join(cmd))

    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
