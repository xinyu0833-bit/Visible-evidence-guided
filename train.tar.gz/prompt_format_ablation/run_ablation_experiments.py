#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_ablation_experiments.py

Run prompt ablation experiments without using a .sh file.

The test script must support:
--prompt_json, --prompt_mode, --ablation_name, --max_images,
--disable_prompt_adapter, --route_mode, --prompt_injection,
--adapter_variant, --prompt_scale
"""

import argparse
import subprocess
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_script", type=str, default="test_combined_final.py")
    parser.add_argument("--opt", type=str, required=True)
    parser.add_argument("--prompt_json", type=str, required=True)
    parser.add_argument("--python", type=str, default="python")
    parser.add_argument("--max_images", type=int, default=-1)
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument(
        "--only",
        type=str,
        default="",
        help="Comma-separated ablation names to run. Empty means run all default prompt ablations.",
    )
    return parser.parse_args()


def build_commands(args):
    base = [
        args.python,
        args.test_script,
        "-opt", args.opt,
        "--prompt_json", args.prompt_json,
        "--max_images", str(args.max_images),
    ]

    experiments = [
        ("full", ["--prompt_mode", "full_structured"]),
        ("empty_prompt", ["--prompt_mode", "no_prompt"]),
        ("generic_prompt", ["--prompt_mode", "generic_prompt"]),
        ("tag_prompt", ["--prompt_mode", "tag_prompt"]),
        ("random_prompt", ["--prompt_mode", "random_prompt"]),
        ("wrong_degradation", ["--prompt_mode", "wrong_degradation"]),
        ("content_only", ["--prompt_mode", "content_only"]),
        ("degradation_only", ["--prompt_mode", "degradation_only"]),
        ("content_degradation", ["--prompt_mode", "content_degradation"]),
    ]

    if args.only.strip():
        keep = {x.strip() for x in args.only.split(",") if x.strip()}
        experiments = [(name, extra) for name, extra in experiments if name in keep]

    commands = []
    for name, extra in experiments:
        commands.append((name, base + ["--ablation_name", name] + extra))
    return commands


def main():
    args = parse_args()

    if not Path(args.test_script).exists():
        raise FileNotFoundError(f"test_script not found: {args.test_script}")
    if not Path(args.prompt_json).exists():
        raise FileNotFoundError(f"prompt_json not found: {args.prompt_json}")
    if not Path(args.opt).exists():
        raise FileNotFoundError(f"opt yml not found: {args.opt}")

    commands = build_commands(args)

    if not commands:
        raise SystemExit("No ablation command selected. Check --only.")

    for name, cmd in commands:
        print("=" * 100)
        print(f"[RUN] {name}")
        print(" ".join(cmd))
        if not args.dry_run:
            subprocess.run(cmd, check=True)

    print("[DONE] All selected ablation runs finished.")


if __name__ == "__main__":
    main()
