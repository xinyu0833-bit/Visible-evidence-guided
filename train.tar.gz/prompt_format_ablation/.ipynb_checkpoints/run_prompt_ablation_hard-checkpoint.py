#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_prompt_ablation_hard.py

Prompt ablation runner for StrDiffusion / Dunhuang mural restoration.

What it does:
1. Read VLM prompt JSON containing prompts_for_ablation.
2. For each prompt mode, write a flat {image_id: {"final_prompt": "..."} } JSON
   compatible with the existing test_combined_final.py.
3. Patch the test yaml:
   - use final model weight
   - use current prompt_path
   - use unique experiment name
   - force common fusion option names to hard
   - optionally replace dataset root with a small symlink subset
4. Run test_combined_final.py.
5. Post-process predictions with HARD fusion:
      hard = pred * hole_mask + masked_input * (1 - hole_mask)
   The default assumes raw test_mask white/255 means hole/missing area.
6. Write:
   - summary CSV comparing different prompt modes
   - per-image CSV for each prompt mode

The script is intentionally regex-based for yaml patching so it can work with
the original project without adding PyYAML as a dependency.
"""

import argparse
import csv
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
from PIL import Image


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}


DEFAULT_PROMPT_MODES = [
    "no_prompt",
    "generic_prompt",
    "tag_prompt",
    "content_only",
    "degradation_only",
    "content_degradation",
    "wrong_degradation",
    "random_prompt",
    "full_structured",
]


PROMPT_MODE_MAPPING = {
    "full": "full_structured",
    "full_structured": "full_structured",
    "no_prompt": "no_prompt",
    "empty_prompt": "no_prompt",
    "generic": "generic_prompt",
    "generic_prompt": "generic_prompt",
    "tag": "tag_prompt",
    "tag_prompt": "tag_prompt",
    "random": "random_prompt",
    "random_prompt": "random_prompt",
    "wrong_degradation": "wrong_degradation",
    "content_only": "content_only",
    "degradation_only": "degradation_only",
    "content_degradation": "content_degradation",
}


def sort_key(x):
    x = str(x)
    return int(x) if x.isdigit() else x


def sanitize_name(x: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(x))


def normalize_id(stem: str) -> str:
    """Normalize common dataset/result suffixes to the base image id."""
    s = Path(stem).stem
    suffixes = [
        "_masked", "_mask", "_edge", "_gt", "_GT",
        "_output", "_Output", "_out", "_pred", "_prediction",
        "_restored", "_restore", "_fake", "_result", "_hard",
    ]
    changed = True
    while changed:
        changed = False
        for suf in suffixes:
            if s.endswith(suf):
                s = s[: -len(suf)]
                changed = True
    return s


def choose_prompt(item, prompt_mode: str) -> str:
    if not isinstance(item, dict):
        return str(item)

    prompts = item.get("prompts_for_ablation", {})
    key = PROMPT_MODE_MAPPING.get(prompt_mode, prompt_mode)
    prompt = prompts.get(key, "")
    return "" if prompt is None else str(prompt)


def load_prompt_ids(prompt_json: Path, max_images: int = -1) -> List[str]:
    data = json.loads(prompt_json.read_text(encoding="utf-8"))
    image_ids = sorted(data.keys(), key=sort_key)
    if max_images is not None and max_images > 0:
        image_ids = image_ids[:max_images]
    return [str(x) for x in image_ids]


def write_flat_prompt(prompt_json: Path, prompt_mode: str, out_json: Path, max_images: int = -1) -> Tuple[int, int]:
    data = json.loads(prompt_json.read_text(encoding="utf-8"))
    image_ids = sorted(data.keys(), key=sort_key)
    if max_images is not None and max_images > 0:
        image_ids = image_ids[:max_images]

    flat = {}
    non_empty = 0
    for image_id in image_ids:
        prompt = choose_prompt(data[image_id], prompt_mode)
        if prompt.strip():
            non_empty += 1

        # Compatible with different dataloader/test-script lookup keys.
        for key in [
            str(image_id),
            f"{image_id}_masked",
            f"{image_id}_mask",
            f"{image_id}_edge",
        ]:
            flat[key] = {"final_prompt": prompt}

    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(flat, ensure_ascii=False, indent=2), encoding="utf-8")
    return len(image_ids), non_empty


def find_existing_file(folder: Path, patterns: Iterable[str]) -> Optional[Path]:
    for pat in patterns:
        p = folder / pat
        if p.exists():
            return p
    return None


def safe_symlink_or_copy(src: Path, dst: Path, copy_files: bool = False):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() or dst.is_symlink():
        dst.unlink()
    if copy_files:
        shutil.copy2(src, dst)
    else:
        dst.symlink_to(src)


def make_subset_from_prompt(
    data_root: Path,
    prompt_json: Path,
    max_images: int,
    copy_files: bool = False,
) -> Optional[Path]:
    if max_images is None or max_images <= 0:
        return None

    image_ids = load_prompt_ids(prompt_json, max_images=max_images)
    subset_root = data_root.parent / f"{data_root.name}_prompt_ablation_{max_images}"

    if subset_root.exists():
        shutil.rmtree(subset_root)

    mapping = {
        "test_GT": ["{id}.jpg", "{id}.png", "{id}.jpeg"],
        "test_masked": ["{id}_masked.jpg", "{id}_masked.png", "{id}.jpg", "{id}.png", "{id}.jpeg"],
        "test_mask": ["{id}_mask.jpg", "{id}_mask.png", "{id}.jpg", "{id}.png", "{id}.jpeg"],
        "test_edge": ["{id}_edge.jpg", "{id}_edge.png", "{id}.jpg", "{id}.png", "{id}.jpeg"],
    }

    for sub, patterns in mapping.items():
        src_dir = data_root / sub
        dst_dir = subset_root / sub
        dst_dir.mkdir(parents=True, exist_ok=True)

        if not src_dir.exists():
            print(f"[WARN] missing source directory: {src_dir}")
            continue

        for image_id in image_ids:
            src = find_existing_file(src_dir, [p.format(id=image_id) for p in patterns])
            if src is None:
                print(f"[WARN] missing {sub} for id={image_id}")
                continue
            safe_symlink_or_copy(src, dst_dir / src.name, copy_files=copy_files)

    return subset_root


def replace_or_append_scalar(text: str, key: str, value: str, append_if_missing: bool = False) -> Tuple[str, bool]:
    pattern = rf"(?m)^(\s*){re.escape(key)}\s*:\s*.*$"
    if re.search(pattern, text):
        text = re.sub(pattern, rf"\1{key}: {value}", text)
        return text, True
    if append_if_missing:
        if not text.endswith("\n"):
            text += "\n"
        text += f"{key}: {value}\n"
    return text, False


def patch_yml(
    src_yml: Path,
    out_yml: Path,
    prompt_path: Path,
    exp_name: str,
    data_root: Path,
    final_weight: Optional[str],
    subset_root: Optional[Path],
    route_mode: str,
    prompt_injection: str,
    adapter_variant: str,
    prompt_scale: float,
):
    text = src_yml.read_text(encoding="utf-8")

    if final_weight:
        text, _ = replace_or_append_scalar(text, "pretrain_model_G", str(final_weight), append_if_missing=False)

    text, found_prompt = replace_or_append_scalar(text, "prompt_path", str(prompt_path.resolve()), append_if_missing=True)
    if not found_prompt:
        print("[WARN] prompt_path not found in yaml; appended top-level prompt_path.")

    if re.search(r"(?m)^name\s*:\s*.*$", text):
        text = re.sub(r"(?m)^name\s*:\s*.*$", f"name: {exp_name}", text)
    else:
        text = f"name: {exp_name}\n" + text

    # Replace full dataset root paths when running subset tests.
    if subset_root is not None:
        old_root = str(data_root)
        new_root = str(subset_root)
        for sub in ["test_GT", "test_masked", "test_mask", "test_edge"]:
            text = text.replace(f"{old_root}/{sub}", f"{new_root}/{sub}")

    # Force hard fusion in as many common config names as possible.
    # If the original test script only reads one of these, it will be set correctly.
    hard_string_keys = [
        "fusion_mode",
        "fuse_mode",
        "fusion_type",
        "final_fusion",
        "final_fusion_mode",
        "combine_mode",
        "merge_mode",
        "mask_fusion",
        "composite_mode",
        "blend_mode",
    ]
    any_hard_key_found = False
    for key in hard_string_keys:
        text, found = replace_or_append_scalar(text, key, "hard", append_if_missing=False)
        any_hard_key_found = any_hard_key_found or found

    text, found_hard_bool = replace_or_append_scalar(text, "hard_fusion", "true", append_if_missing=False)
    any_hard_key_found = any_hard_key_found or found_hard_bool

    if not any_hard_key_found:
        # These top-level keys are harmless for dict-style option parsers and useful
        # if test_combined_final.py checks opt.get("fusion_mode").
        if not text.endswith("\n"):
            text += "\n"
        text += "\n# Added by run_prompt_ablation_hard.py\nfusion_mode: hard\nhard_fusion: true\n"

    # Patch existing prompt-adapter ablation knobs if they are already present in yaml.
    # We do not append these blindly, because they usually belong under network_G.
    replace_map = {
        "route_mode": route_mode,
        "prompt_injection": prompt_injection,
        "adapter_variant": adapter_variant,
        "prompt_scale": str(float(prompt_scale)),
        "use_prompt_adapter": "true",
    }
    for key, value in replace_map.items():
        text, _ = replace_or_append_scalar(text, key, value, append_if_missing=False)

    out_yml.parent.mkdir(parents=True, exist_ok=True)
    out_yml.write_text(text, encoding="utf-8")

    print(f"[YML] wrote {out_yml}")
    for line in text.splitlines():
        if any(k in line for k in [
            "name:", "pretrain_model_G:", "prompt_path:", "fusion_mode:",
            "hard_fusion:", "route_mode:", "prompt_injection:",
            "adapter_variant:", "prompt_scale:"
        ]):
            print("  " + line)


def tee_subprocess(cmd: List[str], log_path: Path, cwd: Optional[str] = None) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print("[RUN]", " ".join(cmd))
    with log_path.open("w", encoding="utf-8") as f:
        f.write("[RUN] " + " ".join(cmd) + "\n\n")
        p = subprocess.Popen(
            cmd,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert p.stdout is not None
        for line in p.stdout:
            print(line, end="")
            f.write(line)
        return p.wait()


def list_images(root: Path) -> List[Path]:
    if not root.exists():
        return []
    if root.is_file() and root.suffix.lower() in IMAGE_EXTS:
        return [root]
    return [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS]


def find_image_by_id(folder: Path, image_id: str, role: str = "") -> Optional[Path]:
    if not folder.exists():
        return None

    role_patterns = {
        "gt": [f"{image_id}.png", f"{image_id}.jpg", f"{image_id}.jpeg", f"{image_id}_GT.png", f"{image_id}_gt.png"],
        "masked": [f"{image_id}_masked.png", f"{image_id}_masked.jpg", f"{image_id}.png", f"{image_id}.jpg", f"{image_id}.jpeg"],
        "mask": [f"{image_id}_mask.png", f"{image_id}_mask.jpg", f"{image_id}.png", f"{image_id}.jpg", f"{image_id}.jpeg"],
        "edge": [f"{image_id}_edge.png", f"{image_id}_edge.jpg", f"{image_id}.png", f"{image_id}.jpg"],
    }

    if role in role_patterns:
        direct = find_existing_file(folder, role_patterns[role])
        if direct is not None:
            return direct

    candidates = []
    for p in list_images(folder):
        stem_norm = normalize_id(p.stem)
        if stem_norm == str(image_id) or str(image_id) in p.stem:
            candidates.append(p)

    if not candidates:
        return None

    def score(p: Path) -> Tuple[int, float]:
        name = p.name.lower()
        s = 0
        if normalize_id(p.stem) == str(image_id):
            s += 10
        if role == "mask" and "mask" in name:
            s += 5
        if role == "masked" and "masked" in name:
            s += 5
        if role == "gt" and ("gt" in name or p.stem == str(image_id)):
            s += 5
        if role in ["pred", "output", "result"]:
            include_words = ["output", "out", "pred", "prediction", "result", "restored", "fake", "sr"]
            exclude_words = ["gt", "mask", "masked", "input", "lq", "edge"]
            if any(w in name for w in include_words):
                s += 5
            if any(w in name for w in exclude_words):
                s -= 10
        return (s, p.stat().st_mtime)

    candidates.sort(key=score, reverse=True)
    return candidates[0]


def infer_result_dir(exp_name: str, result_dir_template: Optional[str], started_at: float) -> Optional[Path]:
    if result_dir_template:
        p = Path(result_dir_template.format(name=exp_name))
        return p if p.exists() else p

    search_roots = [Path("results"), Path("experiments"), Path("train/experiments"), Path(".")]
    candidates = []

    for root in search_roots:
        if not root.exists():
            continue
        for d in root.rglob("*"):
            if not d.is_dir():
                continue
            path_lower = str(d).lower()
            if exp_name.lower() not in path_lower:
                continue
            imgs = list_images(d)
            if imgs:
                newest = max(p.stat().st_mtime for p in imgs)
                if newest >= started_at - 5:
                    candidates.append((newest, d))

    if not candidates:
        return None

    candidates.sort(reverse=True)
    return candidates[0][1]


def read_rgb(path: Path, size: Optional[Tuple[int, int]] = None) -> np.ndarray:
    im = Image.open(path).convert("RGB")
    if size is not None and im.size != size:
        im = im.resize(size, Image.BICUBIC)
    return np.asarray(im).astype(np.float32) / 255.0


def read_mask_hole(path: Path, size: Tuple[int, int], mask_white_hole: bool) -> np.ndarray:
    im = Image.open(path).convert("L")
    if im.size != size:
        im = im.resize(size, Image.NEAREST)
    arr = np.asarray(im).astype(np.float32) / 255.0
    hole = arr > 0.5
    if not mask_white_hole:
        hole = ~hole
    return hole


def psnr_from_mse(mse: float) -> float:
    if mse <= 1e-12:
        return float("inf")
    return 10.0 * math.log10(1.0 / mse)


def compute_ssim_safe(a: np.ndarray, b: np.ndarray) -> float:
    try:
        from skimage.metrics import structural_similarity
        return float(structural_similarity(a, b, data_range=1.0, channel_axis=2))
    except Exception:
        return float("nan")


def compute_metrics(pred: np.ndarray, gt: np.ndarray, hole: Optional[np.ndarray] = None) -> Dict[str, float]:
    diff = pred - gt
    out = {}

    mse_all = float(np.mean(diff ** 2))
    out["mse_all"] = mse_all
    out["mae_all"] = float(np.mean(np.abs(diff)))
    out["psnr_all"] = psnr_from_mse(mse_all)
    out["ssim_all"] = compute_ssim_safe(pred, gt)

    if hole is not None and np.any(hole):
        hole3 = np.repeat(hole[:, :, None], 3, axis=2)
        d = diff[hole3]
        mse_hole = float(np.mean(d ** 2))
        out["mse_hole"] = mse_hole
        out["mae_hole"] = float(np.mean(np.abs(d)))
        out["psnr_hole"] = psnr_from_mse(mse_hole)
    else:
        out["mse_hole"] = float("nan")
        out["mae_hole"] = float("nan")
        out["psnr_hole"] = float("nan")

    return out


def mean_ignore_nan(values: List[float]) -> float:
    arr = np.asarray(values, dtype=np.float64)
    arr = arr[~np.isnan(arr)]
    if arr.size == 0:
        return float("nan")
    if np.isinf(arr).any():
        finite = arr[np.isfinite(arr)]
        return float(np.mean(finite)) if finite.size else float("inf")
    return float(np.mean(arr))


def hard_fuse_and_eval(
    image_ids: List[str],
    data_root: Path,
    result_dir: Path,
    hard_dir: Path,
    per_image_csv: Path,
    mask_white_hole: bool,
) -> Dict[str, float]:
    hard_dir.mkdir(parents=True, exist_ok=True)
    per_image_csv.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    missing = []

    for image_id in image_ids:
        gt_path = find_image_by_id(data_root / "test_GT", image_id, role="gt")
        masked_path = find_image_by_id(data_root / "test_masked", image_id, role="masked")
        mask_path = find_image_by_id(data_root / "test_mask", image_id, role="mask")
        pred_path = find_image_by_id(result_dir, image_id, role="pred")

        if gt_path is None or masked_path is None or mask_path is None or pred_path is None:
            missing.append({
                "image_id": image_id,
                "gt_found": gt_path is not None,
                "masked_found": masked_path is not None,
                "mask_found": mask_path is not None,
                "pred_found": pred_path is not None,
            })
            continue

        gt_im = Image.open(gt_path).convert("RGB")
        size = gt_im.size
        gt = np.asarray(gt_im).astype(np.float32) / 255.0
        pred = read_rgb(pred_path, size=size)
        masked = read_rgb(masked_path, size=size)
        hole = read_mask_hole(mask_path, size=size, mask_white_hole=mask_white_hole)

        hole3 = np.repeat(hole[:, :, None], 3, axis=2)
        hard = np.where(hole3, pred, masked)
        hard_u8 = np.clip(hard * 255.0 + 0.5, 0, 255).astype(np.uint8)

        out_path = hard_dir / f"{image_id}.png"
        Image.fromarray(hard_u8).save(out_path)

        m = compute_metrics(hard, gt, hole=hole)
        row = {
            "image_id": image_id,
            "pred_path": str(pred_path),
            "hard_path": str(out_path),
            **m,
        }
        rows.append(row)

    fieldnames = [
        "image_id", "pred_path", "hard_path",
        "psnr_all", "ssim_all", "mae_all", "mse_all",
        "psnr_hole", "mae_hole", "mse_hole",
    ]
    with per_image_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})

    if missing:
        miss_path = per_image_csv.with_suffix(".missing.json")
        miss_path.write_text(json.dumps(missing, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[WARN] missing {len(missing)} samples for evaluation; details: {miss_path}")

    summary = {
        "n_eval": len(rows),
        "n_missing": len(missing),
        "psnr_all": mean_ignore_nan([r["psnr_all"] for r in rows]),
        "ssim_all": mean_ignore_nan([r["ssim_all"] for r in rows]),
        "mae_all": mean_ignore_nan([r["mae_all"] for r in rows]),
        "mse_all": mean_ignore_nan([r["mse_all"] for r in rows]),
        "psnr_hole": mean_ignore_nan([r["psnr_hole"] for r in rows]),
        "mae_hole": mean_ignore_nan([r["mae_hole"] for r in rows]),
        "mse_hole": mean_ignore_nan([r["mse_hole"] for r in rows]),
    }
    return summary


def write_summary_csv(rows: List[Dict[str, object]], output_csv: Path):
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "prompt_mode", "experiment_name", "n_prompt", "n_non_empty_prompt",
        "return_code", "n_eval", "n_missing",
        "psnr_all", "ssim_all", "mae_all", "mse_all",
        "psnr_hole", "mae_hole", "mse_hole",
        "hard_fusion", "result_dir", "hard_dir", "per_image_csv", "log_path", "tmp_yml", "flat_prompt_json",
    ]
    with output_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-opt", required=True, help="Base test yaml, e.g. options/test/test_combined_final.yml")
    parser.add_argument("--prompt_json", required=True, help="VLM prompt JSON with prompts_for_ablation.")
    parser.add_argument("--test_script", default="test_combined_final.py")
    parser.add_argument("--data_root", default="/root/autodl-tmp/data/mural/DUNHUANG/test")
    parser.add_argument("--final_weight", default="/root/autodl-tmp/StrDiffusion_Official/train/experiments/inpainting/StrDiffusion_Ours_Final_RTX4090/models/latest_G.pth")
    parser.add_argument("--prompt_modes", nargs="+", default=DEFAULT_PROMPT_MODES)
    parser.add_argument("--max_images", type=int, default=-1)
    parser.add_argument("--work_dir", default="options/test/_tmp_prompt_ablation_hard")
    parser.add_argument("--output_csv", default="prompt_format_ablation/prompt_ablation_hard_summary.csv")
    parser.add_argument("--hard_root", default="prompt_format_ablation/hard_fusion_outputs")
    parser.add_argument("--per_image_root", default="prompt_format_ablation/per_image_metrics")
    parser.add_argument("--result_dir_template", default=None,
                        help='Optional prediction dir template, e.g. "results/{name}" or "experiments/{name}/visualization".')
    parser.add_argument("--route_mode", default="hole_boundary")
    parser.add_argument("--prompt_injection", default="full")
    parser.add_argument("--adapter_variant", default="film_attn")
    parser.add_argument("--prompt_scale", type=float, default=2.0)
    parser.add_argument("--mask_white_hole", action="store_true", default=True,
                        help="Default: raw mask white/255 means missing area/hole.")
    parser.add_argument("--mask_black_hole", action="store_true",
                        help="Use this if raw mask black/0 means missing area/hole.")
    parser.add_argument("--copy_subset_files", action="store_true",
                        help="Copy subset files instead of symlinking them.")
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument("--continue_on_error", action="store_true", default=True)
    parser.add_argument("--extra_test_args", nargs=argparse.REMAINDER,
                        help="Everything after this flag is appended to test command.")
    return parser.parse_args()


def main():
    args = parse_args()

    src_yml = Path(args.opt)
    prompt_json = Path(args.prompt_json)
    data_root = Path(args.data_root)
    work_dir = Path(args.work_dir)
    output_csv = Path(args.output_csv)
    hard_root = Path(args.hard_root)
    per_image_root = Path(args.per_image_root)

    mask_white_hole = not args.mask_black_hole

    image_ids = load_prompt_ids(prompt_json, max_images=args.max_images)
    subset_root = make_subset_from_prompt(
        data_root=data_root,
        prompt_json=prompt_json,
        max_images=args.max_images,
        copy_files=args.copy_subset_files,
    )
    eval_data_root = subset_root if subset_root is not None else data_root

    print(f"[INFO] prompt modes: {args.prompt_modes}")
    print(f"[INFO] num image ids: {len(image_ids)}")
    print(f"[INFO] eval data root: {eval_data_root}")
    print(f"[INFO] hard fusion: enabled; raw mask white means hole = {mask_white_hole}")

    rows = []

    for prompt_mode in args.prompt_modes:
        mode_key = PROMPT_MODE_MAPPING.get(prompt_mode, prompt_mode)
        exp_name = f"test_prompt_ablation_hard_{sanitize_name(mode_key)}"

        flat_prompt = work_dir / f"prompts_{sanitize_name(mode_key)}.json"
        tmp_yml = work_dir / f"{sanitize_name(mode_key)}.yml"
        log_path = work_dir / "logs" / f"{sanitize_name(mode_key)}.log"

        n_prompt, n_non_empty = write_flat_prompt(
            prompt_json=prompt_json,
            prompt_mode=mode_key,
            out_json=flat_prompt,
            max_images=args.max_images,
        )

        patch_yml(
            src_yml=src_yml,
            out_yml=tmp_yml,
            prompt_path=flat_prompt,
            exp_name=exp_name,
            data_root=data_root,
            final_weight=args.final_weight,
            subset_root=subset_root,
            route_mode=args.route_mode,
            prompt_injection=args.prompt_injection,
            adapter_variant=args.adapter_variant,
            prompt_scale=args.prompt_scale,
        )

        cmd = [sys.executable, args.test_script, "-opt", str(tmp_yml)]
        if args.extra_test_args:
            cmd += args.extra_test_args

        started_at = time.time()
        if args.dry_run:
            rc = 0
            print("[DRY RUN] skip test command.")
        else:
            rc = tee_subprocess(cmd, log_path=log_path)

        result_dir = infer_result_dir(exp_name, args.result_dir_template, started_at=started_at)
        hard_dir = hard_root / exp_name
        per_image_csv = per_image_root / f"{exp_name}.csv"

        eval_summary = {
            "n_eval": 0,
            "n_missing": len(image_ids),
            "psnr_all": float("nan"),
            "ssim_all": float("nan"),
            "mae_all": float("nan"),
            "mse_all": float("nan"),
            "psnr_hole": float("nan"),
            "mae_hole": float("nan"),
            "mse_hole": float("nan"),
        }

        if result_dir is not None and result_dir.exists() and not args.dry_run:
            print(f"[EVAL] result_dir={result_dir}")
            eval_summary = hard_fuse_and_eval(
                image_ids=image_ids,
                data_root=eval_data_root,
                result_dir=result_dir,
                hard_dir=hard_dir,
                per_image_csv=per_image_csv,
                mask_white_hole=mask_white_hole,
            )
        else:
            print(f"[WARN] result directory not found for {exp_name}. "
                  f"Set --result_dir_template if auto-detection fails.")

        row = {
            "prompt_mode": mode_key,
            "experiment_name": exp_name,
            "n_prompt": n_prompt,
            "n_non_empty_prompt": n_non_empty,
            "return_code": rc,
            **eval_summary,
            "hard_fusion": "hard",
            "result_dir": str(result_dir) if result_dir is not None else "",
            "hard_dir": str(hard_dir),
            "per_image_csv": str(per_image_csv),
            "log_path": str(log_path),
            "tmp_yml": str(tmp_yml),
            "flat_prompt_json": str(flat_prompt),
        }
        rows.append(row)
        write_summary_csv(rows, output_csv)

        print(f"[DONE] {mode_key}: n_eval={row['n_eval']} "
              f"PSNR_all={row['psnr_all']} SSIM_all={row['ssim_all']} "
              f"PSNR_hole={row['psnr_hole']}")
        print(f"[CSV] updated {output_csv}")

        if rc != 0 and not args.continue_on_error:
            raise SystemExit(rc)

    print(f"[FINAL] summary csv: {output_csv}")


if __name__ == "__main__":
    main()
