import argparse
import logging
import os
import random
import json
import glob
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import options as option
from models import create_model
import str_utils as str_util
import utils as util
from data import create_dataloader, create_dataset
from PIL import Image
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from torchvision.transforms.functional import gaussian_blur
from transformers import CLIPTextModel, CLIPTokenizer
from skimage.feature import canny
from ablation_prompt_utils import (
    add_ablation_arguments,
    apply_ablation_to_model,
    load_prompt_database,
    select_prompt,
)

# metrics
from skimage.metrics import peak_signal_noise_ratio as psnr_metric
from skimage.metrics import structural_similarity as ssim_metric
import lpips

try:
    import pyiqa
    HAS_NIQE = True
except ImportError:
    HAS_NIQE = False
    print("⚠️ 未安装 pyiqa，NIQE 将显示为 0。请执行: pip install pyiqa")


class OutputWrapper(torch.nn.Module):
    def __init__(self, net):
        super().__init__()
        self.net = net
        self.current_mask = None
        self.S_GT = None
        self.S_LQ = None
        self.S_sde = None

    def forward(self, xt, cond, time, **kwargs):
        if self.current_mask is not None:
            kwargs["mask"] = self.current_mask

        if self.S_sde is not None and self.S_GT is not None and self.S_LQ is not None:
            if isinstance(time, (int, float)):
                t_tensor = torch.tensor([int(time)], device=xt.device).long()
            else:
                t_tensor = time.long().squeeze()
                if t_tensor.dim() == 0:
                    t_tensor = t_tensor.unsqueeze(0)

            self.S_sde.set_mu(self.S_LQ * self.current_mask)
            S_mu_bar = self.S_sde.mu_bar(self.S_GT, t_tensor)
            S_sigma_bar = self.S_sde.sigma_bar(t_tensor).view(-1, 1, 1, 1)

            S_noise = torch.randn_like(S_mu_bar)
            S_optimum = S_mu_bar + S_noise * S_sigma_bar
            kwargs["S"] = S_optimum

        out = self.net(xt, cond, time, **kwargs)
        if isinstance(out, tuple):
            return out[0]
        return out


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def compute_metrics(pred_tensor, gt_tensor, mask_tensor, loss_fn_vgg, niqe_metric=None):
    """
    pred_tensor, gt_tensor: [1,3,H,W], range [0,1]
    mask_tensor: [1,1,H,W], 1=known, 0=hole
    """
    pred_tensor = torch.clamp(pred_tensor, 0.0, 1.0)
    gt_tensor = torch.clamp(gt_tensor, 0.0, 1.0)

    pred_bgr_np = pred_tensor.squeeze(0).detach().cpu().numpy().transpose(1, 2, 0)
    gt_bgr_np = gt_tensor.squeeze(0).detach().cpu().numpy().transpose(1, 2, 0)
    mask_np = mask_tensor.squeeze(0).squeeze(0).detach().cpu().numpy()

    pred_rgb_u8 = np.clip(pred_bgr_np[:, :, ::-1] * 255.0, 0, 255).astype(np.uint8)
    gt_rgb_u8 = np.clip(gt_bgr_np[:, :, ::-1] * 255.0, 0, 255).astype(np.uint8)

    pred_rgb_f32 = pred_rgb_u8.astype(np.float32) / 255.0
    gt_rgb_f32 = gt_rgb_u8.astype(np.float32) / 255.0

    global_psnr = psnr_metric(gt_rgb_u8, pred_rgb_u8)
    _, ssim_map = ssim_metric(
        gt_rgb_f32,
        pred_rgb_f32,
        channel_axis=2,
        full=True,
        data_range=1.0
    )
    global_ssim = np.mean(ssim_map)

    mask_3c = np.expand_dims(mask_np, axis=-1).repeat(3, axis=-1)
    hole_mask_3c = 1.0 - mask_3c
    hole_mask_1c = 1.0 - mask_np

    mse_hole = np.sum(((gt_rgb_f32 - pred_rgb_f32) ** 2) * hole_mask_3c) / (np.sum(hole_mask_3c) + 1e-8)
    hole_psnr = 10 * np.log10(1.0 / mse_hole) if mse_hole > 0 else 99.99

    ssim_map_gray = np.mean(ssim_map, axis=2)
    hole_ssim = np.sum(ssim_map_gray * hole_mask_1c) / (np.sum(hole_mask_1c) + 1e-8)

    t_pred_lpips = pred_tensor[:, [2, 1, 0], :, :] * 2.0 - 1.0
    t_gt_lpips = gt_tensor[:, [2, 1, 0], :, :] * 2.0 - 1.0

    with torch.no_grad():
        lpips_val = loss_fn_vgg(t_pred_lpips, t_gt_lpips).item()
        niqe_val = niqe_metric(pred_tensor[:, [2, 1, 0], :, :]).item() if niqe_metric is not None else 0.0

    return {
        "Global_PSNR": round(global_psnr, 4),
        "Global_SSIM": round(global_ssim, 4),
        "Hole_PSNR": round(hole_psnr, 4),
        "Hole_SSIM": round(hole_ssim, 4),
        "LPIPS": round(lpips_val, 4),
        "NIQE": round(niqe_val, 4)
    }


def summarize_results(df, title):
    print("\n" + "=" * 110)
    print(title)
    print(f"{'Category':<12} | {'Count':<6} | {'G-PSNR':<8} | {'H-PSNR':<8} | {'H-SSIM':<8} | {'LPIPS':<8} | {'NIQE':<8}")
    print("-" * 110)

    categories = ["0-20%", "20-40%", "40%+"]
    summary_rows = []

    for c in categories:
        sub = df[df["Category"] == c]
        if len(sub) == 0:
            continue

        m_gp = sub["Global_PSNR"].mean()
        m_hp = sub["Hole_PSNR"].mean()
        m_hs = sub["Hole_SSIM"].mean()
        m_lp = sub["LPIPS"].mean()
        m_nq = sub["NIQE"].mean()

        print(f"{c:<12} | {len(sub):<6} | {m_gp:<8.4f} | {m_hp:<8.4f} | {m_hs:<8.4f} | {m_lp:<8.4f} | {m_nq:<8.4f}")

        summary_rows.append({
            "Image": f"AVG_{c}",
            "Category": c,
            "Ratio": "",
            "Fusion": title,
            "Global_PSNR": m_gp,
            "Global_SSIM": sub["Global_SSIM"].mean(),
            "Hole_PSNR": m_hp,
            "Hole_SSIM": m_hs,
            "LPIPS": m_lp,
            "NIQE": m_nq
        })

    mean_gp = df["Global_PSNR"].mean()
    mean_gs = df["Global_SSIM"].mean()
    mean_hp = df["Hole_PSNR"].mean()
    mean_hs = df["Hole_SSIM"].mean()
    mean_lp = df["LPIPS"].mean()
    mean_nq = df["NIQE"].mean()

    print("-" * 110)
    print(f"{'OVERALL':<12} | {len(df):<6} | {mean_gp:<8.4f} | {mean_hp:<8.4f} | {mean_hs:<8.4f} | {mean_lp:<8.4f} | {mean_nq:<8.4f}")
    print("=" * 110)

    summary_rows.append({
        "Image": "AVERAGE_ALL",
        "Category": "ALL",
        "Ratio": "",
        "Fusion": title,
        "Global_PSNR": mean_gp,
        "Global_SSIM": mean_gs,
        "Hole_PSNR": mean_hp,
        "Hole_SSIM": mean_hs,
        "LPIPS": mean_lp,
        "NIQE": mean_nq
    })

    return summary_rows


def main():
    set_random_seed(42)

    parser = argparse.ArgumentParser()
    parser.add_argument("-opt", default="options/test/test_combined_routeA.yml", type=str)
    args = parser.parse_args()

    opt = option.parse(args.opt, is_train=False)
    opt = option.dict_to_nonedict(opt)

    base_results_root = opt["path"]["results_root"]
    util.mkdirs(
        path for key, path in opt["path"].items()
        if key != "experiments_root" and "pretrain_model" not in key and "resume" not in key
    )

    util.setup_logger(
        "base",
        opt["path"]["log"],
        "test_combined_hard_soft_ablation",
        level=logging.INFO,
        screen=False,
        tofile=True
    )
    logger = logging.getLogger("base")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info("⏳ 正在加载 LPIPS 与 NIQE 评估模型...")
    loss_fn_vgg = lpips.LPIPS(net="vgg").to(device)
    niqe_metric = pyiqa.create_metric("niqe", device=device) if HAS_NIQE else None

    model = create_model(opt)

    logger.info("Initializing CLIP Text Encoder...")
    tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
    text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14").to(device)
    text_encoder.eval()

    sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )
    S_sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )
    wrapped_model = OutputWrapper(model.model)
    sde.set_model(wrapped_model)

    resize_256 = transforms.Resize((256, 256), interpolation=InterpolationMode.BICUBIC)
    mask_resize_256 = transforms.Resize((256, 256), interpolation=InterpolationMode.NEAREST)
    transform_mask = transforms.Compose([mask_resize_256, transforms.ToTensor()])

    for phase, dataset_opt in sorted(opt["datasets"].items()):
        dataset_name = dataset_opt.get("name", phase)
        logger.info("\n" + "=" * 85)
        logger.info(f"🚀 正在开始评测数据集: {dataset_name}")
        logger.info("=" * 85)

        current_results_root = os.path.join(base_results_root, f"{dataset_name}_FusionAblation_Results")
        hard_dir = os.path.join(current_results_root, "images_hard")
        soft_dir = os.path.join(current_results_root, "images_soft")
        raw_dir = os.path.join(current_results_root, "images_raw")
        csv_path = os.path.join(current_results_root, f"{dataset_name}_FusionAblation_Metrics.csv")

        util.mkdir(current_results_root)
        util.mkdir(hard_dir)
        util.mkdir(soft_dir)
        util.mkdir(raw_dir)

        test_set = create_dataset(dataset_opt)
        test_loader = create_dataloader(test_set, dataset_opt)

        prompt_dict = {}
        prompt_json_path = dataset_opt.get("prompt_path", "")
        if prompt_json_path and os.path.exists(prompt_json_path):
            with open(prompt_json_path, "r", encoding="utf-8") as f:
                prompt_dict = json.load(f)

        mask_root = dataset_opt.get("mask_root", opt.get("degradation", {}).get("mask_root", ""))
        available_masks = sorted(
            glob.glob(os.path.join(mask_root, "*.png")) +
            glob.glob(os.path.join(mask_root, "*.jpg"))
        )

        all_results = []

        for g, train_data in enumerate(test_loader):
            img_path = train_data["GT_path"][0]
            img_name = os.path.splitext(os.path.basename(img_path))[0]

            possible_mask_names = [
                f"{img_name}.jpg", f"{img_name}.png",
                f"{img_name}_mask.jpg", f"{img_name}_mask.png",
                f"{img_name}_masked.jpg", f"{img_name}_masked.png"
            ]

            mask_path = None
            for name in possible_mask_names:
                tmp_path = os.path.join(mask_root, name)
                if os.path.exists(tmp_path):
                    mask_path = tmp_path
                    break

            if mask_path is None:
                if len(available_masks) > 0:
                    mask_path = random.choice(available_masks)
                else:
                    logger.warning(f"⚠️ 跳过 {img_name}: {mask_root} 目录下没有任何掩码！")
                    continue

            real_gt_pil = Image.open(img_path).convert("RGB")
            Y_GT = transforms.ToTensor()(resize_256(real_gt_pil)).unsqueeze(0).to(device)
            X_GT = transforms.ToTensor()(resize_256(real_gt_pil.convert("L"))).unsqueeze(0).to(device)

            real_gt_gray_np = np.array(resize_256(real_gt_pil.convert("L"))) / 255.0
            edge_np = canny(real_gt_gray_np, sigma=2.0)
            X_LQ = torch.from_numpy(edge_np).float().unsqueeze(0).unsqueeze(0).to(device)

            mask_pil = Image.open(mask_path).convert("1")
            mask = transform_mask(mask_pil).unsqueeze(0).to(device).float()
            mask = (mask > 0.5).float()  # 1=完好, 0=破损

            damage_ratio = (mask == 0).float().mean().item()
            cat = "0-20%" if damage_ratio <= 0.20 else "20-40%" if damage_ratio <= 0.40 else "40%+"

            save_hard_subdir = os.path.join(hard_dir, cat)
            save_soft_subdir = os.path.join(soft_dir, cat)
            save_raw_subdir = os.path.join(raw_dir, cat)
            util.mkdir(save_hard_subdir)
            util.mkdir(save_soft_subdir)
            util.mkdir(save_raw_subdir)

            raw_prompt = prompt_dict.get(img_name, "一幅色彩丰富的敦煌壁画。")
            current_prompt = raw_prompt.get("final_prompt", "一幅色彩丰富的敦煌壁画。") if isinstance(raw_prompt, dict) else str(raw_prompt)

            tokens = tokenizer(
                [current_prompt],
                padding="max_length",
                max_length=77,
                truncation=True,
                return_tensors="pt"
            ).to(device)

            with torch.no_grad():
                prompt_context = text_encoder(tokens.input_ids)[0]

            model.model.eval()
            sde.set_mu(Y_GT * mask)

            wrapped_model.current_mask = mask
            wrapped_model.S_GT = X_GT
            wrapped_model.S_LQ = X_LQ
            wrapped_model.S_sde = S_sde

            init_xt = (Y_GT * mask) + torch.randn_like(Y_GT) * (opt["sde"]["max_sigma"] / 255.0)

            with torch.no_grad():
                SR_img = sde.reverse_sde(init_xt, prompt_context=prompt_context)

            wrapped_model.current_mask = None
            wrapped_model.S_GT = None
            wrapped_model.S_LQ = None
            wrapped_model.S_sde = None

            SR_img = SR_img.to(device)
            SR_img = torch.clamp(SR_img, 0.0, 1.0)

            # Hard blend: Baseline-style
            hard_out = SR_img * (1.0 - mask) + Y_GT * mask
            hard_out = torch.clamp(hard_out, 0.0, 1.0)

            # Soft blend: original ours
            soft_mask = gaussian_blur(mask, kernel_size=[5, 5], sigma=[1.5, 1.5])
            soft_out = SR_img * (1.0 - soft_mask) + Y_GT * soft_mask
            soft_out = torch.clamp(soft_out, 0.0, 1.0)

            # metrics
            hard_metrics = compute_metrics(hard_out, Y_GT, mask, loss_fn_vgg, niqe_metric)
            soft_metrics = compute_metrics(soft_out, Y_GT, mask, loss_fn_vgg, niqe_metric)

            all_results.append({
                "Image": img_name,
                "Category": cat,
                "Ratio": round(damage_ratio, 4),
                "Fusion": "HardBlend",
                **hard_metrics
            })
            all_results.append({
                "Image": img_name,
                "Category": cat,
                "Ratio": round(damage_ratio, 4),
                "Fusion": "SoftBlend",
                **soft_metrics
            })

            # save images
            hard_path = os.path.join(
                save_hard_subdir,
                f"{img_name}_{cat.replace('%', '')}_ratio{damage_ratio:.2f}_HardBlend.png"
            )
            soft_path = os.path.join(
                save_soft_subdir,
                f"{img_name}_{cat.replace('%', '')}_ratio{damage_ratio:.2f}_SoftBlend.png"
            )
            raw_path = os.path.join(save_raw_subdir, img_name + "_raw.png")
            gt_path = os.path.join(save_raw_subdir, img_name + "_r.png")

            util.save_img(util.tensor2img(hard_out.squeeze(0)), hard_path)
            util.save_img(util.tensor2img(soft_out.squeeze(0)), soft_path)
            util.save_img(util.tensor2img(SR_img.squeeze(0)), raw_path)
            util.save_img(util.tensor2img(Y_GT.squeeze(0)), gt_path)

            if (g + 1) % 10 == 0:
                logger.info(
                    f"[{dataset_name}] ✅ 已完成 {g + 1} 张 | "
                    f"Hard G-PSNR: {hard_metrics['Global_PSNR']:.2f} | "
                    f"Soft G-PSNR: {soft_metrics['Global_PSNR']:.2f}"
                )

        if len(all_results) > 0:
            df_all = pd.DataFrame(all_results)

            df_hard = df_all[df_all["Fusion"] == "HardBlend"].copy()
            df_soft = df_all[df_all["Fusion"] == "SoftBlend"].copy()

            hard_summary = summarize_results(df_hard, "HardBlend")
            soft_summary = summarize_results(df_soft, "SoftBlend")

            df_final = pd.concat([
                df_all,
                pd.DataFrame(hard_summary),
                pd.DataFrame(soft_summary)
            ], ignore_index=True)

            df_final.to_csv(csv_path, index=False)
            logger.info(f"📁 {dataset_name} 详细消融报告保存在: {csv_path}")
        else:
            logger.error(f"❌ {dataset_name} 没有成功评测任何图片！")


if __name__ == "__main__":
    main()
