#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_ablation_experiments.py

Batch runner for inference-time ablations.

This script assumes your test_combined_final.py has been integrated with
ablation_prompt_utils.py and supports these CLI arguments:
--ablation_name
--prompt_json
--prompt_mode
--disable_prompt_adapter
--route_mode
--prompt_injection
--adapter_variant
--prompt_scale
--max_images

Example:
python run_ablation_experiments.py \
    --test_script test_combined_final.py \
    --opt test_combined_routeA.yml \
    --prompt_json prompt_format_ablation/vlm_prompts_for_ablation.json \
    --max_images -1
"""

import argparse
import subprocess
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_script", type=str, default="test_combined_final.py")
    parser.add_argument("--opt", type=str, required=True)
    parser.add_argument("--prompt_json", type=str, required=True)
    parser.add_argument("--python", type=str, default="python")
    parser.add_argument("--max_images", type=int, default=-1)
    parser.add_argument("--dry_run", action="store_true")
    return parser.parse_args()


def build_commands(args):
    base = [
        args.python,
        args.test_script,
        "-opt",
        args.opt,
        "--prompt_json",
        args.prompt_json,
        "--max_images",
        str(args.max_images),
    ]

    experiments = [
        ("full", ["--prompt_mode", "full_structured"]),
        ("no_prompt_adapter", ["--disable_prompt_adapter", "--prompt_mode", "no_prompt"]),
        ("empty_prompt", ["--prompt_mode", "no_prompt"]),
        ("generic_prompt", ["--prompt_mode", "generic_prompt"]),
        ("tag_prompt", ["--prompt_mode", "tag_prompt"]),
        ("random_prompt", ["--prompt_mode", "random_prompt"]),
        ("wrong_degradation", ["--prompt_mode", "wrong_degradation"]),
        ("content_only", ["--prompt_mode", "content_only"]),
        ("degradation_only", ["--prompt_mode", "degradation_only"]),
        ("content_degradation", ["--prompt_mode", "content_degradation"]),

        # Inference-time routing diagnostics.
        # For the formal paper table, retrain adapter-only variants for w/o routing and hole-only routing.
        ("infer_global_route", ["--prompt_mode", "full_structured", "--route_mode", "global"]),
        ("infer_hole_only_route", ["--prompt_mode", "full_structured", "--route_mode", "hole_only"]),
        ("infer_boundary_only_route", ["--prompt_mode", "full_structured", "--route_mode", "boundary_only"]),
        ("infer_no_route", ["--prompt_mode", "full_structured", "--route_mode", "none"]),
    ]

    commands = []
    for name, extra in experiments:
        cmd = base + ["--ablation_name", name] + extra
        commands.append((name, cmd))
    return commands


def main():
    args = parse_args()

    if not Path(args.test_script).exists():
        raise FileNotFoundError(f"test_script not found: {args.test_script}")
    if not Path(args.prompt_json).exists():
        raise FileNotFoundError(f"prompt_json not found: {args.prompt_json}")

    commands = build_commands(args)

    for name, cmd in commands:
        print("=" * 100)
        print(f"[RUN] {name}")
        print(" ".join(cmd))
        if not args.dry_run:
            subprocess.run(cmd, check=True)

    print("[DONE] All ablation runs finished.")


if __name__ == "__main__":
    main()
