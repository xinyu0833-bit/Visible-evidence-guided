#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ablation_prompt_utils.py

Utilities used by test_combined_final.py and run_ablation_experiments.py.
"""

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional


PROMPT_MODE_CHOICES = [
    "full_structured",
    "no_prompt",
    "empty",
    "generic_prompt",
    "generic",
    "tag_prompt",
    "random_prompt",
    "mismatch",
    "wrong_degradation",
    "content_only",
    "degradation_only",
    "content_degradation",
]


def add_ablation_arguments(parser: argparse.ArgumentParser):
    parser.add_argument("--ablation_name", default="full", type=str)
    parser.add_argument("--prompt_json", default=None, type=str)
    parser.add_argument("--prompt_mode", default="full_structured", choices=PROMPT_MODE_CHOICES)
    parser.add_argument("--disable_prompt_adapter", action="store_true")
    parser.add_argument("--route_mode", default="keep",
                        choices=["keep", "none", "global", "hole_only", "boundary_only", "hole_boundary"])
    parser.add_argument("--prompt_injection", default="keep",
                        choices=["keep", "full", "mid_only", "up_only"])
    parser.add_argument("--adapter_variant", default="keep",
                        choices=["keep", "film_attn", "film_only", "attn_only", "none"])
    parser.add_argument("--prompt_scale", default=None, type=float)
    parser.add_argument("--max_images", default=-1, type=int)
    return parser


def load_prompt_database(prompt_json: Optional[str]) -> Dict[str, Any]:
    if not prompt_json:
        return {}
    p = Path(prompt_json)
    if not p.exists():
        raise FileNotFoundError(f"Prompt JSON not found: {prompt_json}")
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def unwrap_model(obj):
    return obj.module if hasattr(obj, "module") else obj


def get_network_from_model(model):
    if hasattr(model, "model"):
        return unwrap_model(model.model)
    if hasattr(model, "netG"):
        return unwrap_model(model.netG)
    if hasattr(model, "net_g"):
        return unwrap_model(model.net_g)
    return unwrap_model(model)


def apply_ablation_to_model(model, args):
    """
    Apply inference-time ablation switches. This does not modify checkpoint files.
    """
    net = get_network_from_model(model)

    if getattr(args, "disable_prompt_adapter", False):
        if hasattr(net, "use_prompt_adapter"):
            net.use_prompt_adapter = False
        for m in net.modules():
            if hasattr(m, "adapter_variant"):
                m.adapter_variant = "none"

    if getattr(args, "prompt_injection", "keep") != "keep":
        if hasattr(net, "prompt_injection"):
            net.prompt_injection = args.prompt_injection

    if getattr(args, "prompt_scale", None) is not None:
        if hasattr(net, "prompt_scale"):
            net.prompt_scale = float(args.prompt_scale)
        for m in net.modules():
            if hasattr(m, "prompt_scale"):
                m.prompt_scale = float(args.prompt_scale)

    for m in net.modules():
        if hasattr(m, "route_mode") and getattr(args, "route_mode", "keep") != "keep":
            m.route_mode = args.route_mode
        if hasattr(m, "adapter_variant") and getattr(args, "adapter_variant", "keep") != "keep":
            m.adapter_variant = args.adapter_variant

    return model


def normalize_image_id(image_id: str) -> str:
    stem = Path(str(image_id)).stem
    for suffix in ["_masked", "_mask", "_gt", "_GT"]:
        if stem.endswith(suffix):
            stem = stem[:-len(suffix)]
    return stem


def get_item(prompt_db: Dict[str, Any], image_id: str) -> Any:
    image_id = normalize_image_id(image_id)
    if image_id in prompt_db:
        return prompt_db[image_id]
    for suffix in [".jpg", ".png", ".jpeg"]:
        if image_id + suffix in prompt_db:
            return prompt_db[image_id + suffix]
    return None


def raw_prompt_to_text(raw: Any) -> str:
    if raw is None:
        return "A damaged Dunhuang mural with mineral pigments and line-drawing structures."

    if isinstance(raw, str):
        return raw

    if isinstance(raw, dict):
        if "prompts_for_ablation" in raw and isinstance(raw["prompts_for_ablation"], dict):
            prompts = raw["prompts_for_ablation"]
            return prompts.get("full_structured") or prompts.get("generic_prompt") or ""

        for key in ["final_prompt", "prompt", "text", "caption", "description"]:
            if raw.get(key):
                return str(raw[key])

        if "structured" in raw:
            return raw_prompt_to_text(raw["structured"])

        parts = []
        cs = raw.get("content_style", {})
        dg = raw.get("degradation", {})
        if isinstance(cs, dict):
            for key in ["objects", "palette", "line_style", "composition"]:
                v = cs.get(key)
                if isinstance(v, list):
                    parts.extend([str(x) for x in v])
                elif v:
                    parts.append(str(v))
        if isinstance(dg, dict):
            for key in ["defect_types", "severity", "location", "boundary_condition"]:
                v = dg.get(key)
                if isinstance(v, list):
                    parts.extend([str(x) for x in v])
                elif v:
                    parts.append(str(v))
        if raw.get("restoration_constraint"):
            parts.append(str(raw["restoration_constraint"]))
        if parts:
            return "; ".join(parts)

    return str(raw)


def select_prompt(
    prompt_db: Dict[str, Any],
    image_id: str,
    prompt_mode: str = "full_structured",
    index: int = 0,
    default_full: str = "A damaged Dunhuang mural with mineral pigments and line-drawing structures.",
) -> str:
    item = get_item(prompt_db, image_id)

    if prompt_mode in ["no_prompt", "empty"]:
        return ""

    if prompt_mode in ["generic", "generic_prompt"]:
        return "A damaged Dunhuang mural."

    if item is None:
        return default_full

    if isinstance(item, dict) and "prompts_for_ablation" in item:
        prompts = item.get("prompts_for_ablation", {})
        if prompt_mode == "mismatch":
            return str(prompts.get("random_prompt") or prompts.get("generic_prompt") or default_full)
        if prompt_mode in prompts:
            return str(prompts[prompt_mode])
        return str(prompts.get("full_structured") or prompts.get("generic_prompt") or default_full)

    if prompt_mode == "mismatch":
        keys = list(prompt_db.keys())
        if len(keys) > 1:
            other_key = keys[(index + 1) % len(keys)]
            return raw_prompt_to_text(prompt_db.get(other_key))
        return default_full

    return raw_prompt_to_text(item)
