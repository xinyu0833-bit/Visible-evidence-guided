#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import re
from pathlib import Path

import pandas as pd


PROMPT_PREFIX = "test_prompt_ablation_hard_"


def norm_name(s):
    s = str(s).strip().lower()
    s = s.replace("%", "pct")
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def infer_prompt_mode(folder):
    name = Path(folder).name
    if name.startswith(PROMPT_PREFIX):
        return name[len(PROMPT_PREFIX):]
    return name


def to_float(v):
    try:
        x = pd.to_numeric(v, errors="coerce")
        if pd.isna(x):
            return None
        return float(x)
    except Exception:
        return None


def find_metrics_csv(prompt_dir):
    prompt_dir = Path(prompt_dir)

    exact = (
        prompt_dir
        / "DUNHUANG_Test_PromptAblation_Results"
        / "DUNHUANG_Test_full_quick_metrics.csv"
    )
    if exact.exists():
        return exact

    candidates = sorted(prompt_dir.rglob("*quick_metrics*.csv"))
    if candidates:
        return candidates[0]

    candidates = sorted(prompt_dir.rglob("*.csv"))
    if candidates:
        return candidates[0]

    return None


def pick_final_row(df):
    if len(df) == 1:
        return df.iloc[0]

    preferred_cols = [
        "category",
        "subset",
        "split",
        "region",
        "mask_category",
        "type",
        "summary",
    ]

    for c in df.columns:
        nc = norm_name(c)
        if nc in preferred_cols or any(k in nc for k in preferred_cols):
            vals = df[c].astype(str).str.lower()
            mask = (
                vals.eq("all")
                | vals.eq("final")
                | vals.str.contains("all", na=False)
                | vals.str.contains("final", na=False)
                | vals.str.contains("summary", na=False)
                | vals.str.contains("mean", na=False)
            )
            if mask.any():
                return df[mask].iloc[0]

    return df.iloc[0]


def clean_hard_key(col):
    key = norm_name(col)

    key = key.replace("hardblend", "hard")
    key = key.replace("hard_blend", "hard")
    key = key.replace("hardfusion", "hard")
    key = key.replace("hard_fusion", "hard")

    if key == "hard":
        return key

    if key.startswith("hard_"):
        return key

    if key.startswith("hard"):
        key = "hard_" + key[len("hard"):].lstrip("_")
        return key

    return "hard_" + key


def extract_hard_metrics(csv_path):
    df = pd.read_csv(csv_path)
    df.columns = [str(c).strip() for c in df.columns]

    metrics = {}
    note = ""

    method_like_cols = []
    for c in df.columns:
        nc = norm_name(c)
        if any(k in nc for k in ["method", "fusion", "blend", "image_type", "mode", "result_type", "name"]):
            method_like_cols.append(c)

    hard_mask = pd.Series(False, index=df.index)

    for c in method_like_cols:
        vals = df[c].astype(str).str.lower()
        hard_mask = hard_mask | vals.str.contains("hard", na=False)

    # Case 1: long format, rows contain Method/Type = Hard
    if hard_mask.any():
        hard_df = df[hard_mask].copy()
        row = pick_final_row(hard_df)
        note = "long_format_hard_row"

        for c in df.columns:
            if c in method_like_cols:
                continue

            v = to_float(row[c])
            if v is not None:
                metrics[clean_hard_key(c)] = v

        return metrics, note

    # Case 2: wide format, columns contain HardBlend / HardFusion
    row = pick_final_row(df)
    note = "wide_format_hard_columns"

    for c in df.columns:
        nc = norm_name(c)
        v = to_float(row[c])
        if v is None:
            continue

        if "hard" in nc:
            metrics[clean_hard_key(c)] = v
        elif nc in ["n_eval", "n_missing", "count", "num_images", "n_images"]:
            metrics[nc] = v

    # Case 3: fallback, csv itself is already hard metrics
    if not metrics:
        note = "fallback_numeric_columns"
        for c in df.columns:
            nc = norm_name(c)
            v = to_float(row[c])
            if v is not None:
                if nc in ["n_eval", "n_missing", "count", "num_images", "n_images"]:
                    metrics[nc] = v
                else:
                    metrics["hard_" + nc] = v

    return metrics, note


def choose_rank_column(df):
    high_better_priority = [
        "hard_hole_psnr",
        "hard_h_psnr",
        "hard_psnr_hole",
        "hard_hole_region_psnr",
        "hard_boundary_psnr",
        "hard_b_psnr",
        "hard_global_psnr",
        "hard_g_psnr",
        "hard_psnr_all",
        "hard_all_psnr",
    ]

    low_better_priority = [
        "hard_lpips",
        "hard_hole_lpips",
        "hard_mae_hole",
        "hard_hole_mae",
        "hard_mse_hole",
        "hard_hole_mse",
        "hard_niqe",
    ]

    for c in high_better_priority:
        if c in df.columns:
            return c, False

    for c in df.columns:
        nc = norm_name(c)
        if "hole" in nc and "psnr" in nc:
            return c, False

    for c in df.columns:
        nc = norm_name(c)
        if "psnr" in nc:
            return c, False

    for c in low_better_priority:
        if c in df.columns:
            return c, True

    for c in df.columns:
        nc = norm_name(c)
        if any(k in nc for k in ["lpips", "mae", "mse", "rmse", "niqe"]):
            return c, True

    return None, False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root",
        type=str,
        default="/root/autodl-tmp/StrDiffusion_Official/train/results/inpainting",
        help="Root folder containing test_prompt_ablation_hard_* folders.",
    )
    parser.add_argument(
        "--pattern",
        type=str,
        default="test_prompt_ablation_hard_*",
        help="Prompt ablation folder pattern.",
    )
    parser.add_argument(
        "--output_csv",
        type=str,
        default="/root/autodl-tmp/StrDiffusion_Official/train/results/inpainting/prompt_ablation_hard_final_sorted.csv",
        help="Output sorted comparison csv.",
    )
    args = parser.parse_args()

    root = Path(args.root)
    prompt_dirs = sorted([p for p in root.glob(args.pattern) if p.is_dir()])

    if not prompt_dirs:
        raise SystemExit(f"No prompt folders found under: {root} with pattern: {args.pattern}")

    rows = []

    for d in prompt_dirs:
        prompt_mode = infer_prompt_mode(d)
        csv_path = find_metrics_csv(d)

        if csv_path is None:
            rows.append({
                "prompt_mode": prompt_mode,
                "status": "missing_csv",
                "source_dir": str(d),
            })
            continue

        try:
            metrics, note = extract_hard_metrics(csv_path)
            row = {
                "prompt_mode": prompt_mode,
                "status": "ok",
                "extract_note": note,
                "csv_path": str(csv_path),
                "source_dir": str(d),
            }
            row.update(metrics)
            rows.append(row)
        except Exception as e:
            rows.append({
                "prompt_mode": prompt_mode,
                "status": "error",
                "error": repr(e),
                "csv_path": str(csv_path),
                "source_dir": str(d),
            })

    out = pd.DataFrame(rows)

    rank_col, ascending = choose_rank_column(out)
    if rank_col is not None:
        out = out.sort_values(rank_col, ascending=ascending).reset_index(drop=True)
        out.insert(0, "rank", range(1, len(out) + 1))
        out.insert(1, "rank_metric", rank_col)
        out.insert(2, "rank_order", "ascending" if ascending else "descending")
    else:
        out.insert(0, "rank", range(1, len(out) + 1))
        out.insert(1, "rank_metric", "none_found")
        out.insert(2, "rank_order", "none")

    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_csv, index=False, encoding="utf-8-sig")

    print("=" * 100)
    print("Saved sorted comparison CSV:")
    print(output_csv)
    print("=" * 100)

    show_cols = [
        "rank",
        "prompt_mode",
        "status",
        "rank_metric",
        "hard_hole_psnr",
        "hard_global_psnr",
        "hard_hole_ssim",
        "hard_global_ssim",
        "hard_lpips",
        "n_eval",
    ]
    show_cols = [c for c in show_cols if c in out.columns]
    print(out[show_cols].to_string(index=False))


if __name__ == "__main__":
    main()
