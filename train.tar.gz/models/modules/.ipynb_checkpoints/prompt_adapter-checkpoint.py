import torch
import torch.nn as nn
import torch.nn.functional as F


def build_prompt_route(
    mask: torch.Tensor,
    target_size,
    route_mode: str = "hole_boundary",
    boundary_weight: float = 0.5,
    temperature: float = 1.0,
    kernel_size: int = 5,
) -> torch.Tensor:
    """
    mask: [B,1,H,W], 1=known region, 0=hole region.
    route_mode:
      - none / global: all-one route, global text injection
      - hole_only: only hole region
      - boundary_only: only boundary band
      - hole_boundary: hole + boundary
    """
    b = mask.shape[0]

    if route_mode in ["none", "global"]:
        return torch.ones(
            b, 1, target_size[0], target_size[1],
            device=mask.device,
            dtype=mask.dtype,
        )

    hole = 1.0 - mask.float()
    hole_down = F.interpolate(hole, size=target_size, mode="area")

    pad = kernel_size // 2
    dilated_hole = F.max_pool2d(
        hole,
        kernel_size=kernel_size,
        stride=1,
        padding=pad,
    )
    boundary = (dilated_hole - hole).clamp(0.0, 1.0)
    boundary_down = F.interpolate(boundary, size=target_size, mode="area")

    if route_mode == "hole_only":
        route = hole_down
    elif route_mode == "boundary_only":
        route = boundary_down
    elif route_mode == "hole_boundary":
        route = (hole_down + boundary_weight * boundary_down).clamp(0.0, 1.0)
    else:
        raise ValueError(f"Unknown route_mode: {route_mode}")

    if temperature is not None and temperature > 1.0:
        route = torch.sigmoid((route - 0.5) * float(temperature))

    return route


class PromptAdapter(nn.Module):
    def __init__(
        self,
        query_dim: int,
        context_dim: int = 768,
        heads: int = 8,
        route_boundary_weight: float = 0.5,
        route_temperature: float = 1.0,
        route_mode: str = "hole_boundary",
        route_kernel_size: int = 5,
        adapter_variant: str = "film_attn",
    ):
        super().__init__()

        if query_dim % heads != 0:
            heads = 4 if query_dim % 4 == 0 else 1

        self.route_boundary_weight = route_boundary_weight
        self.route_temperature = route_temperature
        self.route_mode = route_mode
        self.route_kernel_size = route_kernel_size
        self.adapter_variant = adapter_variant

        self.norm = self._make_group_norm(query_dim)
        self.text_proj = nn.Linear(context_dim, query_dim)

        self.to_gamma_beta = nn.Sequential(
            nn.Linear(query_dim, query_dim * 2),
            nn.SiLU(),
            nn.Linear(query_dim * 2, query_dim * 2),
        )

        self.cross_attn = nn.MultiheadAttention(
            embed_dim=query_dim,
            num_heads=heads,
            batch_first=True,
        )

        self.out_proj = nn.Conv2d(query_dim, query_dim, kernel_size=1)

        self.alpha_film = nn.Parameter(torch.tensor(1e-3))
        self.alpha_attn = nn.Parameter(torch.tensor(1e-3))

        nn.init.zeros_(self.out_proj.weight)
        nn.init.zeros_(self.out_proj.bias)

    @staticmethod
    def _make_group_norm(num_channels: int) -> nn.GroupNorm:
        for groups in (32, 16, 8, 4, 2):
            if num_channels >= groups and num_channels % groups == 0:
                return nn.GroupNorm(groups, num_channels)
        return nn.GroupNorm(1, num_channels)

    def forward(
        self,
        x_img: torch.Tensor,
        x_text: torch.Tensor,
        mask: torch.Tensor = None,
        prompt_scale: float = 1.0,
    ) -> torch.Tensor:
        if self.adapter_variant == "none":
            return torch.zeros_like(x_img)

        b, c, h, w = x_img.shape

        if x_text.shape[0] == 1 and b > 1:
            x_text = x_text.expand(b, -1, -1)

        x_norm = self.norm(x_img)
        text_tokens = self.text_proj(x_text)

        text_pooled = text_tokens.mean(dim=1)
        gamma, beta = self.to_gamma_beta(text_pooled).chunk(2, dim=-1)
        gamma = gamma.view(b, c, 1, 1)
        beta = beta.view(b, c, 1, 1)
        film_residual = x_norm * gamma + beta

        img_tokens = x_norm.flatten(2).transpose(1, 2)
        attn_tokens, _ = self.cross_attn(
            query=img_tokens,
            key=text_tokens,
            value=text_tokens,
            need_weights=False,
        )
        attn_residual = attn_tokens.transpose(1, 2).view(b, c, h, w)

        if self.adapter_variant == "film_only":
            residual = self.alpha_film * film_residual
        elif self.adapter_variant == "attn_only":
            residual = self.alpha_attn * attn_residual
        elif self.adapter_variant == "film_attn":
            residual = self.alpha_film * film_residual + self.alpha_attn * attn_residual
        else:
            raise ValueError(f"Unknown adapter_variant: {self.adapter_variant}")

        residual = self.out_proj(residual)

        if mask is not None:
            route = build_prompt_route(
                mask=mask,
                target_size=(h, w),
                route_mode=self.route_mode,
                boundary_weight=self.route_boundary_weight,
                temperature=self.route_temperature,
                kernel_size=self.route_kernel_size,
            )
            residual = residual * route

        return residual * float(prompt_scale)
