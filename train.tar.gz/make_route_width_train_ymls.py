#!/usr/bin/env python3
from pathlib import Path
import copy
import yaml

ROOT = Path("/root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting")
SRC = ROOT / "options/train/parameter_matched/PM_Correct_OfficialInit_20K.yml"
OUT = ROOT / "options/train/boundary_sensitivity_route_only"
KERNELS = [1, 3, 5, 7, 9]

assert SRC.exists(), SRC
base = yaml.safe_load(SRC.read_text(encoding="utf-8"))
OUT.mkdir(parents=True, exist_ok=True)

def get(cfg, keys):
    cur = cfg
    for k in keys:
        cur = cur[k]
    return cur

for k in KERNELS:
    cfg = copy.deepcopy(base)
    radius = (k - 1) // 2
    cfg["name"] = f"PMCorrect_RouteK{k}_R{radius}px_20K"

    cfg["network_G"]["setting"]["route_kernel_size"] = int(k)

    # PRIMARY sensitivity isolates routing width.
    # Boundary supervision stays identical to baseline.
    assert int(cfg["train"]["boundary_kernel_size"]) == 5
    assert float(cfg["train"]["lambda_boundary"]) == 2.0
    assert float(cfg["network_G"]["setting"]["route_boundary_weight"]) == 0.5
    assert float(cfg["network_G"]["setting"]["route_temperature"]) == 4.0
    assert cfg["network_G"]["setting"]["route_mode"] == "hole_boundary"

    out = OUT / f"PMCorrect_RouteK{k}_20K.yml"
    out.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    print(out)

print("\nPrimary sweep created: route_kernel_size = 1/3/5/7/9")
print("boundary_kernel_size remains fixed at 5 for all variants.")
