#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting}"
OUT="${2:-/root/autodl-tmp/boundary_code_audit.md}"

cd "$ROOT"

python - "$ROOT" "$OUT" <<'PY'
from pathlib import Path
import sys, re, datetime

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()

patterns = [
    r"route_kernel_size",
    r"boundary_kernel_size",
    r"route_boundary_weight",
    r"lambda_boundary",
    r"route_mode",
    r"hole_boundary",
    r"make_boundary_mask",
    r"boundary_mask",
    r"known.?side",
    r"dilat",
    r"max_pool2d",
    r"conv2d",
    r"kernel_size",
    r"outside_boundary",
    r"inside_boundary",
    r"eroded_known",
]

rx = re.compile("|".join(f"(?:{p})" for p in patterns), re.I)

# Skip bulky/irrelevant dirs.
skip_parts = {
    ".git", "__pycache__", ".ipynb_checkpoints",
    "experiments", "results", "log", "logs",
}

extensions = {".py", ".yml", ".yaml"}

files = []
for p in root.rglob("*"):
    if not p.is_file() or p.suffix.lower() not in extensions:
        continue
    if any(part in skip_parts for part in p.parts):
        continue
    files.append(p)

matches = []
for p in sorted(files):
    try:
        lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        continue
    hit_lines = [i for i, line in enumerate(lines, 1) if rx.search(line)]
    if not hit_lines:
        continue
    # Merge hit windows of +/- 10 lines.
    windows = []
    for n in hit_lines:
        a, b = max(1, n-10), min(len(lines), n+10)
        if windows and a <= windows[-1][1] + 1:
            windows[-1] = (windows[-1][0], max(windows[-1][1], b))
        else:
            windows.append((a,b))
    matches.append((p, lines, windows, hit_lines))

cfg = root / "options/train/parameter_matched/PM_Correct_OfficialInit_20K.yml"

with out.open("w", encoding="utf-8") as f:
    f.write("# Boundary-band code audit\n\n")
    f.write(f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}\n")
    f.write(f"- Root: `{root}`\n")
    f.write(f"- Baseline config: `{cfg}`\n\n")

    f.write("## 1. Baseline configuration\n\n")
    if cfg.exists():
        lines = cfg.read_text(encoding="utf-8", errors="ignore").splitlines()
        for i, line in enumerate(lines,1):
            if re.search(r"route_|boundary|kernel|lambda_boundary|seed|manual_seed|batch_size|lr_G|lr_steps|niter|pretrain_model_G|prompt_path", line, re.I):
                f.write(f"- L{i}: `{line.rstrip()}`\n")
    else:
        f.write("**Baseline config not found.**\n")
    f.write("\n")

    f.write("## 2. Relevant source locations\n\n")
    for p, lines, windows, hit_lines in matches:
        rel = p.relative_to(root)
        f.write(f"### `{rel}`\n\n")
        f.write(f"Matched lines: {', '.join(map(str, hit_lines))}\n\n")
        for a,b in windows:
            f.write(f"Context L{a}-L{b}:\n\n```python\n")
            for i in range(a,b+1):
                f.write(f"{i:5d}: {lines[i-1]}\n")
            f.write("```\n\n")

    f.write("## 3. Questions this audit must resolve\n\n")
    qs = [
        "Where is `route_kernel_size` read and passed into the train-time routing mask?",
        "Where is `boundary_kernel_size` read and passed into the boundary loss?",
        "Do routing and boundary loss use the same dilation definition?",
        "Does an odd kernel `k` produce an effective one-sided boundary width `(k-1)/2` pixels at 256x256?",
        "Does `kernel_size=1` yield an empty boundary without NaN in the boundary loss?",
        "Is the routed band on the known side, hole side, or both?",
        "Does the test path use the same routing implementation as training?",
        "Are `route_boundary_weight=0.5` and `lambda_boundary=2.0` independent of kernel size?",
    ]
    for q in qs:
        f.write(f"- {q}\n")

    f.write("\n## 4. Candidate sensitivity plan (pending code verification)\n\n")
    f.write("| Kernel size | Effective radius if odd-kernel dilation | Role |\n")
    f.write("|---:|---:|---|\n")
    for k in [1,3,5,7,9]:
        f.write(f"| {k} | {(k-1)//2} px | {'hole-only / no boundary' if k==1 else ('current baseline' if k==5 else 'sensitivity control')} |\n")
    f.write("\n")
    f.write("Keep all other settings fixed: `route_boundary_weight=0.5`, `lambda_boundary=2.0`, seed, data, prompts, optimizer, initialization, and training budget.\n")

print(out)
PY

echo
echo "Generated audit:"
ls -lh "$OUT"
echo
echo "Upload this markdown file to ChatGPT:"
echo "$OUT"
