import os

os.environ["USE_TORCH"] = "1"
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_NO_FLAX"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import argparse
import logging
import random
import json
import glob
import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

import options as option
from models import create_model
from data import create_dataloader, create_dataset
import utils as util

from PIL import Image
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from transformers import CLIPTextModel, CLIPTokenizer
from skimage.feature import canny
from skimage.metrics import peak_signal_noise_ratio as psnr_metric
from skimage.metrics import structural_similarity as ssim_metric

import lpips

try:
    import pyiqa
    HAS_NIQE = True
except ImportError:
    HAS_NIQE = False
    print("Warning: pyiqa is not installed. NIQE will be set to 0.")


class OutputWrapper(torch.nn.Module):
    """
    Ours wrapper for testing hard-blend ablations.

    mask convention:
        mask = 1 known region
        mask = 0 hole region
    """
    def __init__(self, net):
        super().__init__()
        self.net = net
        self.current_mask = None
        self.S_GT = None
        self.S_LQ = None
        self.S_sde = None

    def forward(self, xt, cond, time, **kwargs):
        if self.current_mask is not None:
            kwargs["mask"] = self.current_mask

        if self.S_sde is not None and self.S_GT is not None and self.S_LQ is not None:
            if isinstance(time, (int, float)):
                t_tensor = torch.tensor([int(time)], device=xt.device).long()
            else:
                t_tensor = time.long().squeeze()
                if t_tensor.dim() == 0:
                    t_tensor = t_tensor.unsqueeze(0)

            self.S_sde.set_mu(self.S_LQ * self.current_mask)

            S_mu_bar = self.S_sde.mu_bar(self.S_GT, t_tensor)
            S_sigma_bar = self.S_sde.sigma_bar(t_tensor).view(-1, 1, 1, 1)

            S_noise = torch.randn_like(S_mu_bar)
            S_optimum = S_mu_bar + S_noise * S_sigma_bar
            kwargs["S"] = S_optimum

        out = self.net(xt, cond, time, **kwargs)
        if isinstance(out, tuple):
            return out[0]
        return out


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def ensure_4d(x):
    if x.dim() == 3:
        x = x.unsqueeze(0)
    if x.dim() != 4:
        raise ValueError(f"Expected 3D or 4D tensor, got shape: {tuple(x.shape)}")
    return x


def tensor_to_uint8_rgb(x):
    x = ensure_4d(x)
    arr = x[0].detach().float().cpu().clamp(0, 1).permute(1, 2, 0).numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    return arr


def save_tensor_rgb(x, path):
    arr = tensor_to_uint8_rgb(x)
    Image.fromarray(arr).save(path)


def save_gray_tensor(x, path):
    x = x.detach().float().cpu()
    if x.dim() == 4:
        x = x[0, 0]
    elif x.dim() == 3:
        x = x[0]
    elif x.dim() == 2:
        pass
    else:
        raise ValueError(f"Unsupported gray tensor shape: {tuple(x.shape)}")

    arr = x.clamp(0, 1).numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    Image.fromarray(arr, mode="L").save(path)


def read_mask_white_bg_black_hole(mask_path, image_size=256):
    """
    Current mask convention:
        white = known = 1
        black = hole  = 0
    """
    transform_mask = transforms.Compose([
        transforms.Resize((image_size, image_size), interpolation=InterpolationMode.NEAREST),
        transforms.ToTensor()
    ])

    mask_pil = Image.open(mask_path).convert("L")
    mask = transform_mask(mask_pil)
    mask = (mask > 0.5).float()
    return mask.unsqueeze(0)


def find_mask_for_image(img_path, mask_root):
    img_name = os.path.splitext(os.path.basename(img_path))[0]
    candidates = [
        f"{img_name}.jpg",
        f"{img_name}.png",
        f"{img_name}.jpeg",
        f"{img_name}_mask.jpg",
        f"{img_name}_mask.png",
        f"{img_name}_masked.jpg",
        f"{img_name}_masked.png",
    ]

    for name in candidates:
        p = os.path.join(mask_root, name)
        if os.path.exists(p):
            return p

    return None


def rgb_to_gray_tensor(rgb):
    rgb = ensure_4d(rgb).float().clamp(0, 1)
    r = rgb[:, 0:1]
    g = rgb[:, 1:2]
    b = rgb[:, 2:3]
    return 0.299 * r + 0.587 * g + 0.114 * b


def edge_from_gray_tensor(gray_tensor, sigma=2.0):
    gray_tensor = ensure_4d(gray_tensor)
    device = gray_tensor.device
    gray_np = gray_tensor.detach().cpu().numpy()

    edge_list = []
    for i in range(gray_np.shape[0]):
        g = gray_np[i, 0].astype(np.float32)
        edge = canny(g, sigma=sigma).astype(np.float32)
        edge_list.append(edge[None, :, :])

    edge_arr = np.stack(edge_list, axis=0)
    return torch.from_numpy(edge_arr).float().to(device)


def erode_mask(mask, kernel_size=5):
    """
    mask: [1,1,H,W], 1=known, 0=hole
    Return eroded known mask.
    """
    inv = 1.0 - mask
    eroded_known = 1.0 - F.max_pool2d(
        inv,
        kernel_size=kernel_size,
        stride=1,
        padding=kernel_size // 2
    )
    return eroded_known.clamp(0, 1)


def build_structure_inputs(real_gt_pil, Y_GT, mask, image_size, device, structure_mode, edge_sigma=2.0, erode_kernel=5):
    """
    structure_mode:
        official:
            X_GT = GT gray
            X_LQ = GT edge
        masked_recomputed:
            X_GT = gray(Y_GT * mask)
            X_LQ = canny(gray(Y_GT * mask))
        masked_edge_erode:
            X_GT = gray(Y_GT * mask)
            X_LQ = canny(gray(Y_GT * mask)) * eroded(mask)
        masked_edge_inpaint:
            X_GT = gray(Y_GT * mask)
            X_LQ = canny(gray(inpainted masked image)) * mask
    """
    resize_rgb = transforms.Resize((image_size, image_size), interpolation=InterpolationMode.BICUBIC)

    if structure_mode == "official":
        gray_pil = resize_rgb(real_gt_pil.convert("L"))
        X_GT = transforms.ToTensor()(gray_pil).unsqueeze(0).to(device)

        gray_np = np.array(gray_pil).astype(np.float32) / 255.0
        edge_np = canny(gray_np, sigma=edge_sigma).astype(np.float32)
        X_LQ = torch.from_numpy(edge_np).float().unsqueeze(0).unsqueeze(0).to(device)
        return X_GT, X_LQ

    observed = Y_GT * mask
    masked_gray = rgb_to_gray_tensor(observed)

    if structure_mode == "masked_recomputed":
        masked_edge = edge_from_gray_tensor(masked_gray, sigma=edge_sigma)
        return masked_gray, masked_edge

    if structure_mode == "masked_edge_erode":
        masked_edge = edge_from_gray_tensor(masked_gray, sigma=edge_sigma)
        eroded = erode_mask(mask, kernel_size=erode_kernel)
        masked_edge = masked_edge * eroded
        return masked_gray, masked_edge

    if structure_mode == "masked_edge_inpaint":
        gray_np = masked_gray[0, 0].detach().cpu().numpy().astype(np.float32)
        gray_u8 = np.clip(gray_np * 255.0, 0, 255).astype(np.uint8)

        hole_np = (1.0 - mask[0, 0].detach().cpu().numpy()).astype(np.uint8)
        hole_u8 = (hole_np * 255).astype(np.uint8)

        filled = cv2.inpaint(gray_u8, hole_u8, 3, cv2.INPAINT_TELEA)
        filled_f32 = filled.astype(np.float32) / 255.0

        edge_np = canny(filled_f32, sigma=edge_sigma).astype(np.float32)
        X_LQ = torch.from_numpy(edge_np).float().unsqueeze(0).unsqueeze(0).to(device)
        X_LQ = X_LQ * mask
        return masked_gray, X_LQ

    raise ValueError(f"Unknown structure_mode: {structure_mode}")


def make_boundary_mask(mask, kernel_size=5, boundary_side="hole"):
    """
    mask:
        [1,1,H,W], 1=known, 0=hole

    boundary_side:
        hole  : inner boundary inside hole
        known : outside boundary in known region
        both  : union
    """
    mask = ensure_4d(mask).float()
    hole = 1.0 - mask

    dilated_hole = F.max_pool2d(
        hole,
        kernel_size=kernel_size,
        stride=1,
        padding=kernel_size // 2
    )

    eroded_hole = 1.0 - F.max_pool2d(
        1.0 - hole,
        kernel_size=kernel_size,
        stride=1,
        padding=kernel_size // 2
    )

    outside_boundary = (dilated_hole - hole).clamp(0, 1)
    inside_boundary = (hole - eroded_hole).clamp(0, 1)

    if boundary_side == "hole":
        return inside_boundary
    if boundary_side == "known":
        return outside_boundary
    if boundary_side == "both":
        return ((inside_boundary + outside_boundary) > 0).float()

    raise ValueError(f"Unknown boundary_side: {boundary_side}")


def masked_psnr(pred_rgb, gt_rgb, region_mask_1c):
    region_3c = np.expand_dims(region_mask_1c, axis=-1).repeat(3, axis=-1)
    denom = np.sum(region_3c) + 1e-8
    mse = np.sum(((pred_rgb - gt_rgb) ** 2) * region_3c) / denom
    if mse <= 0:
        return 99.99
    return 10.0 * np.log10(1.0 / mse)


def masked_mae(pred_rgb, gt_rgb, region_mask_1c):
    region_3c = np.expand_dims(region_mask_1c, axis=-1).repeat(3, axis=-1)
    denom = np.sum(region_3c) + 1e-8
    return np.sum(np.abs(pred_rgb - gt_rgb) * region_3c) / denom


def masked_ssim_from_map(ssim_map, region_mask_1c):
    ssim_gray = np.mean(ssim_map, axis=2)
    return np.sum(ssim_gray * region_mask_1c) / (np.sum(region_mask_1c) + 1e-8)


def boundary_edge_f1(pred_rgb, gt_rgb, boundary_mask_1c, sigma=2.0):
    pred_gray = (
        0.299 * pred_rgb[:, :, 0] +
        0.587 * pred_rgb[:, :, 1] +
        0.114 * pred_rgb[:, :, 2]
    )
    gt_gray = (
        0.299 * gt_rgb[:, :, 0] +
        0.587 * gt_rgb[:, :, 1] +
        0.114 * gt_rgb[:, :, 2]
    )

    pred_edge = canny(pred_gray, sigma=sigma).astype(np.float32)
    gt_edge = canny(gt_gray, sigma=sigma).astype(np.float32)

    region = (boundary_mask_1c > 0.5).astype(np.float32)
    pred_edge = pred_edge * region
    gt_edge = gt_edge * region

    tp = np.sum((pred_edge > 0.5) & (gt_edge > 0.5))
    fp = np.sum((pred_edge > 0.5) & (gt_edge <= 0.5))
    fn = np.sum((pred_edge <= 0.5) & (gt_edge > 0.5))

    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2.0 * precision * recall / (precision + recall + 1e-8)

    return float(precision), float(recall), float(f1)


def compute_all_metrics(pred_tensor, gt_tensor, mask_tensor, boundary_tensor, lpips_fn, niqe_metric=None, edge_sigma=2.0):
    pred_tensor = ensure_4d(pred_tensor).detach().float().clamp(0, 1)
    gt_tensor = ensure_4d(gt_tensor).detach().float().clamp(0, 1)
    mask_tensor = ensure_4d(mask_tensor).detach().float()
    boundary_tensor = ensure_4d(boundary_tensor).detach().float()

    pred_u8 = tensor_to_uint8_rgb(pred_tensor)
    gt_u8 = tensor_to_uint8_rgb(gt_tensor)

    pred_f32 = pred_u8.astype(np.float32) / 255.0
    gt_f32 = gt_u8.astype(np.float32) / 255.0

    mask_np = mask_tensor[0, 0].detach().cpu().numpy().astype(np.float32)
    hole_np = 1.0 - mask_np
    boundary_np = boundary_tensor[0, 0].detach().cpu().numpy().astype(np.float32)

    global_psnr = psnr_metric(gt_u8, pred_u8, data_range=255)

    _, ssim_map = ssim_metric(
        gt_f32,
        pred_f32,
        channel_axis=2,
        full=True,
        data_range=1.0
    )
    global_ssim = float(np.mean(ssim_map))

    hole_psnr = masked_psnr(pred_f32, gt_f32, hole_np)
    hole_ssim = masked_ssim_from_map(ssim_map, hole_np)
    hole_mae = masked_mae(pred_f32, gt_f32, hole_np)

    boundary_psnr = masked_psnr(pred_f32, gt_f32, boundary_np)
    boundary_ssim = masked_ssim_from_map(ssim_map, boundary_np)
    boundary_mae = masked_mae(pred_f32, gt_f32, boundary_np)

    edge_precision, edge_recall, edge_f1 = boundary_edge_f1(
        pred_f32,
        gt_f32,
        boundary_np,
        sigma=edge_sigma
    )

    with torch.no_grad():
        lpips_val = lpips_fn(
            pred_tensor * 2.0 - 1.0,
            gt_tensor * 2.0 - 1.0
        ).item()

        if niqe_metric is not None:
            niqe_val = niqe_metric(pred_tensor).item()
        else:
            niqe_val = 0.0

    return {
        "Global_PSNR": round(float(global_psnr), 4),
        "Global_SSIM": round(float(global_ssim), 4),
        "Hole_PSNR": round(float(hole_psnr), 4),
        "Hole_SSIM": round(float(hole_ssim), 4),
        "Hole_MAE": round(float(hole_mae), 6),
        "Boundary_PSNR": round(float(boundary_psnr), 4),
        "Boundary_SSIM": round(float(boundary_ssim), 4),
        "Boundary_MAE": round(float(boundary_mae), 6),
        "Boundary_Edge_Precision": round(float(edge_precision), 4),
        "Boundary_Edge_Recall": round(float(edge_recall), 4),
        "Boundary_Edge_F1": round(float(edge_f1), 4),
        "LPIPS": round(float(lpips_val), 4),
        "NIQE": round(float(niqe_val), 4),
    }


def load_prompt_dict(prompt_path):
    if prompt_path and os.path.exists(prompt_path):
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt_dict = json.load(f)
        print(f"Loaded prompt json: {prompt_path}, num={len(prompt_dict)}")
        return prompt_dict
    print("Warning: prompt json not found. Default prompt will be used.")
    return {}


def get_original_prompt(prompt_dict, img_name, img_base, default_prompt):
    raw_prompt = prompt_dict.get(img_name, prompt_dict.get(img_base, default_prompt))
    if isinstance(raw_prompt, dict):
        return raw_prompt.get("final_prompt", default_prompt)
    return str(raw_prompt)


def build_prompt_for_variant(variant, original_prompt, generic_prompt, mismatched_prompt):
    """
    Return:
        prompt_string or None

    None means do not pass prompt_context to reverse_sde.
    """
    if variant == "full":
        return original_prompt
    if variant == "no_prompt":
        return None
    if variant == "empty":
        return ""
    if variant == "generic":
        return generic_prompt
    if variant == "mismatched":
        return mismatched_prompt
    raise ValueError(f"Unknown ablation variant: {variant}")


def summarize_and_save(df, output_root):
    metric_cols = [
        "Global_PSNR", "Global_SSIM",
        "Hole_PSNR", "Hole_SSIM", "Hole_MAE",
        "Boundary_PSNR", "Boundary_SSIM", "Boundary_MAE",
        "Boundary_Edge_Precision", "Boundary_Edge_Recall", "Boundary_Edge_F1",
        "LPIPS", "NIQE"
    ]

    summary = (
        df.groupby(["Variant", "StructureMode", "Category"])[metric_cols]
        .mean()
        .reset_index()
    )
    summary_all = (
        df.groupby(["Variant", "StructureMode"])[metric_cols]
        .mean()
        .reset_index()
    )
    counts = (
        df.groupby(["Variant", "StructureMode", "Category"])
        .size()
        .reset_index(name="Count")
    )
    counts_all = (
        df.groupby(["Variant", "StructureMode"])
        .size()
        .reset_index(name="Count")
    )

    summary = counts.merge(summary, on=["Variant", "StructureMode", "Category"])
    summary_all = counts_all.merge(summary_all, on=["Variant", "StructureMode"])
    summary_all.insert(2, "Category", "ALL")

    final_summary = pd.concat([summary, summary_all], ignore_index=True)

    detail_csv = os.path.join(output_root, "ablation_detail.csv")
    summary_csv = os.path.join(output_root, "ablation_summary.csv")

    df.to_csv(detail_csv, index=False)
    final_summary.to_csv(summary_csv, index=False)

    print("\n" + "=" * 140)
    print("Ablation Summary")
    print(final_summary.to_string(index=False))
    print("=" * 140)
    print(f"Detail CSV : {detail_csv}")
    print(f"Summary CSV: {summary_csv}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-opt", default="./options/test/test_combined_routeA.yml", type=str)
    parser.add_argument("--pretrain_model_G", default="", type=str)
    parser.add_argument("--pretrain_model_Gs", default="", type=str)
    parser.add_argument("--mask_root", default="", type=str)
    parser.add_argument("--prompt_path", default="", type=str)
    parser.add_argument("--results_root", default="", type=str)
    parser.add_argument("--image_size", default=256, type=int)
    parser.add_argument("--edge_sigma", default=2.0, type=float)
    parser.add_argument("--boundary_kernel", default=5, type=int)
    parser.add_argument("--boundary_side", default="hole", choices=["hole", "known", "both"])
    parser.add_argument("--max_images", default=-1, type=int)
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--save_images", action="store_true")

    parser.add_argument(
        "--variants",
        nargs="+",
        default=["full", "no_prompt", "empty", "generic", "mismatched"],
        choices=["full", "no_prompt", "empty", "generic", "mismatched"]
    )

    parser.add_argument(
        "--structure_modes",
        nargs="+",
        default=["official"],
        choices=["official", "masked_recomputed", "masked_edge_erode", "masked_edge_inpaint"]
    )

    parser.add_argument(
        "--generic_prompt",
        default=(
            "A colorful Dunhuang mural painting with ancient mineral pigments, "
            "religious figures, lotus motifs, decorative patterns, and damaged regions."
        ),
        type=str
    )

    args = parser.parse_args()
    set_random_seed(args.seed)

    opt = option.parse(args.opt, is_train=False)
    opt = option.dict_to_nonedict(opt)

    if args.pretrain_model_G:
        opt["path"]["pretrain_model_G"] = args.pretrain_model_G
    if args.pretrain_model_Gs:
        opt["path"]["pretrain_model_Gs"] = args.pretrain_model_Gs
    if args.results_root:
        opt["path"]["results_root"] = args.results_root

    base_results_root = opt["path"]["results_root"]

    util.mkdirs(
        path for key, path in opt["path"].items()
        if key != "experiments_root"
        and "pretrain_model" not in key
        and "resume" not in key
    )

    util.setup_logger(
        "base",
        opt["path"]["log"],
        "test_ablation_hard_metrics",
        level=logging.INFO,
        screen=True,
        tofile=True
    )
    logger = logging.getLogger("base")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    logger.info("Loading LPIPS and NIQE...")
    lpips_fn = lpips.LPIPS(net="vgg").to(device)
    lpips_fn.eval()

    niqe_metric = None
    if HAS_NIQE:
        niqe_metric = pyiqa.create_metric("niqe", device=device)

    logger.info("Creating model...")
    model = create_model(opt)

    logger.info("Loading CLIP text encoder...")
    tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
    text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14").to(device)
    text_encoder.eval()
    for p in text_encoder.parameters():
        p.requires_grad = False

    sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )

    S_sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )

    wrapped_model = OutputWrapper(model.model)
    sde.set_model(wrapped_model)

    resize_rgb = transforms.Resize((args.image_size, args.image_size), interpolation=InterpolationMode.BICUBIC)

    output_root = os.path.join(
        base_results_root,
        "Ablation_Hard_Metrics"
    )
    util.mkdir(output_root)

    all_rows = []

    for phase, dataset_opt in sorted(opt["datasets"].items()):
        dataset_name = dataset_opt.get("name", phase)
        logger.info("=" * 90)
        logger.info(f"Testing dataset: {dataset_name}")
        logger.info("=" * 90)

        test_set = create_dataset(dataset_opt)
        test_loader = create_dataloader(test_set, dataset_opt)

        prompt_path = args.prompt_path if args.prompt_path else dataset_opt.get("prompt_path", "")
        prompt_dict = load_prompt_dict(prompt_path)
        prompt_keys = sorted(list(prompt_dict.keys()))

        mask_root = args.mask_root if args.mask_root else dataset_opt.get(
            "mask_root",
            opt.get("degradation", {}).get("mask_root", "")
        )

        available_masks = sorted(
            glob.glob(os.path.join(mask_root, "*.png")) +
            glob.glob(os.path.join(mask_root, "*.jpg")) +
            glob.glob(os.path.join(mask_root, "*.jpeg"))
        )

        for idx, train_data in enumerate(test_loader):
            if args.max_images > 0 and idx >= args.max_images:
                break

            img_path = train_data["GT_path"][0]
            img_base = os.path.basename(img_path)
            img_name = os.path.splitext(img_base)[0]

            mask_path = find_mask_for_image(img_path, mask_root)
            if mask_path is None:
                if available_masks:
                    mask_path = random.choice(available_masks)
                    logger.warning(f"No matched mask for {img_name}, use random mask: {mask_path}")
                else:
                    logger.warning(f"Skip {img_name}: no mask found in {mask_root}")
                    continue

            real_gt_pil = Image.open(img_path).convert("RGB")
            Y_GT = transforms.ToTensor()(resize_rgb(real_gt_pil)).unsqueeze(0).to(device)

            mask = read_mask_white_bg_black_hole(mask_path, image_size=args.image_size).to(device)
            mask = (mask > 0.5).float()

            observed = Y_GT * mask
            damage_ratio = float((mask == 0).float().mean().item())

            if damage_ratio <= 0.20:
                cat = "0-20%"
            elif damage_ratio <= 0.40:
                cat = "20-40%"
            else:
                cat = "40%+"

            original_prompt = get_original_prompt(
                prompt_dict=prompt_dict,
                img_name=img_name,
                img_base=img_base,
                default_prompt=args.generic_prompt
            )

            if prompt_keys:
                mismatch_key = prompt_keys[(idx + 17) % len(prompt_keys)]
                mismatched_prompt = get_original_prompt(
                    prompt_dict=prompt_dict,
                    img_name=os.path.splitext(os.path.basename(mismatch_key))[0],
                    img_base=mismatch_key,
                    default_prompt=args.generic_prompt
                )
            else:
                mismatched_prompt = args.generic_prompt

            boundary = make_boundary_mask(
                mask=mask,
                kernel_size=args.boundary_kernel,
                boundary_side=args.boundary_side
            )

            for structure_mode in args.structure_modes:
                X_GT, X_LQ = build_structure_inputs(
                    real_gt_pil=real_gt_pil,
                    Y_GT=Y_GT,
                    mask=mask,
                    image_size=args.image_size,
                    device=device,
                    structure_mode=structure_mode,
                    edge_sigma=args.edge_sigma,
                    erode_kernel=args.boundary_kernel
                )

                for variant in args.variants:
                    set_random_seed(args.seed + idx)

                    prompt_text = build_prompt_for_variant(
                        variant=variant,
                        original_prompt=original_prompt,
                        generic_prompt=args.generic_prompt,
                        mismatched_prompt=mismatched_prompt
                    )

                    prompt_context = None
                    if prompt_text is not None:
                        tokens = tokenizer(
                            [prompt_text],
                            padding="max_length",
                            max_length=77,
                            truncation=True,
                            return_tensors="pt"
                        ).to(device)

                        with torch.no_grad():
                            prompt_context = text_encoder(tokens.input_ids)[0]

                    model.model.eval()
                    sde.set_mu(observed)

                    wrapped_model.current_mask = mask
                    wrapped_model.S_GT = X_GT
                    wrapped_model.S_LQ = X_LQ
                    wrapped_model.S_sde = S_sde

                    init_xt = observed + torch.randn_like(Y_GT) * (opt["sde"]["max_sigma"] / 255.0)

                    with torch.no_grad():
                        if prompt_context is None:
                            SR_img = sde.reverse_sde(init_xt)
                        else:
                            SR_img = sde.reverse_sde(init_xt, prompt_context=prompt_context)

                    wrapped_model.current_mask = None
                    wrapped_model.S_GT = None
                    wrapped_model.S_LQ = None
                    wrapped_model.S_sde = None

                    SR_img = ensure_4d(SR_img).to(device).float().clamp(0, 1)

                    hard_out = SR_img * (1.0 - mask) + observed
                    hard_out = hard_out.clamp(0, 1)

                    metrics = compute_all_metrics(
                        pred_tensor=hard_out,
                        gt_tensor=Y_GT,
                        mask_tensor=mask,
                        boundary_tensor=boundary,
                        lpips_fn=lpips_fn,
                        niqe_metric=niqe_metric,
                        edge_sigma=args.edge_sigma
                    )

                    row = {
                        "Dataset": dataset_name,
                        "Image": img_name,
                        "ImagePath": img_path,
                        "MaskPath": mask_path,
                        "Category": cat,
                        "DamageRatio": round(damage_ratio, 4),
                        "Variant": variant,
                        "StructureMode": structure_mode,
                        "Fusion": "Hard",
                        "BoundarySide": args.boundary_side,
                        "BoundaryKernel": args.boundary_kernel,
                        "Prompt": "" if prompt_text is None else prompt_text,
                        **metrics
                    }

                    all_rows.append(row)

                    if args.save_images:
                        save_dir = os.path.join(
                            output_root,
                            "images",
                            dataset_name,
                            structure_mode,
                            variant,
                            cat
                        )
                        util.mkdir(save_dir)
                        prefix = f"{img_name}_{structure_mode}_{variant}_{cat.replace('%','')}_ratio{damage_ratio:.2f}"
                        save_tensor_rgb(hard_out, os.path.join(save_dir, f"{prefix}_hard.png"))
                        save_tensor_rgb(SR_img, os.path.join(save_dir, f"{prefix}_raw.png"))
                        save_tensor_rgb(observed, os.path.join(save_dir, f"{prefix}_input.png"))
                        save_tensor_rgb(Y_GT, os.path.join(save_dir, f"{prefix}_gt.png"))

            if (idx + 1) % 10 == 0:
                logger.info(f"[{dataset_name}] finished {idx + 1}")

    df = pd.DataFrame(all_rows)
    summarize_and_save(df, output_root)


if __name__ == "__main__":
    main()
