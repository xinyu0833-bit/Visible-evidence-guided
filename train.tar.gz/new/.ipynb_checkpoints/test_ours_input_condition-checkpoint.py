import argparse
import glob
import json
import logging
import os
import os.path as osp
import random
import time

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

import options as option
import str_utils as str_util
import utils as util

from data import create_dataloader, create_dataset
from models import create_model

from PIL import Image
from skimage.feature import canny
from skimage.metrics import peak_signal_noise_ratio as psnr_metric
from skimage.metrics import structural_similarity as ssim_metric
from torchvision import transforms
from torchvision.transforms import InterpolationMode

from transformers import CLIPTokenizer, CLIPTextModel


try:
    import lpips
    HAS_LPIPS = True
except Exception:
    HAS_LPIPS = False


try:
    import pyiqa
    HAS_NIQE = True
except Exception:
    HAS_NIQE = False


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)


def ensure_4d(x):
    """
    Convert tensor to [B, C, H, W].
    Accept:
        [C, H, W]
        [1, C, H, W]
    """
    if x.dim() == 3:
        x = x.unsqueeze(0)
    if x.dim() != 4:
        raise ValueError(f"Expected 3D or 4D tensor, got shape: {tuple(x.shape)}")
    return x

def resize_4d_tensor(x, image_size=256, mode="bilinear"):
    """
    Resize tensor to [B, C, image_size, image_size].

    x:
        [C, H, W] or [B, C, H, W]

    mode:
        bilinear for RGB/gray
        nearest for binary edge/mask
    """
    x = ensure_4d(x)

    if x.shape[-2:] == (image_size, image_size):
        return x

    if mode == "nearest":
        return F.interpolate(
            x,
            size=(image_size, image_size),
            mode="nearest"
        )

    return F.interpolate(
        x,
        size=(image_size, image_size),
        mode=mode,
        align_corners=False
    )


def tensor_to_uint8_rgb(x):
    """
    x: [1, 3, H, W] or [3, H, W], RGB, range [0, 1].
    return: HWC uint8 RGB.
    """
    if x.dim() == 4:
        x = x[0]
    x = x.detach().float().cpu().clamp(0.0, 1.0)
    arr = x.permute(1, 2, 0).numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    return arr


def save_tensor_image(tensor, path):
    arr = tensor_to_uint8_rgb(tensor)
    Image.fromarray(arr).save(path)


def save_gray_tensor_image(tensor, path):
    """
    Save [1,1,H,W], [1,H,W], or [H,W] tensor as grayscale PNG.
    """
    x = tensor.detach().float().cpu()

    if x.dim() == 4:
        x = x[0, 0]
    elif x.dim() == 3:
        x = x[0]
    elif x.dim() == 2:
        pass
    else:
        raise ValueError(f"Unsupported gray tensor shape: {tuple(x.shape)}")

    arr = x.clamp(0.0, 1.0).numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    Image.fromarray(arr, mode="L").save(path)


def tensor_to_gray_tensor(rgb_tensor):
    """
    rgb_tensor: [B, 3, H, W], RGB, range [0, 1].
    return: [B, 1, H, W].
    """
    rgb_tensor = ensure_4d(rgb_tensor).detach().float().clamp(0.0, 1.0)
    r = rgb_tensor[:, 0:1, :, :]
    g = rgb_tensor[:, 1:2, :, :]
    b = rgb_tensor[:, 2:3, :, :]
    gray = 0.299 * r + 0.587 * g + 0.114 * b
    return gray


def batch_gray_edge_from_rgb_tensor(rgb_tensor, sigma=2.0):
    """
    rgb_tensor: [B, 3, H, W], RGB, range [0, 1].
    return:
        gray_tensor: [B, 1, H, W]
        edge_tensor: [B, 1, H, W]
    """
    device = rgb_tensor.device
    gray_tensor = tensor_to_gray_tensor(rgb_tensor)

    gray_np = gray_tensor.detach().cpu().numpy()
    edge_list = []

    for i in range(gray_np.shape[0]):
        g = gray_np[i, 0].astype(np.float32)
        edge = canny(g, sigma=sigma).astype(np.float32)
        edge_list.append(edge[None, :, :])

    edge_arr = np.stack(edge_list, axis=0)
    edge_tensor = torch.from_numpy(edge_arr).float().to(device)

    return gray_tensor.to(device), edge_tensor


def normalize_mask_tensor(mask_tensor):
    """
    Return binary mask:
        1 = known / unmasked
        0 = hole / masked
    """
    return (mask_tensor > 0.5).float()


def read_mask_white_bg_black_hole(mask_path, image_size=256):
    """
    Your mask convention:
        white background = known = 1
        black hole       = hole  = 0
    """
    transform = transforms.Compose([
        transforms.Resize((image_size, image_size), interpolation=InterpolationMode.NEAREST),
        transforms.ToTensor()
    ])

    mask_pil = Image.open(mask_path).convert("L")
    mask = transform(mask_pil)
    mask = normalize_mask_tensor(mask)
    return mask


def read_mask_official_black_bg_white_hole(mask_path, image_size=256):
    """
    Official-style mask assumption:
        raw white = hole
        raw black = known

    After inversion:
        known = 1
        hole = 0
    """
    transform = transforms.Compose([
        transforms.Resize((image_size, image_size), interpolation=InterpolationMode.NEAREST),
        transforms.ToTensor()
    ])

    mask_pil = Image.open(mask_path).convert("L")
    raw = normalize_mask_tensor(transform(mask_pil))
    mask = 1.0 - raw
    return mask


def read_mask(mask_path, mask_format, image_size=256):
    if mask_format == "white_bg_black_hole":
        return read_mask_white_bg_black_hole(mask_path, image_size=image_size)

    if mask_format == "official_black_bg_white_hole":
        return read_mask_official_black_bg_white_hole(mask_path, image_size=image_size)

    raise ValueError(f"Unknown mask_format: {mask_format}")


def find_mask_for_image(img_path, mask_root):
    img_name = os.path.splitext(os.path.basename(img_path))[0]
    candidates = [
        f"{img_name}.png",
        f"{img_name}.jpg",
        f"{img_name}.jpeg",
        f"{img_name}_mask.png",
        f"{img_name}_mask.jpg",
        f"{img_name}_masked.png",
        f"{img_name}_masked.jpg",
    ]

    for name in candidates:
        p = os.path.join(mask_root, name)
        if os.path.exists(p):
            return p

    return None


def list_masks(mask_root):
    masks = []
    for ext in ["*.png", "*.jpg", "*.jpeg", "*.bmp"]:
        masks.extend(glob.glob(os.path.join(mask_root, ext)))
    return sorted(masks)


def pretty_structure_name(mode):
    name_map = {
        "official": "Oracle",
        "masked_recomputed": "Masked",
        "masked_gray_dataset_edge": "MaskedGray_GTedge",
        "oracle_gray_masked_edge_recomputed": "OracleGray_MaskedEdge",
    }
    return name_map.get(mode, mode)


def build_structure_inputs(Y_GT, X_GT_dataset, X_LQ_dataset, mask, mode, edge_sigma):
    """
    Official dataset:
        X_GT_dataset = GT_gray from complete GT
        X_LQ_dataset = GT_edge from complete GT

    All masks follow:
        mask = 1 known
        mask = 0 hole
    """
    if mode == "official":
        # Official StrDiffusion-style upper-bound condition:
        # S_GT uses complete GT gray.
        # S_LQ uses GT edge, later masked.
        return X_GT_dataset, X_LQ_dataset

    if mode == "masked_recomputed":
        # Fair condition:
        # gray and edge are extracted only from observed image.
        observed = Y_GT * mask
        X_gray, X_edge = batch_gray_edge_from_rgb_tensor(observed, sigma=edge_sigma)
        return X_gray, X_edge

    if mode == "masked_gray_dataset_edge":
        # Diagnostic:
        # masked gray + GT edge.
        observed = Y_GT * mask
        X_gray, _ = batch_gray_edge_from_rgb_tensor(observed, sigma=edge_sigma)
        return X_gray, X_LQ_dataset

    if mode == "oracle_gray_masked_edge_recomputed":
        # Diagnostic:
        # GT gray + edge recomputed from observed input.
        observed = Y_GT * mask
        _, X_edge = batch_gray_edge_from_rgb_tensor(observed, sigma=edge_sigma)
        return X_GT_dataset, X_edge

    raise ValueError(f"Unknown structure mode: {mode}")


def compute_metrics(pred_tensor, gt_tensor, mask_tensor, lpips_fn=None, niqe_fn=None):
    """
    pred_tensor, gt_tensor:
        [1, 3, H, W] or [3, H, W], RGB, range [0, 1]

    mask_tensor:
        [1, 1, H, W] or [1, H, W], 1 = known, 0 = hole
    """
    pred_tensor = ensure_4d(pred_tensor).detach().float().clamp(0.0, 1.0)
    gt_tensor = ensure_4d(gt_tensor).detach().float().clamp(0.0, 1.0)

    if mask_tensor.dim() == 3:
        mask_tensor = mask_tensor.unsqueeze(0)
    if mask_tensor.dim() != 4:
        raise ValueError(f"Expected 3D or 4D mask tensor, got shape: {tuple(mask_tensor.shape)}")

    mask_tensor = mask_tensor.detach().float()

    pred_u8 = tensor_to_uint8_rgb(pred_tensor)
    gt_u8 = tensor_to_uint8_rgb(gt_tensor)

    pred_f32 = pred_u8.astype(np.float32) / 255.0
    gt_f32 = gt_u8.astype(np.float32) / 255.0

    global_psnr = psnr_metric(gt_u8, pred_u8, data_range=255)

    _, ssim_map = ssim_metric(
        gt_f32,
        pred_f32,
        channel_axis=2,
        full=True,
        data_range=1.0
    )
    global_ssim = float(np.mean(ssim_map))

    mask_np = mask_tensor[0, 0].detach().cpu().numpy().astype(np.float32)
    hole_np = 1.0 - mask_np
    hole_3c = np.expand_dims(hole_np, axis=-1).repeat(3, axis=-1)

    mse_hole = np.sum(((gt_f32 - pred_f32) ** 2) * hole_3c) / (np.sum(hole_3c) + 1e-8)
    hole_psnr = 10.0 * np.log10(1.0 / mse_hole) if mse_hole > 0 else 99.99

    ssim_gray = np.mean(ssim_map, axis=2)
    hole_ssim = np.sum(ssim_gray * hole_np) / (np.sum(hole_np) + 1e-8)

    lpips_val = 0.0
    if lpips_fn is not None:
        with torch.no_grad():
            lpips_val = lpips_fn(
                pred_tensor * 2.0 - 1.0,
                gt_tensor * 2.0 - 1.0
            ).item()

    niqe_val = 0.0
    if niqe_fn is not None:
        with torch.no_grad():
            niqe_val = niqe_fn(pred_tensor).item()

    return {
        "Global_PSNR": round(float(global_psnr), 4),
        "Global_SSIM": round(float(global_ssim), 4),
        "Hole_PSNR": round(float(hole_psnr), 4),
        "Hole_SSIM": round(float(hole_ssim), 4),
        "LPIPS": round(float(lpips_val), 4),
        "NIQE": round(float(niqe_val), 4),
    }


def load_prompt_dict(prompt_path):
    if prompt_path and os.path.exists(prompt_path):
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt_dict = json.load(f)
        print(f"Loaded prompt json: {prompt_path}, num={len(prompt_dict)}")
        return prompt_dict

    print("Warning: prompt json not found. Default English prompt will be used.")
    return {}


def get_prompt_for_image(prompt_dict, img_name, img_base, default_prompt):
    raw_prompt = prompt_dict.get(img_name, prompt_dict.get(img_base, default_prompt))

    if isinstance(raw_prompt, dict):
        return raw_prompt.get("final_prompt", default_prompt)

    return str(raw_prompt)


def encode_prompt(tokenizer, text_encoder, prompt, device):
    tokens = tokenizer(
        [prompt],
        padding="max_length",
        max_length=77,
        truncation=True,
        return_tensors="pt"
    ).to(device)

    with torch.no_grad():
        prompt_context = text_encoder(tokens.input_ids)[0]

    return prompt_context


def call_model_test_ours(
    model,
    sde,
    S_sde,
    noisy_state,
    observed,
    Y_GT,
    mask,
    X_GT_mode,
    X_LQ_mode,
    noisy_states,
    prompt_context,
    save_dir,
):
    """
    Try to use the Ours-modified model.test() first.
    If the local model.test() does not accept prompt_context / mask,
    fallback to setting attributes before calling model.test().
    """
    model.feed_data(
        noisy_state,
        observed,
        Y_GT,
        mask,
        S_sde,
        X_GT_mode,
        X_LQ_mode * mask
    )

    # Force prompt_context into DenoisingModel for local test() implementations
    # that read self.prompt_context instead of kwargs["prompt_context"].
    if prompt_context is not None:
        model.prompt_context = prompt_context
    else:
        model.prompt_context = None

    # Also attach to wrapped DataParallel module for safety.
    if hasattr(model, "model") and hasattr(model.model, "module"):
        setattr(model.model.module, "prompt_context", prompt_context)
    # Preferred path:
    # modified Ours DenoisingModel.test should accept prompt_context and mask.
    try:
        model.test(
            sde,
            save_states=False,
            save_dir=save_dir,
            GT=Y_GT,
            mask=mask,
            S_sde=S_sde,
            S_GT=X_GT_mode,
            S_LQ=noisy_states,
            dis=model.dis,
            prompt_context=prompt_context,
        )
        return

    except TypeError:
        # Fallback for versions where test() signature is close to official.
        # Store prompt_context on model/model.module so the modified UNet can still receive it
        # if the local code checks attributes internally.
        if hasattr(model, "prompt_context"):
            model.prompt_context = prompt_context

        if hasattr(model, "model") and hasattr(model.model, "module"):
            if hasattr(model.model.module, "prompt_context"):
                model.model.module.prompt_context = prompt_context

        try:
            model.test(
                sde,
                save_states=False,
                save_dir=save_dir,
                GT=Y_GT,
                mask=mask,
                S_sde=S_sde,
                S_GT=X_GT_mode,
                S_LQ=noisy_states,
                dis=model.dis,
            )
            return

        except TypeError as e:
            raise RuntimeError(
                "Your local DenoisingModel.test() does not support prompt_context, "
                "and fallback also failed. Please modify denoising_model.py so that "
                "test() forwards prompt_context and mask into sde.reverse_sde(). "
                f"Original error: {e}"
            )


def summarize(df, output_dir):
    metric_cols = [
        "Global_PSNR",
        "Global_SSIM",
        "Hole_PSNR",
        "Hole_SSIM",
        "LPIPS",
        "NIQE",
    ]

    summary = (
        df.groupby(["Dataset", "StructureName", "Fusion"])[metric_cols]
        .mean()
        .reset_index()
    )

    summary_by_cat = (
        df.groupby(["Dataset", "StructureName", "Fusion", "Category"])[metric_cols]
        .mean()
        .reset_index()
    )

    summary_path = os.path.join(output_dir, "ours_input_condition_summary.csv")
    summary_cat_path = os.path.join(output_dir, "ours_input_condition_summary_by_category.csv")

    summary.to_csv(summary_path, index=False)
    summary_by_cat.to_csv(summary_cat_path, index=False)

    print("\n=== Summary ===")
    print(summary.to_string(index=False))
    print(f"\nSaved summary to: {summary_path}")
    print(f"Saved category summary to: {summary_cat_path}")

    paired_rows = []

    for dataset_name in sorted(df["Dataset"].unique()):
        sub_dataset = df[df["Dataset"] == dataset_name]

        for fusion_name in sorted(sub_dataset["Fusion"].unique()):
            sub_fusion = sub_dataset[sub_dataset["Fusion"] == fusion_name]

            for image_name in sorted(sub_fusion["Image"].unique()):
                sub_img = sub_fusion[sub_fusion["Image"] == image_name]

                oracle = sub_img[sub_img["StructureName"] == "Oracle"]
                masked = sub_img[sub_img["StructureName"] == "Masked"]

                if len(oracle) == 0 or len(masked) == 0:
                    continue

                oracle_row = oracle.iloc[0]
                masked_row = masked.iloc[0]

                row = {
                    "Dataset": dataset_name,
                    "Image": image_name,
                    "Fusion": fusion_name,
                    "Category": oracle_row["Category"],
                    "DamageRatio": oracle_row["DamageRatio"],
                }

                for m in metric_cols:
                    row[f"Oracle_{m}"] = oracle_row[m]
                    row[f"Masked_{m}"] = masked_row[m]
                    row[f"Diff_OracleMinusMasked_{m}"] = oracle_row[m] - masked_row[m]

                paired_rows.append(row)

    if len(paired_rows) > 0:
        paired_df = pd.DataFrame(paired_rows)
        paired_path = os.path.join(output_dir, "ours_input_condition_oracle_vs_masked_paired.csv")
        paired_df.to_csv(paired_path, index=False)

        diff_cols = [c for c in paired_df.columns if c.startswith("Diff_OracleMinusMasked_")]
        mean_diff = paired_df[diff_cols].mean().reset_index()
        mean_diff.columns = ["Metric", "Mean_OracleMinusMasked"]

        mean_diff_path = os.path.join(output_dir, "ours_input_condition_oracle_vs_masked_mean_diff.csv")
        mean_diff.to_csv(mean_diff_path, index=False)

        print("\n=== Paired Oracle - Masked Difference ===")
        print(mean_diff.to_string(index=False))
        print(f"\nSaved paired comparison to: {paired_path}")
        print(f"Saved mean difference to: {mean_diff_path}")
    else:
        print("\nWarning: no paired Oracle/Masked rows found.")


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-opt",
        default="./options/test/ir-sde.yml",
        type=str,
        help="Path to Ours/StrDiffusion test option YAML."
    )

    parser.add_argument(
        "--mask_root",
        default="",
        type=str,
        help="Override mask root. If empty, use opt['degradation']['mask_root']."
    )

    parser.add_argument(
        "--mask_format",
        default="white_bg_black_hole",
        choices=["white_bg_black_hole", "official_black_bg_white_hole"],
        help=(
            "white_bg_black_hole: your mask format, white=known, black=hole. "
            "official_black_bg_white_hole: official-style mask, white=hole, black=known."
        )
    )

    parser.add_argument(
        "--mask_match",
        default="name",
        choices=["name", "random"],
        help="name: match mask by image basename. random: use random masks."
    )

    parser.add_argument(
        "--structure_modes",
        nargs="+",
        default=["official", "masked_recomputed"],
        choices=[
            "official",
            "masked_recomputed",
            "masked_gray_dataset_edge",
            "oracle_gray_masked_edge_recomputed",
        ],
        help="Structure input modes to evaluate."
    )

    parser.add_argument(
        "--prompt_path",
        default="",
        type=str,
        help="English prompt json path. If empty, use dataset_opt['prompt_path'] if available."
    )

    parser.add_argument(
        "--default_prompt",
        default=(
            "A colorful Dunhuang mural painting with ancient mineral pigments, "
            "religious figures, lotus motifs, decorative patterns, and damaged regions."
        ),
        type=str,
        help="Default English prompt when json prompt is missing."
    )

    parser.add_argument(
        "--disable_prompt",
        action="store_true",
        help="Disable CLIP prompt_context. This turns Ours into no-prompt inference."
    )

    parser.add_argument(
        "--pretrain_model_G",
        default="",
        type=str,
        help="Override opt['path']['pretrain_model_G'] with Ours checkpoint."
    )

    parser.add_argument(
        "--pretrain_model_Gs",
        default="",
        type=str,
        help="Override opt['path']['pretrain_model_Gs']."
    )

    parser.add_argument(
        "--pretrain_model_D",
        default="",
        type=str,
        help="Override opt['path']['pretrain_model_D']."
    )

    parser.add_argument(
        "--results_root",
        default="",
        type=str,
        help="Override opt['path']['results_root']."
    )

    parser.add_argument(
        "--seed",
        default=42,
        type=int
    )

    parser.add_argument(
        "--edge_sigma",
        default=2.0,
        type=float,
        help="Canny sigma for recomputed masked edge."
    )

    parser.add_argument(
        "--save_images",
        action="store_true",
        help="Save raw output, hard composite, input and GT images."
    )

    parser.add_argument(
        "--save_structure_debug",
        action="store_true",
        help="Save gray/edge structure debug images."
    )

    parser.add_argument(
        "--max_images",
        default=-1,
        type=int,
        help="For quick debugging. -1 means all images."
    )

    parser.add_argument(
        "--eval_fusion",
        default="hard",
        choices=["raw", "hard", "both"],
        help="raw: evaluate direct output. hard: evaluate hard composite. both: evaluate both."
    )

    parser.add_argument(
        "--image_size",
        default=256,
        type=int,
        help="Resize GT, gray, edge and mask to this size."
    )

    
    args = parser.parse_args()

    set_random_seed(args.seed)

    opt = option.parse(args.opt, is_train=False)
    opt = option.dict_to_nonedict(opt)

    if args.pretrain_model_G:
        opt["path"]["pretrain_model_G"] = args.pretrain_model_G
    if args.pretrain_model_Gs:
        opt["path"]["pretrain_model_Gs"] = args.pretrain_model_Gs
    if args.pretrain_model_D:
        opt["path"]["pretrain_model_D"] = args.pretrain_model_D
    if args.results_root:
        opt["path"]["results_root"] = args.results_root

    mask_root = args.mask_root if args.mask_root else opt["degradation"]["mask_root"]
    available_masks = list_masks(mask_root)
    if len(available_masks) == 0:
        raise RuntimeError(f"No mask files found in mask_root: {mask_root}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    util.mkdirs(
        path for key, path in opt["path"].items()
        if key != "experiments_root"
        and "pretrain_model" not in key
        and "resume" not in key
    )

    util.setup_logger(
        "base",
        opt["path"]["log"],
        "test_ours_input_condition",
        level=logging.INFO,
        screen=True,
        tofile=True,
    )
    logger = logging.getLogger("base")
    logger.info(option.dict2str(opt))
    logger.info(f"Mask root: {mask_root}")
    logger.info(f"Mask format: {args.mask_format}")
    logger.info(f"Structure modes: {args.structure_modes}")

    lpips_fn = None
    if HAS_LPIPS:
        lpips_fn = lpips.LPIPS(net="vgg").to(device)
        lpips_fn.eval()

    niqe_fn = None
    if HAS_NIQE:
        try:
            niqe_fn = pyiqa.create_metric("niqe", device=device)
        except Exception as e:
            logger.warning(f"Failed to create NIQE metric: {e}")
            niqe_fn = None

    # Load Ours model.
    model = create_model(opt)
    device = model.device

    sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )
    sde.set_model(model.model)

    S_sde = str_util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )

    if hasattr(model, "models"):
        S_sde.set_model(model.models)

    # Load CLIP text encoder for Ours prompt branch.
    tokenizer = None
    text_encoder = None

    if not args.disable_prompt:
        logger.info("Loading CLIP text encoder for Ours...")
        tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
        text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14").to(device)
        text_encoder.eval()
        for p in text_encoder.parameters():
            p.requires_grad = False

    output_root = os.path.join(
        opt["path"]["results_root"],
        "Ours_InputCondition_Check"
    )
    ensure_dir(output_root)

    all_rows = []

    for phase, dataset_opt in sorted(opt["datasets"].items()):
        test_set = create_dataset(dataset_opt)
        test_loader = create_dataloader(test_set, dataset_opt)

        dataset_name = dataset_opt.get("name", phase)
        dataset_output_root = os.path.join(output_root, dataset_name)
        ensure_dir(dataset_output_root)

        # Prompt path priority:
        # command-line --prompt_path > dataset_opt['prompt_path'] > empty.
        prompt_path = args.prompt_path if args.prompt_path else dataset_opt.get("prompt_path", "")
        prompt_dict = load_prompt_dict(prompt_path)

        logger.info(f"Testing dataset: {dataset_name}, num_images={len(test_set)}")

        for idx, train_data in enumerate(test_loader):
            if args.max_images > 0 and idx >= args.max_images:
                break

            img_path = train_data["GT_path"][0]
            img_base = os.path.basename(img_path)
            img_name = os.path.splitext(img_base)[0]

            if args.mask_match == "name":
                mask_path = find_mask_for_image(img_path, mask_root)
                if mask_path is None:
                    mask_path = random.choice(available_masks)
                    logger.warning(f"No matched mask for {img_name}; use random mask: {mask_path}")
            else:
                mask_path = random.choice(available_masks)

            mask = read_mask(mask_path, args.mask_format, image_size=args.image_size)

            mask = mask.unsqueeze(0).to(device).float()

            # Convention:
            #   mask = 1 known
            #   mask = 0 hole
            Y_GT = ensure_4d(train_data["GT"].to(device))
            X_GT_dataset = ensure_4d(train_data["GT_gray"].to(device))
            X_LQ_dataset = ensure_4d(train_data["GT_edge"].to(device))

            # Official test dataset may return original image size, e.g. 707 px.
            # Resize all inputs to match the 256x256 mask and the trained model setting.
            Y_GT = resize_4d_tensor(
                Y_GT,
                image_size=args.image_size,
                mode="bilinear"
            )

            X_GT_dataset = resize_4d_tensor(
                X_GT_dataset,
                image_size=args.image_size,
                mode="bilinear"
            )

            X_LQ_dataset = resize_4d_tensor(
                X_LQ_dataset,
                image_size=args.image_size,
                mode="nearest"
            )

            mask = resize_4d_tensor(
                mask,
                image_size=args.image_size,
                mode="nearest"
            )
            mask = (mask > 0.5).float()

            observed = Y_GT * mask

            damage_ratio = float((mask == 0).float().mean().item())

            if damage_ratio <= 0.20:
                category = "0-20%"
            elif damage_ratio <= 0.40:
                category = "20-40%"
            else:
                category = "40%+"

            if args.disable_prompt:
                current_prompt = ""
                prompt_context = None
            else:
                current_prompt = get_prompt_for_image(
                    prompt_dict=prompt_dict,
                    img_name=img_name,
                    img_base=img_base,
                    default_prompt=args.default_prompt
                )
                prompt_context = encode_prompt(
                    tokenizer=tokenizer,
                    text_encoder=text_encoder,
                    prompt=current_prompt,
                    device=device
                )

            if args.save_structure_debug:
                debug_dir = os.path.join(output_root, "structure_debug", dataset_name, img_name)
                ensure_dir(debug_dir)

                masked_gray, masked_edge = batch_gray_edge_from_rgb_tensor(
                    observed,
                    sigma=args.edge_sigma
                )
                official_edge_after_mask = X_LQ_dataset * mask

                save_tensor_image(Y_GT, os.path.join(debug_dir, f"{img_name}_gt_rgb.png"))
                save_tensor_image(observed, os.path.join(debug_dir, f"{img_name}_observed_input.png"))
                save_gray_tensor_image(mask, os.path.join(debug_dir, f"{img_name}_mask_known_white_hole_black.png"))
                save_gray_tensor_image(X_GT_dataset, os.path.join(debug_dir, f"{img_name}_dataset_GT_gray.png"))
                save_gray_tensor_image(X_LQ_dataset, os.path.join(debug_dir, f"{img_name}_dataset_GT_edge.png"))
                save_gray_tensor_image(official_edge_after_mask, os.path.join(debug_dir, f"{img_name}_official_GT_edge_after_mask.png"))
                save_gray_tensor_image(masked_gray, os.path.join(debug_dir, f"{img_name}_masked_gray_recomputed.png"))
                save_gray_tensor_image(masked_edge, os.path.join(debug_dir, f"{img_name}_masked_edge_recomputed.png"))
                save_gray_tensor_image(torch.abs(X_GT_dataset - masked_gray), os.path.join(debug_dir, f"{img_name}_gray_abs_diff.png"))
                save_gray_tensor_image(torch.abs(official_edge_after_mask - masked_edge), os.path.join(debug_dir, f"{img_name}_edge_abs_diff.png"))

            for structure_mode in args.structure_modes:
                set_random_seed(args.seed + idx)

                mode_name = pretty_structure_name(structure_mode)
                mode_dir = os.path.join(dataset_output_root, mode_name, category)
                ensure_dir(mode_dir)

                X_GT_mode, X_LQ_mode = build_structure_inputs(
                    Y_GT=Y_GT,
                    X_GT_dataset=X_GT_dataset,
                    X_LQ_dataset=X_LQ_dataset,
                    mask=mask,
                    mode=structure_mode,
                    edge_sigma=args.edge_sigma
                )

                # Official StrDiffusion-style input states.
                noisy_state = sde.noise_state(observed)
                noisy_states = S_sde.noise_state(X_LQ_mode * mask)

                tic = time.time()
                with torch.no_grad():
                    call_model_test_ours(
                        model=model,
                        sde=sde,
                        S_sde=S_sde,
                        noisy_state=noisy_state,
                        observed=observed,
                        Y_GT=Y_GT,
                        mask=mask,
                        X_GT_mode=X_GT_mode,
                        X_LQ_mode=X_LQ_mode,
                        noisy_states=noisy_states,
                        prompt_context=prompt_context,
                        save_dir=mode_dir,
                    )
                toc = time.time()

                visuals = model.get_current_visuals()
                SR_img = visuals["Output"].detach().to(device).float().clamp(0.0, 1.0)
                SR_img = ensure_4d(SR_img)

                # Hard Blend only:
                # known region uses observed input; hole region uses model output.
                hard_out = SR_img * (1.0 - mask) + observed
                hard_out = hard_out.clamp(0.0, 1.0)

                eval_items = []
                if args.eval_fusion in ["raw", "both"]:
                    eval_items.append(("Raw", SR_img))
                if args.eval_fusion in ["hard", "both"]:
                    eval_items.append(("Hard", hard_out))

                for fusion_name, eval_tensor in eval_items:
                    metrics = compute_metrics(
                        eval_tensor,
                        Y_GT,
                        mask,
                        lpips_fn=lpips_fn,
                        niqe_fn=niqe_fn
                    )

                    all_rows.append({
                        "Dataset": dataset_name,
                        "Image": img_name,
                        "ImagePath": img_path,
                        "MaskPath": mask_path,
                        "MaskFormat": args.mask_format,
                        "MaskMatch": args.mask_match,
                        "StructureMode": structure_mode,
                        "StructureName": mode_name,
                        "Fusion": fusion_name,
                        "DamageRatio": round(damage_ratio, 4),
                        "Category": category,
                        "Prompt": current_prompt,
                        "TimeSec": round(toc - tic, 4),
                        **metrics
                    })

                if args.save_images:
                    prefix = f"{img_name}_{mode_name}_ratio{damage_ratio:.2f}"
                    save_tensor_image(SR_img, os.path.join(mode_dir, f"{prefix}_raw.png"))
                    save_tensor_image(hard_out, os.path.join(mode_dir, f"{prefix}_hard.png"))
                    save_tensor_image(observed, os.path.join(mode_dir, f"{prefix}_input.png"))
                    save_tensor_image(Y_GT, os.path.join(mode_dir, f"{prefix}_gt.png"))

            if (idx + 1) % 10 == 0:
                logger.info(f"[{dataset_name}] finished {idx + 1}/{len(test_set)} images")

    df = pd.DataFrame(all_rows)
    detail_path = os.path.join(output_root, "ours_input_condition_detail.csv")
    df.to_csv(detail_path, index=False)
    print(f"\nSaved detail CSV to: {detail_path}")

    summarize(df, output_root)


if __name__ == "__main__":
    main()
