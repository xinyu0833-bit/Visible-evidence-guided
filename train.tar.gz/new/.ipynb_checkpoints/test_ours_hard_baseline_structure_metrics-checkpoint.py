import os

os.environ["USE_TORCH"] = "1"
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_NO_FLAX"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import argparse
import logging
import random
import json
import glob
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

import options as option
from models import create_model
import utils as util
from data import create_dataloader, create_dataset


from PIL import Image
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from transformers import CLIPTextModel, CLIPTokenizer
from skimage.feature import canny
from skimage.metrics import peak_signal_noise_ratio as psnr_metric
from skimage.metrics import structural_similarity as ssim_metric

import lpips

try:
    import pyiqa
    HAS_NIQE = True
except ImportError:
    HAS_NIQE = False
    print("Warning: pyiqa is not installed. NIQE will be set to 0.")


class OutputWrapper(torch.nn.Module):
    """
    Ours wrapper.

    This wrapper follows the same structure-condition protocol as the baseline:
        S_GT = GT gray
        S_LQ = GT edge
        mu   = S_LQ * mask

    mask convention:
        mask = 1 known region
        mask = 0 hole region
    """
    def __init__(self, net):
        super().__init__()
        self.net = net
        self.current_mask = None
        self.S_GT = None
        self.S_LQ = None
        self.S_sde = None

    def forward(self, xt, cond, time, **kwargs):
        if self.current_mask is not None:
            kwargs["mask"] = self.current_mask

        if self.S_sde is not None and self.S_GT is not None and self.S_LQ is not None:
            if isinstance(time, (int, float)):
                t_tensor = torch.tensor([int(time)], device=xt.device).long()
            else:
                t_tensor = time.long().squeeze()
                if t_tensor.dim() == 0:
                    t_tensor = t_tensor.unsqueeze(0)

            # Baseline-consistent structure condition:
            # complete GT edge is extracted first, then masked.
            self.S_sde.set_mu(self.S_LQ * self.current_mask)

            S_mu_bar = self.S_sde.mu_bar(self.S_GT, t_tensor)
            S_sigma_bar = self.S_sde.sigma_bar(t_tensor).view(-1, 1, 1, 1)

            S_noise = torch.randn_like(S_mu_bar)
            S_optimum = S_mu_bar + S_noise * S_sigma_bar
            kwargs["S"] = S_optimum

        out = self.net(xt, cond, time, **kwargs)
        if isinstance(out, tuple):
            return out[0]
        return out


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def ensure_4d(x):
    if x.dim() == 3:
        x = x.unsqueeze(0)
    if x.dim() != 4:
        raise ValueError(f"Expected 3D or 4D tensor, got shape: {tuple(x.shape)}")
    return x


def resize_4d_tensor(x, image_size=256, mode="bilinear"):
    x = ensure_4d(x)

    if x.shape[-2:] == (image_size, image_size):
        return x

    if mode == "nearest":
        return F.interpolate(x, size=(image_size, image_size), mode="nearest")

    return F.interpolate(
        x,
        size=(image_size, image_size),
        mode=mode,
        align_corners=False
    )


def tensor_to_uint8_rgb(x):
    """
    x: [1, 3, H, W] or [3, H, W], RGB, range [0, 1]
    """
    x = ensure_4d(x)
    arr = x[0].detach().float().cpu().clamp(0, 1).permute(1, 2, 0).numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    return arr


def save_tensor_rgb(x, path):
    arr = tensor_to_uint8_rgb(x)
    Image.fromarray(arr).save(path)


def save_gray_tensor(x, path):
    x = x.detach().float().cpu()
    if x.dim() == 4:
        x = x[0, 0]
    elif x.dim() == 3:
        x = x[0]
    elif x.dim() == 2:
        pass
    else:
        raise ValueError(f"Unsupported gray tensor shape: {tuple(x.shape)}")

    arr = x.clamp(0, 1).numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    Image.fromarray(arr, mode="L").save(path)


def read_mask_white_bg_black_hole(mask_path, image_size=256):
    """
    User mask convention:
        white = known = 1
        black = hole  = 0
    """
    transform_mask = transforms.Compose([
        transforms.Resize((image_size, image_size), interpolation=InterpolationMode.NEAREST),
        transforms.ToTensor()
    ])

    mask_pil = Image.open(mask_path).convert("L")
    mask = transform_mask(mask_pil)
    mask = (mask > 0.5).float()
    return mask.unsqueeze(0)


def find_mask_for_image(img_path, mask_root):
    img_name = os.path.splitext(os.path.basename(img_path))[0]
    candidates = [
        f"{img_name}.jpg",
        f"{img_name}.png",
        f"{img_name}.jpeg",
        f"{img_name}_mask.jpg",
        f"{img_name}_mask.png",
        f"{img_name}_masked.jpg",
        f"{img_name}_masked.png",
    ]

    for name in candidates:
        p = os.path.join(mask_root, name)
        if os.path.exists(p):
            return p

    return None


def build_baseline_structure_from_gt(real_gt_pil, image_size, device, edge_sigma=2.0):
    """
    Baseline-consistent structure:
        X_GT = complete GT gray
        X_LQ = Canny edge extracted from complete GT gray
    """
    resize_rgb = transforms.Resize((image_size, image_size), interpolation=InterpolationMode.BICUBIC)

    gray_pil = resize_rgb(real_gt_pil.convert("L"))
    X_GT = transforms.ToTensor()(gray_pil).unsqueeze(0).to(device)

    gray_np = np.array(gray_pil).astype(np.float32) / 255.0
    edge_np = canny(gray_np, sigma=edge_sigma).astype(np.float32)
    X_LQ = torch.from_numpy(edge_np).float().unsqueeze(0).unsqueeze(0).to(device)

    return X_GT, X_LQ


def make_boundary_mask(mask, kernel_size=5, boundary_side="known"):
    """
    mask:
        [1, 1, H, W], 1 = known, 0 = hole

    boundary_side:
        known  : boundary ring outside the hole, same as training code: dilate(hole) - hole
        hole   : inner boundary inside the hole
        both   : union of outside and inside boundary
    """
    mask = ensure_4d(mask).float()
    hole = 1.0 - mask

    kernel = torch.ones(1, 1, kernel_size, kernel_size, device=mask.device)
    padding = kernel_size // 2

    dilated_hole = F.conv2d(hole, kernel, padding=padding).clamp(0, 1)
    outside_boundary = (dilated_hole - hole).clamp(0, 1)

    eroded_known = 1.0 - F.conv2d(hole, kernel, padding=padding).clamp(0, 1)
    inside_boundary = (mask - eroded_known).clamp(0, 1)
    inside_boundary = inside_boundary * hole

    if boundary_side == "known":
        return outside_boundary
    if boundary_side == "hole":
        return inside_boundary
    if boundary_side == "both":
        return ((outside_boundary + inside_boundary) > 0).float()

    raise ValueError(f"Unknown boundary_side: {boundary_side}")


def masked_psnr(pred_rgb, gt_rgb, region_mask_1c):
    """
    pred_rgb, gt_rgb:
        H, W, 3 float32 [0, 1]

    region_mask_1c:
        H, W float32, 1 = evaluated region
    """
    region_3c = np.expand_dims(region_mask_1c, axis=-1).repeat(3, axis=-1)
    denom = np.sum(region_3c) + 1e-8
    mse = np.sum(((pred_rgb - gt_rgb) ** 2) * region_3c) / denom
    if mse <= 0:
        return 99.99
    return 10.0 * np.log10(1.0 / mse)


def masked_mae(pred_rgb, gt_rgb, region_mask_1c):
    region_3c = np.expand_dims(region_mask_1c, axis=-1).repeat(3, axis=-1)
    denom = np.sum(region_3c) + 1e-8
    return np.sum(np.abs(pred_rgb - gt_rgb) * region_3c) / denom


def masked_ssim_from_map(ssim_map, region_mask_1c):
    """
    ssim_map:
        H, W, 3
    region_mask_1c:
        H, W
    """
    ssim_gray = np.mean(ssim_map, axis=2)
    return np.sum(ssim_gray * region_mask_1c) / (np.sum(region_mask_1c) + 1e-8)


def boundary_edge_f1(pred_rgb, gt_rgb, boundary_mask_1c, sigma=2.0):
    """
    Edge-F1 within boundary region.
    """
    pred_gray = (
        0.299 * pred_rgb[:, :, 0] +
        0.587 * pred_rgb[:, :, 1] +
        0.114 * pred_rgb[:, :, 2]
    )
    gt_gray = (
        0.299 * gt_rgb[:, :, 0] +
        0.587 * gt_rgb[:, :, 1] +
        0.114 * gt_rgb[:, :, 2]
    )

    pred_edge = canny(pred_gray, sigma=sigma).astype(np.float32)
    gt_edge = canny(gt_gray, sigma=sigma).astype(np.float32)

    region = (boundary_mask_1c > 0.5).astype(np.float32)
    pred_edge = pred_edge * region
    gt_edge = gt_edge * region

    tp = np.sum((pred_edge > 0.5) & (gt_edge > 0.5))
    fp = np.sum((pred_edge > 0.5) & (gt_edge <= 0.5))
    fn = np.sum((pred_edge <= 0.5) & (gt_edge > 0.5))

    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2.0 * precision * recall / (precision + recall + 1e-8)

    return float(precision), float(recall), float(f1)


def compute_all_metrics(
    pred_tensor,
    gt_tensor,
    mask_tensor,
    boundary_tensor,
    lpips_fn,
    niqe_metric=None,
    edge_sigma=2.0
):
    """
    pred_tensor, gt_tensor:
        [1, 3, H, W], RGB, [0,1]

    mask_tensor:
        [1, 1, H, W], 1 = known, 0 = hole

    boundary_tensor:
        [1, 1, H, W], 1 = boundary region
    """
    pred_tensor = ensure_4d(pred_tensor).detach().float().clamp(0, 1)
    gt_tensor = ensure_4d(gt_tensor).detach().float().clamp(0, 1)
    mask_tensor = ensure_4d(mask_tensor).detach().float()
    boundary_tensor = ensure_4d(boundary_tensor).detach().float()

    pred_u8 = tensor_to_uint8_rgb(pred_tensor)
    gt_u8 = tensor_to_uint8_rgb(gt_tensor)

    pred_f32 = pred_u8.astype(np.float32) / 255.0
    gt_f32 = gt_u8.astype(np.float32) / 255.0

    mask_np = mask_tensor[0, 0].detach().cpu().numpy().astype(np.float32)
    hole_np = 1.0 - mask_np
    boundary_np = boundary_tensor[0, 0].detach().cpu().numpy().astype(np.float32)

    global_psnr = psnr_metric(gt_u8, pred_u8, data_range=255)

    _, ssim_map = ssim_metric(
        gt_f32,
        pred_f32,
        channel_axis=2,
        full=True,
        data_range=1.0
    )
    global_ssim = float(np.mean(ssim_map))

    hole_psnr = masked_psnr(pred_f32, gt_f32, hole_np)
    hole_ssim = masked_ssim_from_map(ssim_map, hole_np)
    hole_mae = masked_mae(pred_f32, gt_f32, hole_np)

    boundary_psnr = masked_psnr(pred_f32, gt_f32, boundary_np)
    boundary_ssim = masked_ssim_from_map(ssim_map, boundary_np)
    boundary_mae = masked_mae(pred_f32, gt_f32, boundary_np)

    edge_precision, edge_recall, edge_f1 = boundary_edge_f1(
        pred_f32,
        gt_f32,
        boundary_np,
        sigma=edge_sigma
    )

    with torch.no_grad():
        # LPIPS expects RGB normalized to [-1,1]
        lpips_val = lpips_fn(
            pred_tensor * 2.0 - 1.0,
            gt_tensor * 2.0 - 1.0
        ).item()

        if niqe_metric is not None:
            # pyiqa expects [B,C,H,W], range [0,1]
            niqe_val = niqe_metric(pred_tensor).item()
        else:
            niqe_val = 0.0

    return {
        "Global_PSNR": round(float(global_psnr), 4),
        "Global_SSIM": round(float(global_ssim), 4),
        "Hole_PSNR": round(float(hole_psnr), 4),
        "Hole_SSIM": round(float(hole_ssim), 4),
        "Hole_MAE": round(float(hole_mae), 6),
        "Boundary_PSNR": round(float(boundary_psnr), 4),
        "Boundary_SSIM": round(float(boundary_ssim), 4),
        "Boundary_MAE": round(float(boundary_mae), 6),
        "Boundary_Edge_Precision": round(float(edge_precision), 4),
        "Boundary_Edge_Recall": round(float(edge_recall), 4),
        "Boundary_Edge_F1": round(float(edge_f1), 4),
        "LPIPS": round(float(lpips_val), 4),
        "NIQE": round(float(niqe_val), 4),
    }


def load_prompt_dict(prompt_path):
    if prompt_path and os.path.exists(prompt_path):
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt_dict = json.load(f)
        print(f"Loaded prompt json: {prompt_path}, num={len(prompt_dict)}")
        return prompt_dict
    print("Warning: prompt json not found. Default English prompt will be used.")
    return {}


def get_prompt(prompt_dict, img_name, img_base, default_prompt):
    raw_prompt = prompt_dict.get(img_name, prompt_dict.get(img_base, default_prompt))
    if isinstance(raw_prompt, dict):
        return raw_prompt.get("final_prompt", default_prompt)
    return str(raw_prompt)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-opt", default="./options/test/test_combined_routeA.yml", type=str)
    parser.add_argument("--pretrain_model_G", default="", type=str)
    parser.add_argument("--pretrain_model_Gs", default="", type=str)
    parser.add_argument("--mask_root", default="", type=str)
    parser.add_argument("--prompt_path", default="", type=str)
    parser.add_argument("--results_root", default="", type=str)
    parser.add_argument("--image_size", default=256, type=int)
    parser.add_argument("--edge_sigma", default=2.0, type=float)
    parser.add_argument("--boundary_kernel", default=5, type=int)
    parser.add_argument("--boundary_side", default="known", choices=["known", "hole", "both"])
    parser.add_argument("--max_images", default=-1, type=int)
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--save_images", action="store_true")
    parser.add_argument(
        "--default_prompt",
        default=(
            "A colorful Dunhuang mural painting with ancient mineral pigments, "
            "religious figures, decorative patterns, and damaged regions."
        ),
        type=str
    )
    args = parser.parse_args()

    set_random_seed(args.seed)

    opt = option.parse(args.opt, is_train=False)
    opt = option.dict_to_nonedict(opt)

    if args.pretrain_model_G:
        opt["path"]["pretrain_model_G"] = args.pretrain_model_G
    if args.pretrain_model_Gs:
        opt["path"]["pretrain_model_Gs"] = args.pretrain_model_Gs
    if args.results_root:
        opt["path"]["results_root"] = args.results_root

    base_results_root = opt["path"]["results_root"]

    util.mkdirs(
        path for key, path in opt["path"].items()
        if key != "experiments_root"
        and "pretrain_model" not in key
        and "resume" not in key
    )

    util.setup_logger(
        "base",
        opt["path"]["log"],
        "test_ours_hard_baseline_structure_metrics",
        level=logging.INFO,
        screen=True,
        tofile=True
    )
    logger = logging.getLogger("base")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    logger.info("Loading LPIPS and NIQE...")
    lpips_fn = lpips.LPIPS(net="vgg").to(device)
    lpips_fn.eval()

    niqe_metric = None
    if HAS_NIQE:
        niqe_metric = pyiqa.create_metric("niqe", device=device)

    logger.info("Creating Ours model...")
    model = create_model(opt)

    logger.info("Loading CLIP text encoder...")
    tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
    text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14").to(device)
    text_encoder.eval()
    for p in text_encoder.parameters():
        p.requires_grad = False

    sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )

    S_sde = util.IRSDE(
        max_sigma=opt["sde"]["max_sigma"],
        T=opt["sde"]["T"],
        schedule=opt["sde"]["schedule"],
        eps=opt["sde"]["eps"],
        device=device
    )

    wrapped_model = OutputWrapper(model.model)
    sde.set_model(wrapped_model)

    resize_rgb = transforms.Resize((args.image_size, args.image_size), interpolation=InterpolationMode.BICUBIC)

    for phase, dataset_opt in sorted(opt["datasets"].items()):
        dataset_name = dataset_opt.get("name", phase)
        logger.info("=" * 90)
        logger.info(f"Testing dataset: {dataset_name}")
        logger.info("=" * 90)

        current_results_root = os.path.join(
            base_results_root,
            f"{dataset_name}_Ours_Hard_BaselineStructure_Metrics"
        )
        image_root = os.path.join(current_results_root, "images")
        metric_csv = os.path.join(current_results_root, f"{dataset_name}_metrics_detail.csv")
        summary_csv = os.path.join(current_results_root, f"{dataset_name}_metrics_summary.csv")
        util.mkdir(current_results_root)
        util.mkdir(image_root)

        test_set = create_dataset(dataset_opt)
        test_loader = create_dataloader(test_set, dataset_opt)

        prompt_path = args.prompt_path if args.prompt_path else dataset_opt.get("prompt_path", "")
        prompt_dict = load_prompt_dict(prompt_path)

        mask_root = args.mask_root if args.mask_root else dataset_opt.get(
            "mask_root",
            opt.get("degradation", {}).get("mask_root", "")
        )

        available_masks = sorted(
            glob.glob(os.path.join(mask_root, "*.png")) +
            glob.glob(os.path.join(mask_root, "*.jpg")) +
            glob.glob(os.path.join(mask_root, "*.jpeg"))
        )

        all_results = []
        categories = ["0-20%", "20-40%", "40%+"]
        cat_results = {c: [] for c in categories}

        for idx, train_data in enumerate(test_loader):
            if args.max_images > 0 and idx >= args.max_images:
                break

            img_path = train_data["GT_path"][0]
            img_base = os.path.basename(img_path)
            img_name = os.path.splitext(img_base)[0]

            mask_path = find_mask_for_image(img_path, mask_root)
            if mask_path is None:
                if available_masks:
                    mask_path = random.choice(available_masks)
                    logger.warning(f"No matched mask for {img_name}, use random mask: {mask_path}")
                else:
                    logger.warning(f"Skip {img_name}: no mask found in {mask_root}")
                    continue

            real_gt_pil = Image.open(img_path).convert("RGB")
            Y_GT = transforms.ToTensor()(resize_rgb(real_gt_pil)).unsqueeze(0).to(device)

            # Baseline-consistent oracle structure condition.
            X_GT, X_LQ = build_baseline_structure_from_gt(
                real_gt_pil=real_gt_pil,
                image_size=args.image_size,
                device=device,
                edge_sigma=args.edge_sigma
            )

            mask = read_mask_white_bg_black_hole(mask_path, image_size=args.image_size).to(device)
            mask = (mask > 0.5).float()

            observed = Y_GT * mask
            damage_ratio = float((mask == 0).float().mean().item())

            if damage_ratio <= 0.20:
                cat = "0-20%"
            elif damage_ratio <= 0.40:
                cat = "20-40%"
            else:
                cat = "40%+"

            current_prompt = get_prompt(
                prompt_dict=prompt_dict,
                img_name=img_name,
                img_base=img_base,
                default_prompt=args.default_prompt
            )

            tokens = tokenizer(
                [current_prompt],
                padding="max_length",
                max_length=77,
                truncation=True,
                return_tensors="pt"
            ).to(device)

            with torch.no_grad():
                prompt_context = text_encoder(tokens.input_ids)[0]

            model.model.eval()
            sde.set_mu(observed)

            wrapped_model.current_mask = mask
            wrapped_model.S_GT = X_GT
            wrapped_model.S_LQ = X_LQ
            wrapped_model.S_sde = S_sde

            init_xt = observed + torch.randn_like(Y_GT) * (opt["sde"]["max_sigma"] / 255.0)

            with torch.no_grad():
                SR_img = sde.reverse_sde(
                    init_xt,
                    prompt_context=prompt_context
                )

            wrapped_model.current_mask = None
            wrapped_model.S_GT = None
            wrapped_model.S_LQ = None
            wrapped_model.S_sde = None

            SR_img = ensure_4d(SR_img).to(device).float().clamp(0, 1)

            # HARD BLEND ONLY.
            # known region: observed input
            # hole region : model prediction
            hard_out = SR_img * (1.0 - mask) + observed
            hard_out = hard_out.clamp(0, 1)

            boundary = make_boundary_mask(
                mask=mask,
                kernel_size=args.boundary_kernel,
                boundary_side=args.boundary_side
            )

            metrics = compute_all_metrics(
                pred_tensor=hard_out,
                gt_tensor=Y_GT,
                mask_tensor=mask,
                boundary_tensor=boundary,
                lpips_fn=lpips_fn,
                niqe_metric=niqe_metric,
                edge_sigma=args.edge_sigma
            )

            res_item = {
                "Image": img_name,
                "ImagePath": img_path,
                "MaskPath": mask_path,
                "Category": cat,
                "DamageRatio": round(damage_ratio, 4),
                "Prompt": current_prompt,
                "Fusion": "Hard",
                "Structure": "BaselineConsistent_GTgray_GTedgeMasked",
                "BoundaryKernel": args.boundary_kernel,
                "BoundarySide": args.boundary_side,
                **metrics
            }

            all_results.append(res_item)
            cat_results[cat].append(res_item)

            if args.save_images:
                save_dir = os.path.join(image_root, cat)
                util.mkdir(save_dir)

                prefix = f"{img_name}_{cat.replace('%','')}_ratio{damage_ratio:.2f}"
                save_tensor_rgb(hard_out, os.path.join(save_dir, f"{prefix}_hard.png"))
                save_tensor_rgb(SR_img, os.path.join(save_dir, f"{prefix}_raw.png"))
                save_tensor_rgb(observed, os.path.join(save_dir, f"{prefix}_input.png"))
                save_tensor_rgb(Y_GT, os.path.join(save_dir, f"{prefix}_gt.png"))
                save_gray_tensor(boundary, os.path.join(save_dir, f"{prefix}_boundary.png"))
                save_gray_tensor(mask, os.path.join(save_dir, f"{prefix}_mask.png"))
                save_gray_tensor(X_GT, os.path.join(save_dir, f"{prefix}_GTgray.png"))
                save_gray_tensor(X_LQ * mask, os.path.join(save_dir, f"{prefix}_GTedge_masked.png"))

            if (idx + 1) % 10 == 0:
                logger.info(
                    f"[{dataset_name}] finished {idx + 1} | "
                    f"G-PSNR={metrics['Global_PSNR']:.4f} | "
                    f"H-PSNR={metrics['Hole_PSNR']:.4f} | "
                    f"B-PSNR={metrics['Boundary_PSNR']:.4f} | "
                    f"Edge-F1={metrics['Boundary_Edge_F1']:.4f}"
                )

        if not all_results:
            logger.error(f"No valid results for {dataset_name}")
            continue

        df = pd.DataFrame(all_results)
        df.to_csv(metric_csv, index=False)

        metric_cols = [
            "Global_PSNR", "Global_SSIM",
            "Hole_PSNR", "Hole_SSIM", "Hole_MAE",
            "Boundary_PSNR", "Boundary_SSIM", "Boundary_MAE",
            "Boundary_Edge_Precision", "Boundary_Edge_Recall", "Boundary_Edge_F1",
            "LPIPS", "NIQE"
        ]

        summary_rows = []

        for c in categories:
            sub = df[df["Category"] == c]
            if len(sub) == 0:
                continue

            row = {
                "Category": c,
                "Count": len(sub)
            }
            for m in metric_cols:
                row[m] = sub[m].mean()
            summary_rows.append(row)

        row_all = {
            "Category": "ALL",
            "Count": len(df)
        }
        for m in metric_cols:
            row_all[m] = df[m].mean()
        summary_rows.append(row_all)

        df_summary = pd.DataFrame(summary_rows)
        df_summary.to_csv(summary_csv, index=False)

        print("\n" + "=" * 120)
        print(f"{dataset_name} Ours Hard + Baseline-consistent Structure finished.")
        print(df_summary.to_string(index=False))
        print("=" * 120)
        print(f"Detail CSV : {metric_csv}")
        print(f"Summary CSV: {summary_csv}")

        logger.info(f"Detail CSV saved to: {metric_csv}")
        logger.info(f"Summary CSV saved to: {summary_csv}")


if __name__ == "__main__":
    main()
