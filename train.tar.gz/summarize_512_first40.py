#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--fusion", default="HardBlend", choices=["HardBlend", "SoftBlend"])
    args = parser.parse_args()

    df = pd.read_csv(args.csv)

    df = df[df["Fusion"] == args.fusion].copy()
    df = df[~df["Image"].astype(str).str.startswith("AVG_")]
    df = df[df["Image"].astype(str) != "AVERAGE_ALL"]

    metric_cols = [
        "Global_PSNR",
        "Global_SSIM",
        "Hole_PSNR",
        "LPIPS",
        "NIQE",
    ]

    for c in metric_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    print("\n==============================")
    print(f"Fusion: {args.fusion}")
    print(f"Valid images: {len(df)}")
    print("==============================\n")

    print("Overall average:")
    print(df[metric_cols].mean(numeric_only=True).round(4))

    if "Category" in df.columns:
        print("\nAverage by mask ratio category:")
        print(df.groupby("Category")[metric_cols].mean(numeric_only=True).round(4))

    print("\nImage-level metrics:")
    show_cols = ["Image", "Category", "Ratio"] + metric_cols
    show_cols = [c for c in show_cols if c in df.columns]
    print(df[show_cols].to_string(index=False))


if __name__ == "__main__":
    main()
