#!/usr/bin/env bash
set -euo pipefail

source /root/miniconda3/etc/profile.d/conda.sh
conda activate strdiff_v2

ROOT=/root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting
cd "$ROOT"

export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export TORCH_CUDA_ARCH_LIST="${TORCH_CUDA_ARCH_LIST:-8.9}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

mkdir -p boundary_sensitivity_route_only_logs

# K=5 is the existing PM-Correct seed-1234 baseline.
# By default train only the four NEW widths.
KERNELS="${KERNELS:-1 3 7 9}"

for K in $KERNELS; do
    CFG="$ROOT/options/train/boundary_sensitivity_route_only/PMCorrect_RouteK${K}_20K.yml"
    LOG="$ROOT/boundary_sensitivity_route_only_logs/RouteK${K}_20K.log"

    test -f "$CFG"

    echo "================================================"
    echo "START route_kernel_size=${K}"
    date
    echo "================================================"

    python train_new.py -opt "$CFG" 2>&1 | tee "$LOG"

    echo "DONE route_kernel_size=${K}"
    date
done
