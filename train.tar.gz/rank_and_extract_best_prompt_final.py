import shutil
from pathlib import Path
import pandas as pd

summary_csv = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation/prompt_ablation_retrain_final_summary.csv")
hard_root = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation/hard_fusion_outputs_retrain_final")

rank_csv = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation/prompt_ablation_retrain_final_ranked.csv")
best_out = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation/best_prompt_repaired_images_final")

df = pd.read_csv(summary_csv)

# 兼容字段检查
required = ["prompt_mode", "n_eval"]
for c in required:
    if c not in df.columns:
        raise SystemExit(f"Missing column: {c}")

# 排序指标优先级：
# 1. psnr_hole 越高越好
# 2. ssim_all 越高越好
# 3. psnr_all 越高越好
# 4. mae_hole 越低越好
sort_cols = []
ascending = []

if "psnr_hole" in df.columns:
    sort_cols.append("psnr_hole")
    ascending.append(False)

if "ssim_all" in df.columns:
    sort_cols.append("ssim_all")
    ascending.append(False)

if "psnr_all" in df.columns:
    sort_cols.append("psnr_all")
    ascending.append(False)

if "mae_hole" in df.columns:
    sort_cols.append("mae_hole")
    ascending.append(True)

if not sort_cols:
    raise SystemExit("No sortable metric found. Expected psnr_hole / ssim_all / psnr_all / mae_hole.")

df = df.copy()
df = df[df["n_eval"] > 0].copy()
df_ranked = df.sort_values(sort_cols, ascending=ascending).reset_index(drop=True)
df_ranked.insert(0, "rank", range(1, len(df_ranked) + 1))

df_ranked.to_csv(rank_csv, index=False, encoding="utf-8-sig")

show_cols = [
    "rank",
    "prompt_mode",
    "n_eval",
    "n_missing",
    "psnr_hole",
    "psnr_all",
    "ssim_all",
    "mae_hole",
    "mse_hole",
    "hard_dir",
]
show_cols = [c for c in show_cols if c in df_ranked.columns]

print("\n" + "=" * 120)
print("Prompt ranking, primary metric = psnr_hole")
print("=" * 120)
print(df_ranked[show_cols].to_string(index=False))

best = df_ranked.iloc[0]
best_prompt = str(best["prompt_mode"])

if "hard_dir" in df_ranked.columns and isinstance(best.get("hard_dir"), str) and best.get("hard_dir"):
    src = Path(best["hard_dir"])
else:
    src = hard_root / f"test_prompt_ablation_hard_{best_prompt}"

if not src.exists():
    # 兼容某些脚本命名
    candidates = list(hard_root.glob(f"*{best_prompt}*"))
    if candidates:
        src = candidates[0]

if not src.exists():
    raise SystemExit(f"Best prompt folder not found: {src}")

if best_out.exists():
    shutil.rmtree(best_out)
best_out.mkdir(parents=True, exist_ok=True)

image_exts = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff"}
count = 0

for p in sorted(src.rglob("*")):
    if p.is_file() and p.suffix.lower() in image_exts:
        rel = p.relative_to(src)
        dst = best_out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dst)
        count += 1

print("\n" + "=" * 120)
print("Best prompt extraction")
print("=" * 120)
print("Best prompt :", best_prompt)
print("Source dir  :", src)
print("Output dir  :", best_out)
print("Images copied:", count)
print("Ranking CSV :", rank_csv)
