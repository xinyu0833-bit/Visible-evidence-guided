import pandas as pd
from pathlib import Path
import re

root = Path("/root/autodl-tmp/data/mural/DUNHUANG/test/prompt_format_ablation")

files = sorted(root.glob("prompt_ablation_retrain_10000_scale*_full_summary.csv"))

if not files:
    raise SystemExit("No 10000 full summary CSV found.")

def extract_scale(name):
    m = re.search(r"scale([0-9]+)_full", name)
    if not m:
        return "unknown"
    s = m.group(1)
    mapping = {
        "05": "0.5",
        "1": "1.0",
        "10": "1.0",
        "15": "1.5",
        "2": "2.0",
        "20": "2.0",
    }
    return mapping.get(s, s)

rows = []
for p in files:
    df = pd.read_csv(p)
    df["csv_file"] = p.name
    df["scale"] = extract_scale(p.name)
    rows.append(df)

data = pd.concat(rows, ignore_index=True)

for col in ["n_eval", "psnr_hole", "psnr_all", "ssim_all", "mae_hole", "mse_hole"]:
    if col not in data.columns:
        data[col] = float("nan")

print("\n" + "=" * 120)
print("10000 FULL DATASET RESULTS SORTED BY scale, psnr_hole DESC")
print("=" * 120)

cols = [
    "scale",
    "prompt_mode",
    "n_eval",
    "psnr_hole",
    "psnr_all",
    "ssim_all",
    "mae_hole",
    "mse_hole",
    "csv_file",
]

print(
    data.sort_values(["scale", "psnr_hole"], ascending=[True, False])[
        [c for c in cols if c in data.columns]
    ].to_string(index=False)
)

print("\n" + "=" * 120)
print("BEST PROMPT FOR EACH SCALE")
print("=" * 120)

best = (
    data.sort_values("psnr_hole", ascending=False)
    .groupby("scale", as_index=False)
    .head(1)
    .sort_values("scale")
)

print(
    best[
        [c for c in ["scale", "prompt_mode", "n_eval", "psnr_hole", "psnr_all", "ssim_all", "csv_file"] if c in data.columns]
    ].to_string(index=False)
)

print("\n" + "=" * 120)
print("PROMPT GAIN AGAINST no_prompt WITHIN EACH SCALE")
print("=" * 120)

gain_rows = []
for scale, g in data.groupby("scale"):
    base = g[g["prompt_mode"] == "no_prompt"]
    if base.empty:
        continue

    base = base.iloc[0]
    for _, r in g.iterrows():
        gain_rows.append({
            "scale": scale,
            "prompt_mode": r["prompt_mode"],
            "n_eval": r["n_eval"],
            "psnr_hole": r["psnr_hole"],
            "delta_hole_vs_no": r["psnr_hole"] - base["psnr_hole"],
            "psnr_all": r["psnr_all"],
            "delta_all_vs_no": r["psnr_all"] - base["psnr_all"],
            "ssim_all": r["ssim_all"],
            "delta_ssim_vs_no": r["ssim_all"] - base["ssim_all"],
            "csv_file": r["csv_file"],
        })

gain = pd.DataFrame(gain_rows)

if not gain.empty:
    print(
        gain.sort_values(["scale", "delta_hole_vs_no"], ascending=[True, False])
        .to_string(index=False)
    )

print("\n" + "=" * 120)
print("KEY COMPARISON")
print("=" * 120)

target_modes = [
    "no_prompt",
    "generic_prompt",
    "content_only",
    "content_degradation",
    "full_structured",
]

mid = data[data["prompt_mode"].isin(target_modes)].copy()

print(
    mid.sort_values(["scale", "psnr_hole"], ascending=[True, False])[
        [c for c in ["scale", "prompt_mode", "n_eval", "psnr_hole", "psnr_all", "ssim_all", "mae_hole", "csv_file"] if c in mid.columns]
    ].to_string(index=False)
)

print("\n" + "=" * 120)
print("OBSERVATION CHECKLIST")
print("=" * 120)

for scale, g in data.groupby("scale"):
    print(f"\n[scale={scale}]")

    g_sorted = g.sort_values("psnr_hole", ascending=False)
    top = g_sorted.iloc[0]
    print(f"Top prompt: {top['prompt_mode']} | psnr_hole={top['psnr_hole']:.4f}")

    no = g[g["prompt_mode"] == "no_prompt"]
    if no.empty:
        continue

    no_h = no.iloc[0]["psnr_hole"]

    for name in ["generic_prompt", "content_only", "content_degradation", "full_structured"]:
        item = g[g["prompt_mode"] == name]
        if item.empty:
            continue
        delta = item.iloc[0]["psnr_hole"] - no_h
        mark = "BETTER" if delta > 0 else "WORSE"
        print(f"{name:22s}: delta_hole_vs_no={delta:+.4f} ({mark})")

    full = g[g["prompt_mode"] == "full_structured"]
    cd = g[g["prompt_mode"] == "content_degradation"]
    co = g[g["prompt_mode"] == "content_only"]

    if not full.empty and not cd.empty:
        delta = full.iloc[0]["psnr_hole"] - cd.iloc[0]["psnr_hole"]
        mark = "full > content_degradation" if delta > 0 else "full < content_degradation"
        print(f"full vs content_degradation: {delta:+.4f} ({mark})")

    if not full.empty and not co.empty:
        delta = full.iloc[0]["psnr_hole"] - co.iloc[0]["psnr_hole"]
        mark = "full > content_only" if delta > 0 else "full < content_only"
        print(f"full vs content_only       : {delta:+.4f} ({mark})")

print("\nDone.")
