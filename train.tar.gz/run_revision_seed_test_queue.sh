#!/bin/bash
set -e

source /root/miniconda3/etc/profile.d/conda.sh
conda activate strdiff_v2

cd /root/autodl-tmp/StrDiffusion_Official/train/texture/config/inpainting

export PYTHONPATH=$PWD:$PYTHONPATH
export CUDA_VISIBLE_DEVICES=0

for SEED in 2025 3407
do

    CFG=$PWD/options/test/revision_seeds/PM_Correct_Seed${SEED}_Test.yml

    python \
    prompt_format_ablation/test_conbined_routeA.py \
    -opt "$CFG" \
    2>&1 | tee \
    revision_seed_test_logs/PM_Correct_Seed${SEED}_Test.log

done
